import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(width, height, rgba) {
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const stride = width * 4 + 1;
  const raw = Buffer.alloc(stride * height);
  for (let y = 0; y < height; y++) {
    raw[y * stride] = 0;
    rgba.copy(raw, y * stride + 1, y * width * 4, (y + 1) * width * 4);
  }
  const compressed = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    signature,
    makeChunk('IHDR', ihdr),
    makeChunk('IDAT', compressed),
    makeChunk('IEND', Buffer.alloc(0)),
  ]);
}

function mix(a, b, t) {
  return a + (b - a) * Math.max(0, Math.min(1, t));
}

function blendPixel(buf, idx, r, g, b, alpha) {
  const a = Math.max(0, Math.min(1, alpha));
  if (a <= 0) return;
  const inv = 1 - a;
  buf[idx] = Math.round(buf[idx] * inv + r * a);
  buf[idx + 1] = Math.round(buf[idx + 1] * inv + g * a);
  buf[idx + 2] = Math.round(buf[idx + 2] * inv + b * a);
  buf[idx + 3] = Math.round(Math.min(255, buf[idx + 3] + 255 * a));
}

function smoothstep(edge0, edge1, x) {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

function renderSippyIcon(size, maskable = false) {
  const buf = Buffer.alloc(size * size * 4);
  const scale = maskable ? 0.68 : 0.84;

  for (let y = 0; y < size; y++) {
    const ny = (y + 0.5) / size;
    const bgR = Math.round(mix(108, 47, ny));
    const bgG = Math.round(mix(147, 91, ny));
    const bgB = Math.round(mix(250, 224, ny));

    for (let x = 0; x < size; x++) {
      const nx = (x + 0.5) / size;
      const idx = (y * size + x) * 4;

      // Background (full bleed for maskable/iOS, rounded squircle for standard)
      let bgAlpha = 1;
      if (!maskable) {
        const cx = Math.abs(nx - 0.5);
        const cy = Math.abs(ny - 0.5);
        const r = 0.22;
        const dx = Math.max(cx - (0.5 - r), 0);
        const dy = Math.max(cy - (0.5 - r), 0);
        const dist = Math.hypot(dx, dy) - r;
        bgAlpha = 1 - smoothstep(-1.5 / size, 1.5 / size, dist);
      }

      buf[idx] = bgR;
      buf[idx + 1] = bgG;
      buf[idx + 2] = bgB;
      buf[idx + 3] = Math.round(bgAlpha * 255);

      if (bgAlpha <= 0.01) continue;

      // Map coordinates into Sippy's normalized space [-1, 1]
      const sx = (nx - 0.5) / (0.5 * scale);
      const sy = (ny - 0.51) / (0.5 * scale);

      // Droplet SDF: chubby bottom circle + soft tapered top
      const dropY = sy - 0.14;
      const widthAtY = sy < 0.14 ? mix(0.06, 0.56, Math.pow(Math.max(0, (sy + 0.68) / 0.82), 0.72)) : 0.56;
      let dDrop = 1;
      if (sy >= 0.14) {
        dDrop = Math.hypot(sx, dropY) - 0.56;
      } else if (sy >= -0.68) {
        const horiz = Math.abs(sx) - widthAtY;
        dDrop = horiz;
      } else {
        dDrop = Math.hypot(sx, sy + 0.68) - 0.05;
      }

      const dropAlpha = (1 - smoothstep(-0.025, 0.025, dDrop)) * bgAlpha;
      if (dropAlpha > 0) {
        const dt = Math.max(0, Math.min(1, (sy + 0.68) / 1.38));
        const dr = Math.round(mix(165, 111, dt));
        const dg = Math.round(mix(230, 211, dt));
        const db = Math.round(mix(255, 255, dt));
        blendPixel(buf, idx, dr, dg, db, dropAlpha);

        // Upper-left highlight
        const hx = (sx + 0.2) * Math.cos(-0.42) - (sy + 0.18) * Math.sin(-0.42);
        const hy = (sx + 0.2) * Math.sin(-0.42) + (sy + 0.18) * Math.cos(-0.42);
        const hDist = Math.hypot(hx / 0.11, hy / 0.2) - 1;
        const hAlpha = (1 - smoothstep(-0.08, 0.08, hDist)) * 0.35 * dropAlpha;
        blendPixel(buf, idx, 255, 255, 255, hAlpha);

        // Cheeks (#FF9DB5 at 45%)
        const cLeft = Math.hypot((sx + 0.34) / 0.09, (sy - 0.24) / 0.055) - 1;
        const cRight = Math.hypot((sx - 0.34) / 0.09, (sy - 0.24) / 0.055) - 1;
        const cAlpha = Math.max(1 - smoothstep(-0.1, 0.1, cLeft), 1 - smoothstep(-0.1, 0.1, cRight)) * 0.45 * dropAlpha;
        blendPixel(buf, idx, 255, 157, 181, cAlpha);

        // Eyes (white ovals)
        const eLeft = Math.hypot((sx + 0.19) / 0.11, (sy - 0.09) / 0.14) - 1;
        const eRight = Math.hypot((sx - 0.19) / 0.11, (sy - 0.09) / 0.14) - 1;
        const eAlpha = Math.max(1 - smoothstep(-0.06, 0.06, eLeft), 1 - smoothstep(-0.06, 0.06, eRight)) * dropAlpha;
        blendPixel(buf, idx, 255, 255, 255, eAlpha);

        // Pupils (#0B1633)
        const pLeft = Math.hypot(sx + 0.175, sy - 0.1) - 0.068;
        const pRight = Math.hypot(sx - 0.175, sy - 0.1) - 0.068;
        const pAlpha = Math.max(1 - smoothstep(-0.015, 0.015, pLeft), 1 - smoothstep(-0.015, 0.015, pRight)) * dropAlpha;
        blendPixel(buf, idx, 11, 22, 51, pAlpha);

        // Eye glints
        const gLeft = Math.hypot(sx + 0.15, sy - 0.06) - 0.025;
        const gRight = Math.hypot(sx - 0.20, sy - 0.06) - 0.025;
        const gAlpha = Math.max(1 - smoothstep(-0.01, 0.01, gLeft), 1 - smoothstep(-0.01, 0.01, gRight)) * dropAlpha;
        blendPixel(buf, idx, 255, 255, 255, gAlpha);

        // Smile arc
        const smileY = 0.25 + 0.055 * (1 - Math.min(1, (sx / 0.11) ** 2));
        const dSmile = Math.abs(sx) <= 0.105 ? Math.abs(sy - smileY) - 0.022 : Math.hypot(Math.abs(sx) - 0.105, sy - 0.25) - 0.022;
        const sAlpha = (1 - smoothstep(-0.012, 0.012, dSmile)) * dropAlpha;
        blendPixel(buf, idx, 11, 22, 51, sAlpha);
      }
    }
  }
  return encodePNG(size, size, buf);
}

const outDir = path.resolve('public');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'pwa-192x192.png'), renderSippyIcon(192, false));
fs.writeFileSync(path.join(outDir, 'pwa-512x512.png'), renderSippyIcon(512, false));
fs.writeFileSync(path.join(outDir, 'pwa-maskable-512x512.png'), renderSippyIcon(512, true));
fs.writeFileSync(path.join(outDir, 'apple-touch-icon.png'), renderSippyIcon(180, true));
console.log('Generated Sippy PWA PNG icons in public/.');
