import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const rules = fs.readFileSync('firestore.rules', 'utf8');

test('firestore.rules enforces default-deny, verified owner, and bounded fields', () => {
  assert.match(rules, /rules_version\s*=\s*'2'/);
  assert.match(rules, /match \/{document=\*\*}\s*\{\s*allow read, write: if false;/);
  assert.match(rules, /request\.auth\.token\.email_verified == true/);
  assert.match(rules, /allow list: if false;/);
  assert.match(rules, /data\.ml is int && data\.ml >= 1 && data\.ml <= 3000/);
  assert.match(rules, /data\.feelings is list && data\.feelings\.size\(\) <= 10/);
  assert.match(rules, /parentUserExists\(userId\)/);
  assert.match(rules, /affectedKeys\(\)\.hasOnly/);
});
