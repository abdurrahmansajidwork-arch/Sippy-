# Sippy — design.md

Single source of truth for how Sippy looks, behaves and feels. It describes the current designs (Welcome, Daily goal, Today, Log a drink, Stats, Reminder) and the rules behind them. Use it with `BRAND_GUIDELINE.md`. Where the two differ, this file wins, because it records the decisions made in the redesign.

---

## 1. Design idea in one paragraph

**Brand Soft Aqua, played with a Duolingo touch.** The palette, type and components come from the brand guideline: calm off-white canvas, one blue moment per screen, big friendly numbers, a mascot who carries the emotion. On top of that sits a *tactile* layer taken from Duolingo: chunky buttons with a darker bottom edge, heavy rounded numerals, flat saturated blocks, and a mascot who reacts to what is happening. Advanced inside, simple outside.

**Personality:** warm, playful, encouraging. Never nagging, never shaming.

### What we took from which reference (principles, not layouts)

| Reference | What we learned |
|---|---|
| Duolingo | The mascot is built from a few flat shapes and shows a different mood in every state. Buttons look pressable (bottom edge). One big action per screen. A learning path becomes our weekly Stats path. |
| Foku | Mascot with a speech bubble inside a hero card. Full-width dark CTA. Greeting plus date. |
| Lena / Miuu streak screens | Streak as a row of flames with dates, today as a filled circle, uppercase greeting. |
| Axius | One filled blue hero tile among white tiles. Floating rounded nav with a raised center button. Tinted icon bubbles on tiles. |
| Hydration wave app | Liquid fill with bubbles. Pastel quick-add tiles. Water shown in a **glass**, never full screen. |
| Widget set | One color per metric. Big number, small unit. |

---

## 2. Color

### 2.1 Roles (what each color does)

| Role | Token | Hex |
|---|---|---|
| Primary brand | brand-500 | `#3D6EF5` |
| Main CTA (button fill) | ink-900 | `#0B1633` |
| Secondary CTA (on blue/tinted cards) | brand-500 fill, white text | `#3D6EF5` |
| Link / small blue text | brand-600 | `#2F5BE0` |
| Water (liquid, glasses, rings, water icons) | water-500 | `#19B4F2` |
| Streak / flame | flame-a → flame-b | `#FFB347` → `#FF6B2C` |
| Success, goal hit | mint-500 | `#22B07D` |
| Missed / delete / error | coral-500 | `#FF6B6B` |
| Feelings / AI insight | lav-500 | `#7C6CF2` |
| Page background | canvas | `#F4F6FA` |
| Card | card | `#FFFFFF` |

### 2.2 Full palette

| Token | Hex | Use |
|---|---|---|
| brand-50 | `#EEF3FF` | Tinted blocks, info notes, "to go" tile, glass shell |
| brand-100 | `#DCE6FE` | Log button ring, light text on blue backgrounds |
| brand-400 | `#6C93FA` | Gradient stop, dark-mode brand |
| brand-500 | `#3D6EF5` | Primary fills, selected chips, Next-sip card, welcome background |
| brand-600 | `#2F5BE0` | Small blue text on white, active nav label |
| ink-900 | `#0B1633` | Headings, big numbers, main CTA |
| ink-700 | `#1F2A44` | Body text |
| ink-500 | `#5B6578` | Secondary text, units, inactive nav |
| ink-300 | `#8A93A6` | Future days, chevrons, disabled |
| canvas | `#F4F6FA` | App background |
| card-tint | `#EAF0FB` | Unselected chips, strips, custom tile |
| line | `#E4E9F2` | 1px dividers, ring on future days |
| water-300 | `#6FD3FF` | Liquid top, wave layer |
| water-500 | `#19B4F2` | Glass liquid in small icons, ring |
| water-100 | `#D9F2FD` | 500 ml tile, water icon bubble, ring track |
| flame-a / flame-b | `#FFB347` / `#FF6B2C` | Streak flame |
| flame-tint | `#FFF1E3` | 300 ml tile, best-day icon bubble |
| mint-500 / mint-100 | `#22B07D` / `#E3F8EE` | Goal hit nodes, tea icon, 150 ml tile |
| coral-500 / coral-100 | `#FF6B6B` / `#FFE8E8` | Missed, error |
| lav-500 / lav-100 | `#7C6CF2` / `#EFEBFF` | 250 ml tile, insights |

### 2.3 Chunky edge colors (the Duolingo touch)

Each pressable element gets a solid, un-blurred bottom edge, a darker version of its own fill.

| Element | Fill | Bottom edge |
|---|---|---|
| Main CTA | `#0B1633` | `0 4px 0 #040A1A` |
| Brand button / selected chip / today circle | `#3D6EF5` | `0 3px 0 #2347B8` (CTA-size: `0 4px 0`) |
| White button on blue | `#FFFFFF` | `0 3px 0 #B9C9F5` |
| Unselected chip | `#EAF0FB` | `0 3px 0 #D3DDEF` |
| Quick tile 250 / 300 / 500 / 150 | lav-100 / flame-tint / water-100 / mint-100 | `0 4px 0` of `#DDD6FB` / `#F8DDBF` / `#B5E3F6` / `#C4EBD8` |
| Stats goal-hit node | `#22B07D` | `0 6px 0 #178A62` |
| Stats today node | `#FFFFFF` + 4px brand ring | `0 6px 0 #C4D2F2` |

### 2.4 Gradients

- **Liquid:** 180°, water-300 `#6FD3FF` → brand-500 `#3D6EF5`.
- **Mascot body:** 180°, `#5AA2FF` → `#3D6EF5`. Thirsty mood uses the paler `#A7C9FF` → `#7FA3FA`.
- **Hero card (Daily goal):** 180°, brand-50 `#EEF3FF` → `#CFE0FF`.
- **Flame:** 180°, `#FFB347` → `#FF6B2C`.
- Never on text.

### 2.5 Color rules

1. **One saturated brand-500 block per screen.** Today: the Next-sip card. Stats: the Daily-average tile. Welcome: the whole background is the block, so nothing else is saturated blue except buttons.
2. **Cyan only for water.** Orange only for streak and rewards. Coral only for missed/error. Lavender only for feelings. Mint only for success.
3. Max 3 hues in one card. No pure black. No gradient on text.
4. Small text on white is ink-700, ink-500 or brand-600, never brand-500.
5. White text is allowed on brand-500 only when **17px or larger**, or on ink-900. (Known gap: the 15px bold "Next sip" label on the blue card is under this rule. Raise it to 17px when polishing.)

### 2.6 Token code

```css
:root{
  --brand-50:#EEF3FF;--brand-100:#DCE6FE;--brand-400:#6C93FA;--brand-500:#3D6EF5;--brand-600:#2F5BE0;
  --ink-900:#0B1633;--ink-700:#1F2A44;--ink-500:#5B6578;--ink-300:#8A93A6;
  --canvas:#F4F6FA;--card:#FFFFFF;--card-tint:#EAF0FB;--line:#E4E9F2;
  --water-300:#6FD3FF;--water-500:#19B4F2;--water-100:#D9F2FD;
  --flame-a:#FFB347;--flame-b:#FF6B2C;--flame-tint:#FFF1E3;
  --mint-500:#22B07D;--mint-100:#E3F8EE;
  --coral-500:#FF6B6B;--coral-100:#FFE8E8;
  --lav-500:#7C6CF2;--lav-100:#EFEBFF;
  --edge-ink:#040A1A;--edge-brand:#2347B8;--edge-white-on-blue:#B9C9F5;--edge-mint:#178A62;
}
```

Dark mode follows the brand guideline (canvas `#0A1224`, card `#121C36`, brand-500 `#5B86FF`, main CTA inverts). Not yet designed.

---

## 3. Typography

**Font:** Plus Jakarta Sans (weights 500, 600, 700, 800). Fallback `system-ui, sans-serif`. **Tabular numbers everywhere** (`font-variant-numeric: tabular-nums`).

| Style | Size / weight | Where it is used |
|---|---|---|
| display | 56–60 / 800, tracking −0.02em | Big ml number (Today 56, Daily goal 60) |
| title-xl | 36 / 800, tracking −0.02em | "Today", welcome headline |
| h1 | 30 / 800, tracking −0.02em | Screen titles ("How much water a day?", "Your week") |
| h2 | 24–26 / 800 | Sheet titles, banner values |
| title | 17 / 700 | Buttons, log amounts, "1,300 ml" |
| body | 15 / 500–600 | Paragraphs, subtitles |
| caption | 13–14 / 500–600 | Times, notes, strip text |
| overline | 12 / 700, uppercase, +0.08em, ink-500 | Greeting name, section labels (QUICK ADD, THIS WEEK, TODAY'S LOG) |

**Number + unit:** number ink-900 at 800, unit ink-500 at 500, roughly 55% of the number size, baseline aligned ("1,500 **ml**").

**Voice in type:** headlines are short and sentence case. No all-caps outside overlines. At most one emoji per message. No gradient text.

---

## 4. Shape, spacing, elevation

- **Radius:** 8 badges · 12 small controls · 16 inputs, tiles, info notes, white buttons in cards · 20 main buttons and quick tiles · 24 cards · 28 hero card, sheet top corners · 34 nav pill · full round for chips-as-pills, Log button, day circles, stepper buttons.
- **Spacing (4pt grid):** 4, 8, 12, 16, 20, 24, 32. Screen padding **20**. Card padding 16 (hero 20). Gap between cards **12**. Gap before a new section label **24** (we use 12 + the label's own margin).
- **Elevation:**
  - card `0 6px 24px rgba(31,58,140,.08)`
  - nav `0 10px 32px rgba(11,22,51,.16)`
  - Log button `0 8px 24px rgba(61,110,245,.45)` + 6px brand-100 ring
  - blue card `0 8px 24px rgba(61,110,245,.30)`
  - **No hard borders on cards.** Hard edges only come from the chunky bottom edges in 2.3.
- **Canvas:** 390 × 844 phone. Scrolling screens (Today) are taller than 844, with the nav floating at the bottom.

---

## 5. Structure theory (how every screen is built)

1. **One job per screen, one main action.** The main action is the navy CTA or the raised Log button, never both competing.
2. **Reading order is fixed:** context line → big answer → one visual → one action → supporting detail.
   - Today: who/when → how much water → glass + Sippy → Drink 250 ml → next sip → quick add → week → log.
3. **The number is the hero.** The biggest thing on screen is always the user's number (ml, goal) or the headline.
4. **Say what the screen is for.** Every setup screen has a title that asks the question in plain words plus one supporting line. No screen relies on a label alone.
5. **Mascot carries emotion, not paragraphs.** Mood replaces extra text. A bubble is max 2 lines and changes only when state changes.
6. **Show water as a glass.** Progress is never a bare bar. The glass or the glass icon is the unit of measure; 10 glasses = 2,500 ml in the goal screen.
7. **Group by color.** Pastel tints separate categories (sizes, drinks) so labels can stay small.
8. **Progressive detail.** Setup screens show only the next question (4-dash progress). Today puts the answer first and history last.
9. **Nothing hidden behind a gesture.** The nav is fixed-size icons with labels. No expanding tabs, no hidden menus.

---

## 6. Components

| Component | Spec |
|---|---|
| **Main CTA** | Full width, 56 high, radius 20, ink-900 fill, white 17/700 text, droplet icon where it logs water, `0 4px 0 #040A1A` edge. One per screen. |
| **Split CTA (Today)** | Same CTA with a 56px caret segment on the right, separated by a 1px `#26335A` line. Left logs the default size, right opens the size sheet. |
| **Brand button** | brand-500 fill, white 17/700, radius 20, edge `#2347B8`. Used for "Continue with email" outline variant on blue (2px white-75% ring). |
| **White button on blue** | White fill, ink or brand-600 text, 48 high, radius 16, edge `#B9C9F5` (Snooze, Skip, Google). |
| **Chip** | 44 high, radius 16, card-tint, ink-700 700/15. Selected: brand-500 fill, white text, edge `#2347B8`. |
| **Stepper button** | 52px circle. Minus: white with brand icon, edge `#B9C9F5`. Plus: brand-500 with white icon, edge `#2347B8`. |
| **Hero card (Today)** | White, radius 28, 392 high. Top-left percent in brand-600 800/16, glass at left, bubble + Sippy at right, number block, "to go" tile, hot-day strip at the bottom. |
| **Hero card (Daily goal)** | Gradient brand-50 → `#CFE0FF`, radius 28, stepper row + 10-glass row + caption, divided by a 1.5px white line. |
| **Next-sip card** | brand-500, radius 24, 16 padding. Round 44 bell bubble (white 22%), label, 28/800 time, 20/800 amount, two white buttons below. The one blue block on Today. |
| **Quick-add tile** | 104 high, radius 20, pastel fill (150 mint, 250 lavender, 300 flame-tint, 500 water-100), glass icon above amount, chunky edge. Custom = dashed 2px `#C3CCDD` on card-tint. |
| **Streak pill** | White pill, radius 24, flame gradient icon, "12 day streak", chevron. |
| **Week row** | 7 columns: letter above, then circle. Hit = gradient flame with white date. Today = brand circle with white number and edge. Future = white circle with 1.5px line ring and ink-300 number. |
| **Log row** | Icon bubble 44 (water-100 + water-500 drop, or mint-100 + mint mug), "250 ml" 17/800 with small unit, drink name 13, time right, chevron. 1px line between rows. |
| **Speech bubble** | White, radius 18, 14/600, max 2 lines, 12px tail at bottom-left, soft shadow. |
| **Info note** | brand-50, radius 16, brand-600 info icon, 14/600 ink-700 text. |
| **Floating nav** | See 6.1. |
| **Bottom sheet (Log a drink)** | Radius 28 top, grabber 40×5, dim overlay ink-900, Sippy peeking over the top edge, size tiles + drink chips + time row + CTA. |
| **Notification banner** | White, radius 28, app icon (Sippy thirsty on brand square 56), meta line 12/600, title 20/800, body 14/500, water ring with percent, Done button + text link. |
| **Stats path node** | 60px circle. Goal hit = mint with white star. Today = white with brand ring and drop. Day and litres label beside it, alternating sides. Chest at the end = next reward. |
| **Banner (Stats)** | ink-900, radius 22, chunky edge, overline date range + 24/800 summary. Navy so blue stays rare. |

### 6.1 Navigation (final)

Floating pill, 68 high, radius 34, white 92% with blur, 16px side margins, 24px from bottom.

- Five equal slots: **Home · Plan · [Log] · Stats · Me**.
- Each tab: 24px outline icon (1.75 stroke, round caps) with an 11/700 label below. **Fixed size, never expands.**
- Active tab = brand-500 icon and label. Inactive = ink-500. No pill, no animation of layout.
- Center Log button: 60px circle, brand-500, white droplet, raised 28px, 6px brand-100 ring, shadow as above, `aria-label="Log a drink"`.
- Max 4 tabs plus the Log button.

---

## 7. Illustration theory

**Style:** chunky soft-gloss vector. Fill-only shapes, rounded forms, two-stop gradients, one soft highlight, soft contact shadow. Cute but clean, never clip-art, never realistic. All drawn as inline SVG. No photos, no 3D, no external images.

### 7.1 Sippy (the mascot)

Built from one body shape. Same character on every screen; **only the face and arms change**.

- **Body:** teardrop, round bottom, soft pointed top with a tiny curl. Gradient `#5AA2FF` → `#3D6EF5`.
- **Highlight:** one white ellipse at 35% on the upper left.
- **Eyes:** two big white ovals (≈26×30), navy pupils (r 7) with a white glint, placed low on the body for a cute proportion.
- **Cheeks:** pink blush `#FF9DB5` at 40%.
- **Arms:** two stub ovals in brand-500. No feet (removed after the first pass).
- **Shadow:** ellipse under the body, ink-900 at 8%.
- **Mouth:** small, 4px rounded stroke, navy.
- Minimum detail 4px at phone size. No thin strokes.

| Mood | Used on | Face and body |
|---|---|---|
| happy | Today hero, Daily goal | Open eyes, small smile |
| waving | Welcome | Happy, one arm raised |
| thinking | (available) | Pupils up, brows, flat mouth |
| hyped / cheering | Log sheet, Stats | Closed arc eyes, open mouth with tongue, both arms up |
| thirsty | Reminder | Paler body, half-lidded eyes, open mouth with tongue |
| sleepy | Wake window screen | Closed eyes, floating z |
| worried / cheeky / proud | Planned (see brand guideline 6.3) | Not yet drawn |

### 7.2 The glass

Tall tapered tumbler. Shell is brand-50 with a 3px brand-100 outline and a white highlight strip. Liquid uses the liquid gradient with **two wave layers** on the surface (back layer water-300 at 75%, front layer gradient), plus 2–3 small white bubbles. The percent label sits at the top-left of the hero card. Small glass icons (tiles, rows, goal screen) use a white shell with `#B7C6E6` outline and a flat `#19B4F2` liquid at the right fill level.

### 7.3 Other pieces

- **Flame:** rounded teardrop flame, gradient flame-a → flame-b. Used for the streak pill and hit days.
- **Chest (Stats):** flame-b body, flame-a lid, white latch. It is a reward, so it may use orange.
- **Stars (Stats):** white four-point-ish star on mint for goal hit.
- **Icons:** Lucide-style outline, 24px, 1.75 stroke, round caps. Filled only for the flame and the Log droplet.

---

## 8. Screen blueprints

### 1 · Welcome
Flat brand-blue background. "Sippy" mark top-left, speech bubble "Hi, I'm Sippy!" above a large waving Sippy, headline 36/800, one line of support, then **Continue with Google** (white) and **Continue with email** (outline on blue), legal line.

### 2 · Daily goal
Back chevron + 4-dash progress (1 filled). Title "How much water a day?" with "A good start is ready. You can change it any time." and Sippy at the right. Hero card: − 2,500 ml + stepper, row of 10 glasses, "About 10 glasses of 250 ml", "Tap + or − to change by 100 ml". Quick picks 2.0/2.5/3.0/3.5 L (2.5 selected). Info note about a doctor's advice. Navy Continue at the bottom.

### 3 · Today (reference structure)
Order: ALEX overline + "Today" + streak pill → hero card (54%, glass, bubble "Right on pace, lovely sipping", Sippy, 1,500 ml of 2,800 ml goal, 1,300 ml to go, hot-day strip) → split CTA **Drink 250 ml** → blue Next-sip card (3:30 PM · 250 ml, Snooze, Skip) → QUICK ADD tiles (250, 300, 500, Custom) → THIS WEEK + 12-day streak → flame week row (23–25 hit, 26 today, 27–29 future) → TODAY'S LOG, 4 drinks → floating nav. Empty state: 0 ml, bubble "Fresh day, ready for the first sip?", empty glass, log card with Sippy and "Nothing yet today".

### 4 · Log a drink (sheet)
Dim background, Sippy cheering over the sheet edge. "Log a drink" with the result line "1,500 → 1,750 ml · 63% of today". SIZE tiles 150/250/300/500 (250 selected with a 3px brand ring), DRINK chips (Water selected, Tea, Coffee, Juice), time row "Now · 2:42 PM  Change", navy **Log 250 ml**.

### 5 · Stats (week)
Title "Your week" + Week selector. Navy banner "6 of 7 goals hit" with the date range. Path of 7 nodes (Fri–Today) zig-zagging, litres beside each, Sippy cheering on the side, chest at the end ("Next reward · 14-day streak"). Two tiles: Daily average (blue) and Best day (white). Nav with Stats active.

### 6 · Reminder (notification)
Dark background, banner: app icon with thirsty Sippy, "Sippy · now", **Sippy is parched**, "250 ml and I'll stop dramatically fainting.", water ring 54%, **Done** + "Remind me later". A large thirsty Sippy peeks from the bottom edge.

### Still to design (from the 12-page Refined Screens PDF)
Wake window, Your go-to glasses, Reminders setup (tone), Building your plan, Sign-in error, Offline, Reminders blocked, Add to Home Screen, Today empty state, plus Log, Stats month/year and settings.

---

## 9. Voice and copy

Short, friendly sentences. Encouraging, a little cheeky, never shaming, no medical claims.

| Case | Title | Body |
|---|---|---|
| Gentle | Sip time | A little water now keeps the afternoon easy. |
| Playful (default) | Sippy is parched | 250 ml and I'll stop dramatically fainting. |
| Coach | Next 250 ml | You're 400 ml behind pace. Close the gap now. |
| On pace (Today bubble) | — | Right on pace, lovely sipping |
| Empty day (Today bubble) | — | Fresh day, ready for the first sip? |

Rules: title ≤ 60 characters, body ≤ 110, one emoji at most, no all-caps, no guilt or threats. In-app bubbles max 2 lines. Use "ml" with a space ("250 ml"). Doctor note stays on the goal screen: "If you have a doctor's advice on water, follow that."

---

## 10. Anti-slop notes (keep it from looking AI-made)

**Do**
- Use one clear hierarchy per screen: headline or number first, everything else smaller.
- Keep real, specific copy (the tone examples above). No lorem ipsum, no invented stats.
- Give every pressable thing a chunky edge, and nothing else. Edges are a signal, not decoration.
- Let color carry meaning (cyan = water, orange = streak, mint = hit). If a color has no job, remove it.
- Keep the mascot identical in shape; vary only the face and arms.
- Use real glass shapes and water levels, so the visual explains the number.
- Keep tabular numbers and consistent units.

**Don't**
- No glossy gradient stripes across the mascot, no purple cheeks, no sparkles spam, no background blobs or pastel circles.
- No gradient text, no pure black, no sharp corners.
- No more than one saturated blue block per screen.
- No left-border accent cards, no emoji as icons, no stock icons mixed with custom ones.
- No hard card borders (use shadow). No dense gray-on-gray text.
- No expanding nav tabs or hidden gestures for core actions.
- No generic copy like "Welcome back!" or "Let's get started"; write in Sippy's voice.
- Don't add a second primary button next to the main CTA.
- Don't repeat the same mascot pose on two screens.

**Checks before shipping a screen**
1. Squint test: is there one obvious first thing to read and one obvious thing to tap?
2. Count blue blocks: more than one means demote one to a tint.
3. Is any hue used for something other than its role?
4. Does every number have a small gray unit?
5. Are touch targets at least 44px? Are icon-only buttons labeled?
6. Is the mascot's mood right for the state, and different from the neighboring screen?
7. Does the screen say, in plain words, what it is for?

---

## 11. Accessibility

- Contrast pairs (WCAG AA): ink-900 on white > 15:1 · ink-500 on white ≈ 5.9:1 · brand-600 on white ≈ 5.7:1 · white on ink-900 > 15:1 · white on brand-500 ≈ 4.4:1 (large/bold 17px+ only).
- Touch targets ≥ 44px. Stepper buttons 52px, Log button 60px.
- Icon-only controls carry an `aria-label` (Less, More, Log a drink, More sizes).
- Never use color alone: hit days have a flame and a date, goal-hit nodes have a star, missed states get a coral dot.
- Respect reduced motion (see below).

---

## 12. Motion (from the brand guideline, not yet prototyped)

| Moment | Behavior |
|---|---|
| Tap | Scale 0.97 over 120 ms; the chunky edge shrinks to 1px so the button looks pressed |
| Log a drink | Droplet falls 500 ms, liquid rises 1200 ms (`cubic-bezier(.22,1,.36,1)`), number counts up, 6–10 bubbles |
| Water wave | Two layers moving sideways in 4 s and 6 s loops |
| Mascot idle | Gentle 3 s bob, blink every 4–6 s |
| Goal reached | Liquid overflows slightly, 1.6 s sparkle and droplet confetti, flame bounces, Sippy switches to hyped |
| Screen change | 220 ms fade + 8 px slide |

Animate only transform and opacity. With reduced motion on: no wave, bob or confetti, instant state changes.

---

## 13. Differences from BRAND_GUIDELINE.md (on purpose)

| Brand guideline | Current design | Why |
|---|---|---|
| No hard edges | Chunky 3–6px bottom edges on buttons, chips, tiles and nodes | The Duolingo touch: it makes things feel pressable and playful |
| Active nav tab = brand-500 icon on brand-100 pill | Color change only, with permanent labels | The expanding pill felt complicated |
| Mascot has stub arms only, no feet | Same (feet removed) | Match the guideline after the first pass |
| One blue block per screen | Welcome uses a full blue background; Stats uses a navy banner and mint nodes | Keeps blue rare while still using the Duolingo path idea |
| Mint for success | Used for goal-hit nodes and the tea icon | Success and "green drink" |
| Chip 36 high | Chip 44 high | Better touch target |

---

## 14. How to use this file

- Give this file plus `BRAND_GUIDELINE.md` to any designer or code tool. Build screens from the blueprints in section 8, using only tokens from section 2 and components from section 6.
- When unsure, ask in this order: what is the one job of the screen? What is the one number? What is the one action? Which mood does Sippy show?
- Update section 8 and section 13 whenever a screen or rule changes.
