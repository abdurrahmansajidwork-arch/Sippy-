# Sippy: Water Tracker PWA, Build Prompt for Google AI Studio

Working name only, rename freely. Paste everything below into Google AI Studio as one prompt.

## 1. Role and goal

You are a senior product designer and full-stack engineer. Build **Sippy**, a mobile-first installable PWA that does one thing: water tracking, but smarter than a normal tracker. The promise is **advanced features, simple use**. A first-time user must log a drink in one tap and understand every screen without a tutorial. Think Duolingo for hydration: a friendly droplet mascot, streaks, and nudges that learn when this person drinks and when they skip.

## 2. MVP scope

**Build:** Google sign-in, daily goal, custom glass sizes, one-tap logging, drink types, adaptive reminders delivered as push notifications to the phone, reminder shifting when one is missed, pattern learning, Duolingo-style messages, streaks, badges, glass skins, feeling check-in, weather and workout goal boost, offline-first logging, shareable progress card, simple stats.

**Do not build:** sleep tracking, food or calorie tracking, steps, weight, social feeds, payments, clock-app alarms, home screen widgets. A PWA cannot do the last two. Substitute: push notifications and long-press app shortcuts on the icon.

## 3. Tech stack and constraints

- React 18, TypeScript, Vite, Tailwind CSS (tokens from section 4 as CSS variables), Motion (Framer Motion) for animation. Hand-built SVG charts, no heavy chart library.
- Firebase modular SDK: Authentication (Google provider), Firestore with persistent offline cache, Cloud Messaging (web push), Cloud Functions (scheduled), and Firebase AI Logic for Gemini calls so no API key ships in client code.
- vite-plugin-pwa (Workbox) for manifest and service worker.
- Config only through env variables (VITE\_FIREBASE\_\*). Use AI Studio's Firebase integration to provision Auth and Firestore if available.
- Anything AI Studio cannot run itself (scheduled Cloud Functions need the Firebase CLI and the Blaze plan): finish the client completely, put the server code in /functions with exact deploy steps, and state clearly what is stubbed. Never fake it silently.
- Add a demo mode (?demo=1) with seeded data so every screen previews before Firebase is connected.
- Target Android Chrome and iOS Safari 16.4+ (installed to Home Screen). Max content width 480px, centered on desktop.

## 4. design.md

### 4.1 Design language

Name: **Soft Aqua Playful**. Calm, rounded, bright. An off-white canvas, one saturated blue moment per screen, big friendly numbers, and a mascot that carries the emotion. Everything is a soft rounded card; nothing is sharp, dense, or gray-on-gray. Borrow ideas from the references below, never layouts.

| Reference | Borrow |
| --- | --- |
| Axius (blue health app) | Saturated blue brand, white cards, one filled hero card with a lighter circular icon, floating pill nav with a centered circular button in a soft ring (our droplet replaces its heart), week pill selector |
| Foku (mascot focus app) | Chunky friendly mascot, speech bubble, small stat chips with icon plus value, selected chip = filled brand pill, full-width navy CTA, sparkles |
| Lena and Miuu Note (streak screens) | Uppercase overline greeting with name, flame streak row with today as a filled circle, big streak number, mascot message bubble, pastel stat cards, Month / All time segmented control |
| Hydration wave app | Liquid fill with percent label and bubbles, pastel quick-add tiles with ml, ring progress with gradient stroke |
| Widget set | One color per metric on white rounded cards: ring plus big number plus small unit |
| Green fitness app | Faded hatched past bars with percent labels, one solid highlighted bar, center action button |

### 4.2 Color tokens (light)

| Token | Hex | Use |
| --- | --- | --- |
| brand-50 | #EEF3FF | Tinted backgrounds, selected-row bg |
| brand-100 | #DCE6FE | Active nav pill, selected day bg, FAB ring |
| brand-400 | #6C93FA | Gradients, brand in dark mode |
| brand-500 | #3D6EF5 | Primary fill: Next-sip card, FAB, selected chips, progress |
| brand-600 | #2F5BE0 | Small text links on white, pressed state |
| ink-900 | #0B1633 | Primary CTA fill, headings, big numbers |
| ink-700 | #1F2A44 | Body text |
| ink-500 | #5B6578 | Secondary text, units |
| ink-300 | #8A93A6 | Placeholder, disabled, faded chart bars only |
| canvas | #F4F6FA | Page background |
| card | #FFFFFF | Cards |
| card-tint | #EAF0FB | Unselected chips, inputs |
| line | #E4E9F2 | 1px borders and dividers |
| water-300 | #6FD3FF | Liquid top, bubbles |
| water-500 | #19B4F2 | Rings, water numbers |
| water-100 | #D9F2FD | Ring tracks, 500 ml tile |
| flame-a / flame-b | #FFB347 / #FF6B2C | Streak flame gradient (top to bottom) |
| flame-tint | #FFF1E3 | 300 ml tile, streak card bg |
| mint-500 / mint-100 | #22B07D / #E3F8EE | Goal hit, success, 150 ml tile |
| coral-500 / coral-100 | #FF6B6B / #FFE8E8 | Missed slot, delete, undo |
| lav-500 / lav-100 | #7C6CF2 / #EFEBFF | Feelings, AI insight cards, 250 ml tile |

Liquid gradient: 180deg from water-300 to brand-500.

**Usage rules**

- One saturated brand-500 block per screen at most (the Next-sip card or the FAB area), everything else white or tinted.
- Cyan is only for water. Orange is only for streaks. Coral is only for missed or destructive. Lavender is only for feelings and AI insights. Mint is only for success.
- White text only on brand-500, ink-900, or flame fills. Small text on white uses ink-700 or brand-600, never brand-500 (contrast).
- Max 3 hues visible inside any one card.

### 4.3 Typography

Font: **Plus Jakarta Sans** (Google Fonts, weights 400 to 800), fallback system-ui. Use tabular-nums for all numbers.

| Style | Size / line | Weight | Use |
| --- | --- | --- | --- |
| display | 56 / 60, tracking -0.02em | 800 | Big ml number in the hero |
| h1 | 28 / 34 | 700 | Screen titles |
| h2 | 22 / 28 | 700 | Section and sheet titles, stat values |
| title | 17 / 24 | 600 | Card titles, buttons |
| body | 15 / 22 | 400 | Paragraphs, list rows |
| caption | 13 / 18 | 500 | Meta, timestamps |
| overline | 12 / 16, uppercase, tracking +0.08em | 700 | Greeting (GOOD AFTERNOON, ALEX) and section labels |

Number plus unit: number in ink-900 bold, unit in ink-500 weight 500 at about 55% of the number size, baseline aligned.

### 4.4 Shape, spacing, elevation

- Radius: 8 badges, 12 small controls, 16 inputs and tiles, 20 rectangular buttons, 24 cards, 28 hero card and sheet top corners, 34 nav pill, 999 chips, FAB, day circles.
- Spacing on a 4pt grid: 4, 8, 12, 16, 20, 24, 32. Screen padding 20. Card padding 16 (20 for hero). Gap between cards 12. Gap between sections 24.
- Shadows: card 0 6px 24px rgba(31,58,140,0.08). Nav 0 10px 32px rgba(11,22,51,0.16). FAB 0 8px 24px rgba(61,110,245,0.45). No hard borders on cards; use line only for dividers.
- Respect safe-area insets (top and bottom).

### 4.5 Components (when to use what)

- **Hero glass card:** radius 28, soft light-blue gradient (brand-50 to #CFE0FF) with faint light rays and sparkles. Holds the mascot with a speech bubble, the glass illustration, and the big number. One per Home screen.
- **Primary CTA:** full width, height 56, radius 20, ink-900 fill, white title text, droplet icon on the right. Press = scale 0.97 over 120ms. Used once per screen, e.g. 'Drink 250 ml'.
- **Next-sip card:** brand-500 fill, white text, lighter circular icon, shows next reminder time and ml, with Snooze and Skip text buttons.
- **Chip:** height 36, pill. Unselected card-tint with ink-700 text, selected brand-500 with white text. For drink types and glass sizes.
- **Quick-add tile:** 2-column grid, radius 20, pastel fill (150 mint-100, 250 lav-100, 300 flame-tint, 500 water-100, custom card-tint with dashed line), icon plus ml. One tap logs.
- **Stat card:** white, radius 24, padding 16, 32px tinted icon bubble, value (h2) plus unit, optional 44px ring (6px stroke, round caps, water-500 on water-100).
- **Streak strip:** 7 day circles, 40px. Hit = flame gradient icon with the date over it. Today = brand-500 circle, white number. Future = white circle, ink-300 number. Missed = white circle with a 4px coral dot below. Shield-saved = ice-blue flame. A streak chip (white pill, flame plus number) sits top right of Home.
- **Speech bubble:** white, radius 18, soft shadow, 10px tail toward the mascot, 14 / 600 ink-900, max 2 lines, pop-in 280ms spring. Changes only when the app state changes.
- **Bottom nav:** floating pill, 16px side margins, 12px above the safe area, height 68, radius 34, glass surface (rgba(255,255,255,0.82) plus 16px backdrop blur plus 1px line). 4 tabs (24px icon, 11 / 600 label). Active tab: brand-500 icon on a brand-100 pill, label ink-900. Center FAB: 60px circle, brand-500, white droplet icon, 6px brand-100 ring, raised 14px above the pill, opens the Log sheet.
- **Bottom sheet:** radius 28 top, 36x4 grabber, dim overlay, spring in 320ms, swipe to dismiss.
- **Toast:** ink-900 pill above the nav, e.g. 'Added 250 ml. Undo', visible 5s.
- **Segmented control:** Week / Month, pill track card-tint, selected white with shadow.
- **Empty states:** mascot (mood fitting) plus one sentence plus one button.

### 4.6 Mascot and illustration

Sippy is a chubby droplet: round bottom, soft pointed top with a tiny curl, body gradient #5AA2FF to #3D6EF5, white 35% highlight upper left, big glossy eyes (white ovals, navy pupils, white glint), pink cheek blush (#FF9DB5 at 40%), small smile, two stub arms. Draw everything as inline SVG in code with components `<Mascot mood size />` and `<GlassFill level skin />`. No stock images, no external image generation.

| Mood | When |
| --- | --- |
| happy | On pace |
| hyped | Goal reached, or 10% ahead of pace |
| thirsty | 15% or more behind pace: paler body, half-lidded eyes |
| worried | 2 missed slots in a row |
| sleepy | Outside the day window: closed eyes, floating z |
| cheeky | Playful nudges: a wink |
| proud | Streak milestones |
| waving | Welcome and onboarding |

Pace curve: expected % of the goal rises from 0 at window start to 100% at window end, with a slight ease-out.

Glass: tall tumbler, liquid gradient water-300 to brand-500, two wave layers on the surface, the percent label riding the surface line, rising bubbles, a few sparkle stars around it.

### 4.7 Motion

| Moment | Spec |
| --- | --- |
| Tap | scale 0.97, 120ms ease-out |
| Log a drink | Droplet falls into the glass 500ms, liquid rises 1200ms with cubic-bezier(.22,1,.36,1), number counts up over the same time, 6 to 10 bubbles rise, navigator.vibrate(15) |
| Wave | Two sine layers translateX, 4s and 6s linear loops, amplitude 6px, paused when the tab is hidden |
| Mascot idle | Bob 3s ease-in-out, 4px; blink 120ms every 4 to 6s at random |
| Goal hit | Liquid overflows slightly, 1.6s droplet and sparkle confetti, mascot hyped, streak flame bounces, 'Goal hit' sheet with a Share button |
| Screen change | 220ms fade plus 8px slide |

Animate only transform and opacity. With prefers-reduced-motion: no wave, bob, or confetti, instant state changes.

### 4.8 Iconography

Lucide-style outline icons, 24px, 1.75px stroke, rounded caps. Filled only for the active nav tab and the flame. Custom droplet icon for the FAB.

### 4.9 Dark mode (follows system)

canvas #0A1224, card #121C36, card-tint #1A2748, line #26335A, text #F2F5FF, secondary #A3AECB, brand-500 becomes #5B86FF. The primary CTA inverts (light fill, navy text). Pastel tiles become 18% opacity tints of their hue. Mascot and liquid stay the same.

### 4.10 Do and don't

- Do: big numbers with small units, 20px padding, mascot message max 2 lines, pastel tints to separate categories.
- Don't: more than 3 hues per card, gradient text, pure black, sharp corners, dense tables, more than 4 tabs plus the FAB, permission pop-ups on first load, red for anything except missed or delete.

## 5. Navigation and screens

Navigation: **Home, Plan, (FAB: Log), Stats, Me.** Nothing else.

**Onboarding (5 steps, progress dots, every step has a good default)**

1. Welcome: Sippy waving, 'Hi, I'm Sippy. I'll help you drink enough water and learn your rhythm.' Button: Continue with Google.
2. Goal: big number with minus and plus (100 ml steps), presets 2.0 / 2.5 / 3.0 / 3.5 L, small note 'Adjust to your doctor's advice'.
3. Day window: wake time and bedtime pickers (default 7:00 and 23:00). 'I only remind you between these times.'
4. Glasses: tiles 250 and 300 preselected, add custom, pick a default.
5. Reminders: Sippy asks, button 'Turn on reminders', choose tone (Gentle / Playful / Coach, default Playful). On iOS Safari not yet installed, show the Add to Home Screen steps. Finish with a short 'building your plan' animation.

**Home (top to bottom)**

1. Overline greeting with name, streak chip on the right.
2. Hero glass card: mascot plus bubble, glass, big '1,250 ml' with 'of 3,000 ml'.
3. Primary CTA 'Drink 250 ml' (default glass). A small chevron opens the glass picker.
4. Next-sip card with time, ml, Snooze 15, Skip.
5. Quick-add chips row.
6. Streak strip.
7. Today's log list (icon, ml, drink type, time ago, edit icon). Tap to edit the amount or time.
8. Reason line when the goal is boosted: 'Goal today 3,300 ml (+300 hot day)' with a one-tap remove.

**Plan:** vertical timeline of today's slots (done = mint, upcoming = brand, missed = coral, tag 'moved from 2:00 PM' when shifted). Tap a slot to log, skip, or edit the time. Header 'Today's plan', subtitle 'I rebuild this when things change'. A card 'Workout today? +500 ml' with a toggle.

**Stats:** Week / Month segmented control, bar chart (past bars faded, selected bar solid, percent labels), 3 stat cards (average per day, best streak, goal hit rate), lavender 'Sippy noticed' pattern card, feeling card, badges and glass skins grid.

**Me:** profile (Google), daily goal, glasses, wake and bedtime, tone, max reminders per day, units (ml / oz), weather boost toggle, theme (system), export data (JSON), delete account and data, About (includes 'Not medical advice').

**Log sheet (from the FAB):** pastel glass tiles, drink-type chips (Water, Sparkling, Tea, Coffee, Juice, Milk), custom amount stepper, optional 'drank earlier' time picker. Tap a tile = logged, sheet closes, undo toast.

**Feeling sheet:** 4 mascot faces (Drained, Okay, Good, Great), skippable.

## 6. Feature rules

**6.1 Goal and glasses.** Store everything in ml. Default glasses 250 and 300, unlimited custom (50 to 1500 ml, optional name, 6 icon choices), one default glass. Today's goal = base goal + boosts.

**6.2 Logging.** At most 2 taps from Home. Undo for 5s. Edit or delete past logs. Counted ml = ml x drink factor (water 1.0, sparkling 1.0, milk 0.9, tea 0.9, juice 0.85, coffee 0.8; editable, shown as approximate).

**6.3 Goal boosts.** Weather via Open-Meteo using coarse location, only after permission: max temp 30C or more = +10%, 35C or more = +20%. Workout toggle on Plan = +500 ml (editable). Always show the reason on Home.

**6.4 Schedule engine (rules first, AI tunes it).** Window = wake + 30 min to bedtime - 90 min. Slots = ceil(remaining ml / default glass), minimum gap 45 min, times snapped to 5 min, about 55% of the goal planned in the first half of the window. Each slot = time + target ml. Rebuild (debounced 2s) after every log, skip, or miss. Write pure TypeScript functions with unit tests.

**6.5 Missed reminders shift the plan.** A slot is missed 30 min after its notification with no log, or when the user taps Skip. Redistribute the missed ml over remaining slots (max +50% per slot). If there is no room, add up to 2 small extra slots before the window end. Never exceed the daily push cap. Drinking early or more shrinks or removes upcoming slots. Runs server-side with rules only (works with the app closed) and in the client with AI tuning when the app is open.

**6.6 Pattern learning.** Computed in code, not by the AI, from logs and notification outcomes: intake by hour, slot completion rate by hour and weekday, median response time after a push, best and worst weekday, usual first and last drink. Use defaults until 3 days of data exist. Save to patterns/current, recompute nightly and on app open. Send the stats JSON to Gemini, which returns (a) a 1 to 2 sentence insight, (b) schedule tweaks (for example, move the 3 PM slot to 2:30 because 3 PM is usually skipped), (c) notification copy. Validate against a JSON schema; on failure fall back to rules and template copy.

**6.7 Notification voice (Duolingo style).** Persona is Sippy. Tone setting: Gentle, Playful (default), Coach.

- Title max 60 characters, body max 110, one emoji max, no all caps, never shame, guilt, or threaten, no medical claims.
- Escalation: normal nudge at slot time. One soft follow-up 20 min later only if the slot is still open. After 2 misses in a row, a worried but kind message plus an automatic reschedule. After 3 ignored pushes in a row, back off to scheduled slots only and show in-app 'Want fewer reminders?'.
- Pattern callouts allowed, e.g. 'It's 3 PM, usually your quiet hour. One small sip?'.
- Defaults: max 8 pushes per day (adjustable 3 to 12), none outside the day window, none after the goal is reached except an optional evening summary.
- Action buttons: '+ default glass' and 'Snooze 15 min' (Android; iOS shows a plain notification). Tapping opens Home.

| Case | Title | Body |
| --- | --- | --- |
| Gentle | Sip time | A little water now keeps the afternoon easy. |
| Playful | Sippy is parched | 250 ml and I'll stop dramatically fainting. |
| Coach | Next 250 ml | You're 400 ml behind pace. Close the gap now. |
| Missed | Still here | No stress. I moved your plan: 2 small sips before 6. |
| Streak at risk | Day 12 is on the line | 600 ml to go. You've got time. |
| Pattern | I noticed something | Mornings are your best time. Let's front-load tomorrow. |

**6.8 Streaks, shields, badges, skins.** A day counts when counted ml reaches the goal. A Streak Shield is earned every 7-day streak (max 2 stored) and auto-protects one missed day (flame turns ice-blue). Badges: First Sip, 3-Day, 7-Day, 30-Day, Early Bird (500 ml before 10 AM), Perfect Week. Glass skins: Classic (default), Mason Jar (7-day streak), Sports Bottle (14), Boba Cup (30). Skins only change the illustration. Milestones trigger the mascot's proud mood and confetti.

**6.9 Feeling check-in.** After a log, at most 3 per day and no more than once per 3 logs, show the skippable one-tap feeling sheet. After 10 or more check-ins, Stats shows one lavender card comparing feelings with intake.

**6.10 Share card.** Render a 1080x1350 PNG (SVG to canvas): mascot, ring, streak, 'x / y ml', date, app name. Web Share API with the file, fallback download. No name or email on the card.

**6.11 Offline-first.** Firestore persistent cache plus service worker app shell. Logging, Plan, and the mascot all work offline. Show a small 'offline, will sync' pill and sync silently.

## 7. Data model and security

```
users/{uid}: { name, photoURL, goalMl, wakeTime, bedTime, tone, maxPushPerDay, unit, defaultGlassId, weatherBoost, shields, createdAt }
users/{uid}/glasses/{id}: { name, ml, icon }
users/{uid}/logs/{id}: { ts, ml, countedMl, glassId, drinkType, source: app|push|shortcut }
users/{uid}/days/{yyyy-mm-dd}: { goalMl, totalMl, hit, shieldUsed, boostMl, feelings[] }
users/{uid}/slots/{id}: { date, notifyAt, targetMl, status: pending|done|missed|skipped, movedFrom?, title, body, notified }
users/{uid}/patterns/current: { stats, insight, updatedAt }
users/{uid}/fcmTokens/{token}: { platform, createdAt }
```

Firestore rules: a user can read and write only documents under their own users/{uid}; log ml must be between 1 and 3000. Output firestore.rules and firestore.indexes.json.

## 8. PWA and push

- Manifest: name Sippy, short\_name Sippy, display standalone, theme\_color #3D6EF5, background\_color #F4F6FA, icons 192 and 512 plus maskable (droplet mascot rendered from SVG), shortcuts 'Log 250 ml' (/?quick=250) and 'Log custom' (/?quick=custom).
- FCM web push through a service worker (firebase-messaging-sw.js). Ask for permission only in onboarding step 5 or after the first log, never on first load. Store the token under fcmTokens, refresh on app open, delete invalid tokens.
- iOS: push only works after Add to Home Screen. Detect iOS Safari in non-standalone mode and show a 3-step install guide with the mascot.
- Cloud Functions in /functions: (1) every minute, collection-group query on slots where notified is false and notifyAt is now or earlier, send via FCM, mark notified; (2) every minute, mark slots missed 30 min after notification and run the rules reschedule; (3) hourly, for users whose local time just passed midnight, create the baseline schedule with template copy so reminders still arrive if the app was not opened.
- Gemini runs from the client through Firebase AI Logic while the app is open. If server-side Gemini is added in Functions, the key lives in a secret, never in the client.

## 9. Build order

At the end of each step, tell me what works and what is stubbed.

1. Design system, mascot, glass component, and Home with demo data (no Firebase).
2. Onboarding, Plan, Stats, Me, sheets, navigation, and motion with demo data.
3. Firebase Auth and Firestore with offline cache, replacing demo data.
4. PWA manifest, service worker, shortcuts, iOS install guide.
5. Schedule engine and missed-reminder shifting (pure functions with unit tests).
6. Push: FCM client, /functions, indexes, deploy steps.
7. Pattern learning and Gemini insight and copy with schema validation and fallbacks.
8. Streaks, shields, badges, skins, feeling check-in, share card, weather boost.

## 10. Acceptance checks

- A new user finishes onboarding in under 60 seconds and logs a first drink within 2 taps from Home.
- Logging works offline and syncs later.
- Missing a reminder produces a shifted plan with 'moved from' tags in Plan.
- A push arrives with the app closed (Android, and iOS when installed).
- Text meets WCAG AA, touch targets are at least 44px, log actions are announced via aria-live, reduced motion is respected.
- Installable PWA, animations hold 60fps on a mid-range Android phone.
- No API keys in the client bundle, Firestore rules deployed.
- About screen contains 'Not medical advice'.
