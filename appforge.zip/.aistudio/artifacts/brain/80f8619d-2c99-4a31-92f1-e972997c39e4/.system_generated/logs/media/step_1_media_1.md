# Sippy: Brand Guideline

Working name: Sippy. Use this file as the single source of truth for how the app looks, sounds, and feels. Give it to Google AI Studio together with the build prompt.

## 1. Brand in one line

A friendly water buddy that makes drinking enough feel easy, not like a chore. **Advanced inside, simple outside.**

**Personality:** warm, playful, encouraging, never nagging, never shaming.
**Look:** calm, rounded, bright. Off-white canvas, one blue moment per screen, big friendly numbers, a mascot that carries the emotion.
**Style name:** Soft Aqua Playful.

## 2. Color

### 2.1 Which color does what (quick answer)

| Role | Color | Hex |
|---|---|---|
| **Primary brand color** | Brand Blue (brand-500) | #3D6EF5 |
| **Main CTA button** | Ink Navy fill, white text | #0B1633 |
| **Secondary CTA** (on blue or tinted cards) | Brand Blue fill, white text | #3D6EF5 |
| **Text link / small blue text** | Brand Blue Deep (brand-600) | #2F5BE0 |
| **Water (liquid, rings, water numbers)** | Water Cyan | #19B4F2 |
| **Streak** | Flame orange gradient | #FFB347 to #FF6B2C |
| **Success / goal reached** | Mint | #22B07D |
| **Missed / delete / error** | Coral | #FF6B6B |
| **AI insight / feelings** | Lavender | #7C6CF2 |
| **Page background** | Canvas | #F4F6FA |
| **Card background** | White | #FFFFFF |

### 2.2 Full palette (light mode)

| Token | Hex | Use |
|---|---|---|
| brand-50 | #EEF3FF | Tinted backgrounds, selected-row background |
| brand-100 | #DCE6FE | Active nav pill, selected day background, Log button ring |
| brand-400 | #6C93FA | Gradients, brand color in dark mode |
| brand-500 | #3D6EF5 | Primary fills: Next-sip card, Log button, selected chips, progress |
| brand-600 | #2F5BE0 | Small blue text on white, pressed state |
| ink-900 | #0B1633 | Main CTA fill, headings, big numbers |
| ink-700 | #1F2A44 | Body text |
| ink-500 | #5B6578 | Secondary text, units |
| ink-300 | #8A93A6 | Placeholder, disabled, faded chart bars only |
| canvas | #F4F6FA | App background |
| card | #FFFFFF | Cards |
| card-tint | #EAF0FB | Unselected chips, inputs |
| line | #E4E9F2 | 1px dividers |
| water-300 | #6FD3FF | Liquid top, bubbles |
| water-500 | #19B4F2 | Rings, water numbers |
| water-100 | #D9F2FD | Ring tracks, 500 ml tile |
| flame-a | #FFB347 | Streak flame top |
| flame-b | #FF6B2C | Streak flame bottom |
| flame-tint | #FFF1E3 | 300 ml tile, streak card background |
| mint-500 | #22B07D | Goal hit, success |
| mint-100 | #E3F8EE | Success background, 150 ml tile |
| coral-500 | #FF6B6B | Missed, delete, error |
| coral-100 | #FFE8E8 | Missed or error background |
| lav-500 | #7C6CF2 | Feelings, AI insights |
| lav-100 | #EFEBFF | Insight card background, 250 ml tile |

**Gradients**

- Liquid: 180deg, water-300 to brand-500.
- Mascot body: 180deg, #5AA2FF to #3D6EF5.
- Hero card background: 180deg, brand-50 to #CFE0FF.
- Streak flame: 180deg, flame-a to flame-b.

### 2.3 Dark mode (follows the phone setting)

| Token | Hex |
|---|---|
| canvas | #0A1224 |
| card | #121C36 |
| card-tint | #1A2748 |
| line | #26335A |
| text | #F2F5FF |
| text-secondary | #A3AECB |
| brand-500 | #5B86FF |

The main CTA inverts (light fill, navy text). Pastel tiles become 18% opacity tints of their hue. Mascot, liquid, and flame stay the same.

### 2.4 Color rules

- One saturated brand-500 block per screen at most.
- Cyan is only for water. Orange only for streaks. Coral only for missed or destructive. Lavender only for feelings and AI insights. Mint only for success.
- White text is allowed only on brand-500 (bold or 17px and larger), ink-900, and flame fills.
- Small text on white uses ink-700 or brand-600, never brand-500.
- Max 3 hues inside any one card. No pure black. No gradient on text.

### 2.5 Contrast pairs (WCAG AA)

| Pair | Ratio | Allowed for |
|---|---|---|
| ink-900 on white | above 15:1 | All text |
| ink-700 on canvas | above 10:1 | All text |
| ink-500 on white | about 5.9:1 | All text |
| brand-600 on white | about 5.7:1 | Small text, links |
| white on brand-500 | about 4.4:1 | Large or bold text only (17px and up) |
| white on ink-900 | above 15:1 | All text |

### 2.6 Token code (paste into the project)

```css
:root {
  --brand-50:#EEF3FF; --brand-100:#DCE6FE; --brand-400:#6C93FA;
  --brand-500:#3D6EF5; --brand-600:#2F5BE0;
  --ink-900:#0B1633; --ink-700:#1F2A44; --ink-500:#5B6578; --ink-300:#8A93A6;
  --canvas:#F4F6FA; --card:#FFFFFF; --card-tint:#EAF0FB; --line:#E4E9F2;
  --water-300:#6FD3FF; --water-500:#19B4F2; --water-100:#D9F2FD;
  --flame-a:#FFB347; --flame-b:#FF6B2C; --flame-tint:#FFF1E3;
  --mint-500:#22B07D; --mint-100:#E3F8EE;
  --coral-500:#FF6B6B; --coral-100:#FFE8E8;
  --lav-500:#7C6CF2; --lav-100:#EFEBFF;

  /* semantic */
  --color-primary:var(--brand-500);
  --color-cta:var(--ink-900);
  --color-cta-text:#FFFFFF;
  --color-cta-secondary:var(--brand-500);
  --color-link:var(--brand-600);
  --color-water:var(--water-500);
  --color-streak:var(--flame-b);
  --color-success:var(--mint-500);
  --color-danger:var(--coral-500);
  --color-insight:var(--lav-500);
  --color-bg:var(--canvas);
  --color-surface:var(--card);
  --color-text:var(--ink-900);
  --color-text-muted:var(--ink-500);
  --color-border:var(--line);
}
@media (prefers-color-scheme: dark) {
  :root {
    --canvas:#0A1224; --card:#121C36; --card-tint:#1A2748; --line:#26335A;
    --brand-500:#5B86FF; --color-text:#F2F5FF; --color-text-muted:#A3AECB;
    --color-cta:#F2F5FF; --color-cta-text:#0B1633;
  }
}
```

## 3. Typography

**Font:** Plus Jakarta Sans (Google Fonts, weights 400 to 800). Fallback: system-ui, sans-serif. Use tabular numbers for all numbers.

| Style | Size / line | Weight | Use |
|---|---|---|---|
| display | 56 / 60, tracking -0.02em | 800 | Big ml number on Home |
| h1 | 28 / 34 | 700 | Screen titles |
| h2 | 22 / 28 | 700 | Section titles, stat values |
| title | 17 / 24 | 600 | Card titles, buttons |
| body | 15 / 22 | 400 | Paragraphs, list rows |
| caption | 13 / 18 | 500 | Timestamps, meta |
| overline | 12 / 16, uppercase, +0.08em | 700 | Greeting and section labels |

**Number plus unit:** number in ink-900 bold, unit in ink-500 weight 500 at about 55% of the number size, baseline aligned.

## 4. Shape, spacing, elevation

- **Radius:** 8 badges, 12 small controls, 16 inputs and tiles, 20 rectangular buttons, 24 cards, 28 hero card and sheet top corners, 34 nav pill, full round for chips, Log button, day circles.
- **Spacing (4pt grid):** 4, 8, 12, 16, 20, 24, 32. Screen padding 20. Card padding 16 (hero 20). Gap between cards 12. Gap between sections 24.
- **Shadows:** card `0 6px 24px rgba(31,58,140,0.08)`. Nav `0 10px 32px rgba(11,22,51,0.16)`. Log button `0 8px 24px rgba(61,110,245,0.45)`. No hard borders on cards.
- **Layout:** mobile first, max width 480px centered on desktop, respect safe-area insets.

## 5. Components (when to use what)

| Component | Spec | Use |
|---|---|---|
| Main CTA button | Full width, 56 high, radius 20, ink-900 fill, white title text, droplet icon | One per screen, e.g. Drink 250 ml, Continue |
| Secondary button | Brand-500 fill, white text, radius 20 | Inside blue or tinted cards |
| Text button | Brand-600 text, no fill | Snooze, Skip, Not now |
| Destructive button | Coral-500 fill or text | Delete only |
| Chip | 36 high, pill. Unselected card-tint with ink-700 text. Selected brand-500 with white text | Drink types, glass sizes |
| Quick-add tile | Radius 20, pastel fill: 150 ml mint-100, 250 ml lav-100, 300 ml flame-tint, 500 ml water-100, custom card-tint with dashed line | One-tap logging |
| Stat card | White, radius 24, padding 16, small tinted icon bubble, value plus unit | Numbers |
| Next-sip card | Brand-500 fill, white text, lighter circular icon | The one blue block on Home |
| Streak row | 7 circles of 40px. Hit: flame icon with date. Today: brand-500 circle, white number. Future: white circle, ink-300 number. Missed: white circle with a small coral dot. Shield-saved: ice-blue flame | Week view |
| Speech bubble | White, radius 18, 10px tail, 14 / 600, max 2 lines | Mascot messages |
| Bottom nav | Floating pill, 68 high, radius 34, translucent white with blur. Active tab: brand-500 icon on brand-100 pill. Center Log button: 60px circle, brand-500, white droplet icon, 6px brand-100 ring, raised 14px | Main navigation |
| Bottom sheet | Radius 28 top corners, grabber, dim overlay | Log, edit, feeling, slot detail |
| Toast | Ink-900 pill above nav, 5 seconds | Added amount with Undo |
| Segmented control | card-tint track, white selected pill | Week and Month |

## 6. Illustration style

### 6.1 Style summary

**Chunky soft-gloss vector.** Fill-only shapes (no outlines), rounded forms, two-stop gradients, one soft highlight per object, gentle contact shadows. Cute but clean, never childish clip-art and never realistic. Everything is drawn as inline SVG in code. No stock photos, no 3D renders, no external image generation.

### 6.2 Drawing rules

- **Shapes:** rounded and chunky. No sharp corners, no thin strokes, minimum visible detail is 4px at phone size.
- **Fills:** flat color or a two-stop vertical gradient from the palette. No textures, no noise, no patterns.
- **Highlight:** one white highlight at 35% opacity on the upper left of every main object.
- **Shadow:** soft ellipse under objects at ink-900 8% opacity. No hard drop shadows.
- **Outlines:** none. Exception: bubbles use a 1.5px white stroke at 60% opacity.
- **Color per scene:** brand blue and water tones plus at most one accent (orange, mint, or lavender).
- **Sparkles:** four-point stars, white at 70% opacity, 2 to 5 per scene, never more.
- **Backgrounds:** soft gradient (brand-50 to #CFE0FF) with faint diagonal light rays. Never busy.

### 6.3 The mascot (Sippy)

A chubby water droplet: round bottom, soft pointed top with a tiny curl, body gradient #5AA2FF to #3D6EF5, white highlight upper left, big glossy eyes (white ovals, navy pupils, white glint), pink cheek blush (#FF9DB5 at 40%), small smile, two stub arms. Head and body are one shape.

| Mood | When it appears | Face and body |
|---|---|---|
| happy | On pace | Open smile, eyes wide |
| hyped | Goal reached or ahead of pace | Big smile, arms up, sparkles |
| thirsty | 15% or more behind pace | Paler body, half-lidded eyes |
| worried | 2 missed reminders in a row | Small frown, raised brows |
| sleepy | Outside the day window | Closed eyes, floating z |
| cheeky | Playful nudges | One-eye wink, tongue out |
| proud | Streak milestones | Closed-eye smile, chest out |
| waving | Welcome and onboarding | One arm raised |

### 6.4 The glass

Tall tumbler shape. Liquid uses the liquid gradient (water-300 to brand-500) with two wave layers on the surface, the percent label riding the surface line, rising bubbles, and a few sparkles. Skins change only the container:

| Skin | Unlock | Shape |
|---|---|---|
| Classic | Default | Tapered tumbler |
| Mason Jar | 7-day streak | Wide jar with a ridged rim |
| Sports Bottle | 14-day streak | Bottle with a flip cap |
| Boba Cup | 30-day streak | Clear cup with dome lid and straw |

### 6.5 Other illustration pieces

- **Streak flame:** rounded teardrop flame, gradient flame-a to flame-b, small inner highlight. Shield-saved version is ice blue (water-300 to brand-400).
- **Badges:** 64px round medallion, two-stop gradient fill, white icon in the center, small sparkle on earned badges. Locked badges are ink-300 flat with a lock icon.
- **Drink icons:** one simple rounded glyph each (glass, bubbles for sparkling, mug for tea, cup for coffee, juice box, milk carton), flat color from the matching tile hue.
- **Empty states:** mascot in the fitting mood on the soft background, one sentence beneath. No other props.
- **Share card:** mascot on the soft blue background, progress ring, big number, streak flame, date, app name. No personal data.
- **App icon:** mascot face on a brand-500 gradient square, face kept inside the central 80% (safe zone for round and maskable icons).

### 6.5.1 Icons (UI)

Lucide-style outline icons, 24px, 1.75px stroke, round caps and joins. Filled only for the active nav tab and the flame. Custom droplet icon for the Log button.

## 7. Motion

| Moment | Behavior |
|---|---|
| Tap | Scale to 0.97 over 120ms |
| Log a drink | Droplet falls 500ms, liquid rises 1200ms (cubic-bezier .22,1,.36,1), number counts up, 6 to 10 bubbles, light vibration |
| Water wave | Two layers moving sideways in 4s and 6s loops, paused when hidden |
| Mascot idle | Gentle 3s bob, blink every 4 to 6 seconds |
| Goal reached | Liquid overflows slightly, 1.6s sparkle and droplet confetti, flame bounces |
| Screen change | 220ms fade plus 8px slide |

Animate only transform and opacity. With reduced-motion turned on: no wave, bob, or confetti, and instant state changes.

## 8. Voice and notification tone

**Voice:** Sippy speaks in short, friendly sentences. Encouraging, a little cheeky, never shaming, no medical claims.

**Tone setting (user picks):** Gentle, Playful (default), Coach.

**Rules:** title up to 60 characters, body up to 110, one emoji at most, no all caps, no guilt or threats.

| Case | Title | Body |
|---|---|---|
| Gentle | Sip time | A little water now keeps the afternoon easy. |
| Playful | Sippy is parched | 250 ml and I'll stop dramatically fainting. |
| Coach | Next 250 ml | You're 400 ml behind pace. Close the gap now. |
| Missed | Still here | No stress. I moved your plan: 2 small sips before 6. |
| Streak at risk | Day 12 is on the line | 600 ml to go. You've got time. |
| Pattern | I noticed something | Mornings are your best time. Let's front-load tomorrow. |
| Goal reached | You did it | Goal reached. That's day 13 in a row. |

**Escalation:** normal nudge, then one soft follow-up after 20 minutes if still open, then a kind worried message after 2 misses and an automatic plan shift. After 3 ignored pushes in a row, back off and offer fewer reminders.

**In-app mascot messages:** max 2 lines, change only when the app state changes (for example new drink logged, behind pace, goal reached).

## 9. Do and don't

**Do**
- Big numbers with small gray units.
- 20px screen padding and generous spacing.
- One main action per screen.
- Pastel tints to tell categories apart.
- Let the mascot show emotion instead of adding more text.

**Don't**
- More than 3 hues in one card.
- Gradient text, pure black, sharp corners.
- Dense tables or small gray-on-gray text.
- More than 4 tabs plus the center Log button.
- Permission pop-ups on first load.
- Red for anything except missed or delete.

## 10. Reference mapping (inspiration only, not copying)

| Reference | What we borrowed |
|---|---|
| Axius blue health app | Saturated blue brand, white cards, one filled hero card, floating pill nav with a centered round button |
| Foku mascot app | Chunky mascot, speech bubble, selected chip as filled pill, full-width navy CTA |
| Lena and Miuu Note streak screens | Uppercase greeting with name, flame streak row, today as filled circle, mascot message bubble, pastel cards |
| Hydration wave app | Liquid fill with percent label, bubbles, pastel quick-add tiles |
| Widget set | One color per metric, ring plus big number plus small unit |
| Green fitness app | Faded past bars with one solid highlighted bar |
