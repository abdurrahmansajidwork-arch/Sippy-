import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  Bell,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Plus,
  Shield,
  Sparkles,
  Sun,
  Trash2,
  WifiOff,
} from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import type { HydrationLog } from '../types';
import { DRINK_LABELS, formatVolume } from '../utils/patternEngine';
import { formatTimeShort, toDateKey } from '../utils/scheduleEngine';
import {
  DrinkGlyph,
  DropletLogoIcon,
  SmallGlassGauge,
  StreakFlame,
  TokenCoinIcon,
} from '../components/BrandIcons';
import { GlassFill } from '../components/GlassFill';
import { Mascot } from '../components/Mascot';
import {
  DeleteConfirmDialog,
  EditLogSheet,
  OverGoalWarningBadge,
} from '../components/Sheets';

const QUICK_ADD_TILES = [
  { ml: 250, fill: 0.65, bg: 'var(--tile-lav)', edge: 'var(--edge-lav)', variant: 'tumbler' as const },
  { ml: 300, fill: 0.78, bg: 'var(--tile-flame)', edge: 'var(--edge-flame)', variant: 'tumbler' as const },
  { ml: 500, fill: 0.9, bg: 'var(--tile-water)', edge: 'var(--edge-water)', variant: 'bottle' as const },
];

export const HomeScreen: React.FC<{
  onOpenStats?: () => void;
  onOpenSettings?: () => void;
}> = ({ onOpenStats, onOpenSettings }) => {
  const {
    profile,
    glasses,
    todayLogs,
    days,
    nextPendingSlot,
    effectiveGoalMl,
    todayTotalMl,
    boostReason,
    currentStreak,
    shieldsEarned,
    shieldSavedDates,
    tokens,
    sippyMood,
    sippyMessage,
    isLoggingAnim,
    showConfetti,
    fewerRemindersPrompt,
    dismissFewerRemindersPrompt,
    intakeWarningStatus,
    requestLogDrink,
    deleteLog,
    snoozeSlot,
    skipSlot,
    removeTodayBoosts,
    updateProfile,
    setLogSheetOpen,
    setReminderPreviewOpen,
  } = useSippy();

  const isOnline = useOnlineStatus();
  const [displayMl, setDisplayMl] = useState(todayTotalMl);
  const prevMlRef = useRef(todayTotalMl);
  const [glassPickerOpen, setGlassPickerOpen] = useState(false);
  const [editingLog, setEditingLog] = useState<HydrationLog | null>(null);
  const [deletingLog, setDeletingLog] = useState<HydrationLog | null>(null);
  const [mascotTapPing, setMascotTapPing] = useState(false);

  // Smooth number count-up over 1200ms
  useEffect(() => {
    const startVal = prevMlRef.current;
    const endVal = todayTotalMl;
    prevMlRef.current = endVal;
    if (startVal === endVal) {
      setDisplayMl(endVal);
      return;
    }

    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduced) {
      setDisplayMl(endVal);
      return;
    }

    const startTime = performance.now();
    const duration = 1200;
    let raf = 0;

    const tick = (now: number) => {
      const t = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplayMl(Math.round(startVal + (endVal - startVal) * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [todayTotalMl]);

  if (!profile) return null;

  const defaultGlass =
    glasses.find((g) => g.id === profile.defaultGlassId) ||
    glasses[0] || { id: 'default', uid: profile.uid, name: 'Glass', ml: 250, icon: 'tumbler' as const };

  const totalFmt = formatVolume(displayMl, profile.unit);
  const goalFmt = formatVolume(effectiveGoalMl, profile.unit);
  const defaultFmt = formatVolume(defaultGlass.ml, profile.unit);
  const remainingMl = Math.max(0, effectiveGoalMl - todayTotalMl);
  const remainingFmt = formatVolume(remainingMl, profile.unit);
  const excessFmt = formatVolume(intakeWarningStatus.excessOverGoalMl, profile.unit);
  const progressRatio = effectiveGoalMl > 0 ? todayTotalMl / effectiveGoalMl : 0;
  const pct = Math.min(999, Math.round(progressRatio * 100));

  const tapReplies = [
    'Keep those refreshing sips flowing!',
    'Every glass brings you closer to Dew Tokens!',
    'Stay cool, sip steady.',
    'Hydro high-five!',
  ];
  const [tapReplyIdx, setTapReplyIdx] = useState(0);

  const bubbleCopy =
    mascotTapPing
      ? tapReplies[tapReplyIdx % tapReplies.length]
      : todayTotalMl === 0
        ? 'Fresh day, ready for the first sip?'
        : sippyMessage;

  // Build 7-day strip (Mon..Sun around today)
  const todayKey = toDateKey(Date.now());
  const todayDate = new Date(`${todayKey}T12:00:00`);
  const dayOfWeek = todayDate.getDay();
  const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(todayDate);
    d.setDate(todayDate.getDate() + mondayOffset + i);
    const key = toDateKey(d.getTime());
    const summary = days.find((x) => x.date === key);
    const isToday = key === todayKey;
    const isFuture = key > todayKey;
    const isShieldSaved = Boolean(summary?.shieldUsed || shieldSavedDates.includes(key));
    const isHit = Boolean(summary?.hit) || (isToday && todayTotalMl >= effectiveGoalMl);
    return {
      key,
      label: ['M', 'T', 'W', 'T', 'F', 'S', 'S'][i],
      dayNum: d.getDate(),
      isToday,
      isFuture,
      isHit,
      isShieldSaved,
      isMissed: !isFuture && !isToday && !isHit && !isShieldSaved,
    };
  });

  const getLogBubbleStyle = (drinkType: HydrationLog['drinkType']) => {
    if (drinkType === 'tea') return { bg: 'var(--mint-100)', color: '#22B07D' };
    if (drinkType === 'coffee' || drinkType === 'juice') return { bg: 'var(--flame-tint)', color: '#FF6B2C' };
    return { bg: 'var(--water-100)', color: '#19B4F2' };
  };

  return (
    <div className="space-y-4">
      {/* Top Header: Clean Sippy brand + quiet Today badge + Streak pill */}
      <header className="flex items-center justify-between gap-2 pt-safe min-h-[44px]">
        <div className="shrink-0">
          <div className="flex items-center gap-2">
            <DropletLogoIcon size={22} className="text-[var(--brand-500)] shrink-0" />
            <h1 className="text-[21px] leading-none font-extrabold tracking-[-0.02em] text-[var(--ink-900)] whitespace-nowrap">
              Sippy
            </h1>
            <span className="px-2 py-0.5 rounded-[8px] bg-[var(--brand-50)] text-[var(--brand-600)] text-[12px] font-bold whitespace-nowrap">
              Today
            </span>
          </div>
          {!isOnline && (
            <p className="mt-1.5 inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--ink-700)] bg-[var(--card-tint)] px-2.5 py-1 rounded-full">
              <WifiOff size={13} />
              <span>Offline, will sync</span>
            </p>
          )}
        </div>

        <button
          type="button"
          onClick={onOpenStats}
          className="h-10 px-3 rounded-full bg-[var(--card)] sippy-card flex items-center gap-1.5 shrink-0 active:scale-95 transition-transform cursor-pointer"
        >
          <StreakFlame size={18} muted={currentStreak === 0} />
          <span className="text-[13.5px] font-extrabold text-[var(--ink-900)] sippy-num whitespace-nowrap">
            {currentStreak} day streak
          </span>
          <ChevronRight size={15} className="text-[var(--ink-300)] shrink-0" />
        </button>
      </header>

      {/* Hero Glass Card — Redesign Pass 2 Page 3 */}
      <section className="relative overflow-hidden rounded-[28px] bg-[var(--card)] sippy-card p-5">
        {/* Goal hit confetti droplets */}
        {showConfetti && (
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden z-20">
            {[14, 28, 44, 62, 78, 88].map((leftPct, i) => (
              <span
                key={leftPct}
                className="absolute bottom-8 w-3 h-3 rounded-full bg-[var(--water-500)]"
                style={{
                  left: `${leftPct}%`,
                  animation: `sippyConfetti 1.5s ease-out ${i * 80}ms forwards`,
                }}
              />
            ))}
          </div>
        )}

        {/* Top row: % readout + quiet Dew Tokens or Over-Goal Warning */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="text-[16px] font-extrabold text-[var(--brand-600)] sippy-num">
            {pct}%
          </span>
          {intakeWarningStatus.breaksTooMuch ? (
            <OverGoalWarningBadge
              excessMl={intakeWarningStatus.excessOverGoalMl}
              unit={profile.unit}
            />
          ) : (
            <button
              type="button"
              onClick={onOpenSettings}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[var(--amber-100)]/75 text-[12.5px] font-extrabold text-[#92400E] dark:text-[#FCD34D] sippy-num hover:opacity-90 active:scale-95 transition-transform cursor-pointer"
              title="Open Dew Tokens & Mystery Recipe Box in Settings"
            >
              <TokenCoinIcon size={17} />
              <span>{tokens} Dews</span>
            </button>
          )}
        </div>

        {/* Visual stage: Glass and Sippy grounded on shared floor baseline */}
        <div className="py-1 grid grid-cols-[112px_1fr] items-end gap-4">
          <div className="flex justify-center pb-0.5">
            <GlassFill
              level={progressRatio}
              skin={profile.activeSkin}
              isLogging={isLoggingAnim}
              goalHit={todayTotalMl >= effectiveGoalMl}
              size={108}
              showPercentInside={false}
            />
          </div>

          <div className="flex flex-col items-center justify-end gap-2.5 min-w-0">
            <motion.div
              key={bubbleCopy}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="relative bg-[var(--canvas)] border border-[var(--line)] rounded-[16px] px-3 py-2 text-center w-full"
            >
              <p className="text-[13px] leading-[17.5px] font-semibold text-[var(--ink-900)]">
                {bubbleCopy}
              </p>
              <div
                aria-hidden="true"
                className="absolute left-1/2 -translate-x-1/2 -bottom-[7px] w-3 h-3 bg-[var(--canvas)] border-r border-b border-[var(--line)] rotate-45"
              />
            </motion.div>

            <Mascot
              mood={sippyMood}
              persona={profile.tone}
              size={102}
              interactive
              autoCycleFaces
              cycleTrigger={todayLogs.length}
              onTap={() => {
                setTapReplyIdx((i) => i + 1);
                setMascotTapPing(true);
                window.setTimeout(() => setMascotTapPing(false), 1800);
              }}
            />
          </div>
        </div>

        {/* Bottom Metric Lockup + "to go" Tile */}
        <div className="mt-3 pt-3.5 border-t border-[var(--line)]/75 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-baseline gap-1.5">
              <span className="text-[38px] leading-[40px] font-extrabold text-[var(--ink-900)] sippy-num">
                {totalFmt.value}
              </span>
              <span className="text-[17px] font-bold text-[var(--ink-500)] sippy-num">
                {totalFmt.unitLabel}
              </span>
            </div>
            <p className="mt-0.5 text-[13.5px] font-semibold text-[var(--ink-500)] sippy-num">
              of {goalFmt.value} {goalFmt.unitLabel} goal
            </p>
          </div>

          <div
            className={`rounded-[16px] px-3.5 py-2 text-center shrink-0 border ${
              intakeWarningStatus.breaksTooMuch
                ? 'bg-[var(--amber-100)] border-[#FDE68A]'
                : todayTotalMl >= effectiveGoalMl
                  ? 'bg-[var(--mint-100)] border-[var(--edge-mint-tile)]'
                  : 'bg-[var(--brand-50)] border-[var(--brand-100)]'
            }`}
          >
            <p
              className={`text-[17px] leading-tight font-extrabold sippy-num ${
                intakeWarningStatus.breaksTooMuch
                  ? 'text-[#B45309] dark:text-[#FCD34D]'
                  : todayTotalMl >= effectiveGoalMl
                    ? 'text-[var(--mint-500)]'
                    : 'text-[var(--brand-600)]'
              }`}
            >
              {todayTotalMl >= effectiveGoalMl
                ? `+${excessFmt.value} ${excessFmt.unitLabel}`
                : `${remainingFmt.value} ${remainingFmt.unitLabel}`}
            </p>
            <p className="text-[11.5px] font-semibold text-[var(--ink-500)]">
              {intakeWarningStatus.breaksTooMuch
                ? 'over goal'
                : todayTotalMl >= effectiveGoalMl
                  ? 'goal met'
                  : 'to go'}
            </p>
          </div>
        </div>

        {/* Weather / Workout Boost Strip */}
        {boostReason && (
          <div className="mt-4 rounded-[14px] bg-[var(--card-tint)] px-3.5 py-2.5 flex items-center justify-between gap-2 text-xs font-semibold text-[var(--ink-700)]">
            <span className="flex items-center gap-2 tabular-nums">
              {boostReason.includes('hot day') ? (
                <Sun size={15} className="text-[#D97706] shrink-0" />
              ) : (
                <Sparkles size={15} className="text-[var(--mint-500)] shrink-0" />
              )}
              <span>Goal {boostReason} today</span>
            </span>
            <button
              type="button"
              onClick={() => void removeTodayBoosts()}
              className="text-[var(--brand-600)] font-bold min-h-[28px] px-1.5 cursor-pointer"
            >
              Remove
            </button>
          </div>
        )}
      </section>

      {/* Split Primary CTA — Design Pass 2 Page 3 */}
      <div className="relative">
        <div className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] flex items-stretch overflow-hidden sippy-press-ink">
          <button
            type="button"
            onClick={() =>
              void requestLogDrink({
                ml: defaultGlass.ml,
                glassId: defaultGlass.id,
                drinkType: 'water',
                source: 'app',
              })
            }
            className="flex-1 px-5 flex items-center justify-center gap-2.5 font-bold text-[17px] cursor-pointer focus-visible:outline-2 focus-visible:outline-[var(--brand-500)]"
          >
            <DropletLogoIcon size={19} />
            <span className="sippy-num">
              Drink {defaultFmt.value} {defaultFmt.unitLabel}
            </span>
          </button>

          <span aria-hidden="true" className="w-[1px] bg-[#26335A] my-2.5" />

          <button
            type="button"
            aria-label="Choose default glass"
            aria-expanded={glassPickerOpen}
            onClick={() => setGlassPickerOpen((v) => !v)}
            className="w-14 flex items-center justify-center cursor-pointer hover:bg-white/10"
          >
            {glassPickerOpen ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
          </button>
        </div>

        {glassPickerOpen && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-2.5 sippy-card rounded-[20px] p-2.5 grid grid-cols-2 gap-2"
          >
            {glasses.map((g) => {
              const isDef = g.id === defaultGlass.id;
              const fmt = formatVolume(g.ml, profile.unit);
              return (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => {
                    void updateProfile({ defaultGlassId: g.id });
                    setGlassPickerOpen(false);
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-[14px] flex items-center gap-2 text-left text-sm font-bold cursor-pointer ${
                    isDef
                      ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                      : 'bg-[var(--card-tint)] text-[var(--ink-700)]'
                  }`}
                >
                  <DrinkGlyph type={g.icon} size={18} color={isDef ? '#FFFFFF' : '#19B4F2'} />
                  <span className="truncate tabular-nums">
                    {fmt.value} {fmt.unitLabel} · {g.name}
                  </span>
                </button>
              );
            })}
          </motion.div>
        )}
      </div>

      {/* Next-Sip Card (The ONE saturated brand-500 block on Today) */}
      {nextPendingSlot && todayTotalMl < effectiveGoalMl && (
        <section className="rounded-[24px] sippy-blue-card text-white p-4 space-y-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setReminderPreviewOpen(true)}
                aria-label="Preview reminder alert"
                className="w-11 h-11 rounded-full bg-white/22 flex items-center justify-center shrink-0 hover:bg-white/30 active:scale-95 transition-transform cursor-pointer"
              >
                <Bell size={20} />
              </button>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-[16px] leading-tight font-bold text-white whitespace-nowrap">Next sip</p>
                  {nextPendingSlot.movedFrom && (
                    <span className="px-1.5 py-0.5 rounded-md bg-white/20 text-[10px] font-bold tracking-[0.02em] whitespace-nowrap">
                      Shifted
                    </span>
                  )}
                </div>
                <p className="mt-0.5 text-[25px] leading-[28px] font-extrabold sippy-num whitespace-nowrap">
                  {formatTimeShort(nextPendingSlot.notifyAt)}
                </p>
              </div>
            </div>

            <p className="text-[21px] font-extrabold sippy-num shrink-0">
              {formatVolume(nextPendingSlot.targetMl, profile.unit).value}{' '}
              {formatVolume(nextPendingSlot.targetMl, profile.unit).unitLabel}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => void snoozeSlot(nextPendingSlot.id, 15)}
              className="h-12 rounded-[16px] bg-white text-[#2F5BE0] font-bold text-[15px] sippy-press-white cursor-pointer"
            >
              Snooze
            </button>
            <button
              type="button"
              onClick={() => void skipSlot(nextPendingSlot.id)}
              className="h-12 rounded-[16px] bg-white text-[#2F5BE0] font-bold text-[15px] sippy-press-white cursor-pointer"
            >
              Skip
            </button>
          </div>
        </section>
      )}

      {/* 3-ignored-pushes gentle backoff prompt */}
      {fewerRemindersPrompt && (
        <div className="sippy-card rounded-[20px] p-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-bold text-[var(--ink-900)]">Want fewer reminders?</p>
            <p className="text-xs text-[var(--ink-500)]">
              Sippy noticed a busy stretch and can trim daily nudges.
            </p>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={dismissFewerRemindersPrompt}
              className="min-h-[40px] px-2.5 text-xs font-semibold text-[var(--ink-500)]"
            >
              Keep
            </button>
            <button
              type="button"
              onClick={() => {
                void updateProfile({ maxPushPerDay: Math.max(3, profile.maxPushPerDay - 2) });
                dismissFewerRemindersPrompt();
              }}
              className="min-h-[40px] px-3 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-bold"
            >
              Fewer
            </button>
          </div>
        </div>
      )}

      {/* QUICK ADD — 4 Pastel Tactile Tiles */}
      <section aria-label="Quick add glasses" className="pt-1">
        <h2 className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)] mb-2.5">
          QUICK ADD
        </h2>
        <div className="grid grid-cols-4 gap-2.5">
          {QUICK_ADD_TILES.map((tile) => {
            const fmt = formatVolume(tile.ml, profile.unit);
            return (
              <button
                key={tile.ml}
                type="button"
                onClick={() =>
                  void requestLogDrink({ ml: tile.ml, drinkType: 'water', source: 'app' })
                }
                className="h-[104px] rounded-[20px] px-1.5 py-3 flex flex-col items-center justify-between transition-transform active:translate-y-[2px] active:scale-[0.97] cursor-pointer"
                style={{
                  backgroundColor: tile.bg,
                  boxShadow: `0 4px 0 ${tile.edge}`,
                }}
              >
                <SmallGlassGauge fillLevel={tile.fill} size={26} variant={tile.variant} />
                <span className="text-[15px] font-extrabold text-[var(--ink-900)] sippy-num">
                  {fmt.value}{' '}
                  <span className="text-[12px] font-bold text-[var(--ink-500)]">
                    {fmt.unitLabel}
                  </span>
                </span>
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setLogSheetOpen(true)}
            className="h-[104px] rounded-[20px] px-1.5 py-3 bg-[var(--card-tint)] border-2 border-dashed border-[#C3CCDD] flex flex-col items-center justify-between text-[var(--ink-700)] active:scale-[0.97] transition-transform cursor-pointer"
          >
            <span className="mt-1 w-8 h-8 rounded-full bg-[var(--card)] flex items-center justify-center text-[var(--ink-700)]">
              <Plus size={18} strokeWidth={2.5} />
            </span>
            <span className="text-[13px] font-bold text-[var(--ink-700)]">Custom</span>
          </button>
        </div>
      </section>

      {/* THIS WEEK — 7-day Flame Streak Row */}
      <section className="pt-1" aria-label="Weekly streak">
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
            THIS WEEK
          </h2>
          <div className="flex items-center gap-2">
            {shieldsEarned > 0 && (
              <span
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[var(--water-100)] text-[var(--brand-600)] text-[11.5px] font-bold tabular-nums"
                title="Streak Shields available"
              >
                <Shield size={12} />
                {shieldsEarned}
              </span>
            )}
            <span className="text-[13px] font-bold text-[var(--brand-600)] tabular-nums">
              {currentStreak}-day streak
            </span>
          </div>
        </div>

        <div className="sippy-card rounded-[24px] p-4">
          <div className="grid grid-cols-7 gap-1 text-center">
            {weekDays.map((d) => (
              <div key={d.key} className="flex flex-col items-center gap-1.5">
                <span className="text-[11px] font-bold text-[var(--ink-500)]">{d.label}</span>
                <div className="relative w-10 h-10 flex items-center justify-center">
                  {d.isHit || d.isShieldSaved ? (
                    <>
                      <span aria-hidden="true" className="absolute inset-0 flex items-center justify-center">
                        <StreakFlame size={40} shieldSaved={d.isShieldSaved} />
                      </span>
                      <span className="relative z-10 text-[12px] font-extrabold text-white tabular-nums pt-2 drop-shadow-[0_1px_2px_rgba(0,0,0,0.35)]">
                        {d.dayNum}
                      </span>
                    </>
                  ) : d.isToday ? (
                    <div
                      className="w-10 h-10 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center text-[13px] font-extrabold tabular-nums"
                      style={{ boxShadow: '0 3px 0 var(--edge-brand)' }}
                    >
                      {d.dayNum}
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-[var(--card)] border-[1.5px] border-[var(--line)] flex items-center justify-center text-[12px] font-bold text-[var(--ink-300)] tabular-nums">
                      {d.dayNum}
                    </div>
                  )}
                </div>
                {d.isMissed ? (
                  <span className="w-1.5 h-1.5 rounded-full bg-[var(--coral-500)]" aria-label="Missed goal" />
                ) : (
                  <span className="w-1.5 h-1.5" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TODAY'S LOG */}
      <section className="pt-1">
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
            TODAY’S LOG
          </h2>
          <span className="text-[13px] font-semibold text-[var(--ink-500)] tabular-nums">
            {todayLogs.length} {todayLogs.length === 1 ? 'drink' : 'drinks'}
          </span>
        </div>

        <div className="sippy-card rounded-[24px] overflow-hidden">
          {todayLogs.length === 0 ? (
            <div className="py-6 px-4 text-center flex flex-col items-center">
              <Mascot mood="happy" persona={profile.tone} size={68} />
              <p className="mt-2 text-[14px] font-semibold text-[var(--ink-500)]">
                Nothing yet today
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-[var(--line)]">
              {todayLogs.map((item) => {
                const fmt = formatVolume(item.ml, profile.unit);
                const bubble = getLogBubbleStyle(item.drinkType);
                return (
                  <li key={item.id} className="flex items-center justify-between px-4 py-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingLog(item)}
                      className="flex-1 min-h-[44px] flex items-center justify-between gap-3 text-left cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className="w-11 h-11 rounded-[14px] flex items-center justify-center shrink-0"
                          style={{ backgroundColor: bubble.bg }}
                        >
                          <DrinkGlyph type={item.drinkType} size={20} color={bubble.color} />
                        </span>
                        <div className="min-w-0">
                          <p className="text-[17px] font-extrabold text-[var(--ink-900)] sippy-num leading-tight">
                            {fmt.value}{' '}
                            <span className="text-[13px] font-semibold text-[var(--ink-500)]">
                              {fmt.unitLabel}
                            </span>
                          </p>
                          <p className="text-[13px] font-medium text-[var(--ink-500)]">
                            {DRINK_LABELS[item.drinkType]}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-[13px] font-bold text-[var(--ink-500)] sippy-num">
                          {formatTimeShort(item.ts)}
                        </span>
                        <ChevronRight size={16} className="text-[var(--ink-300)]" />
                      </div>
                    </button>

                    <button
                      type="button"
                      aria-label={`Delete ${fmt.value} ${fmt.unitLabel} ${DRINK_LABELS[item.drinkType]}`}
                      onClick={() => setDeletingLog(item)}
                      className="min-w-[40px] min-h-[44px] rounded-xl flex items-center justify-center text-[var(--ink-300)] hover:text-[var(--coral-500)] hover:bg-[var(--coral-100)] transition-colors cursor-pointer"
                    >
                      <Trash2 size={17} />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      <EditLogSheet log={editingLog} onClose={() => setEditingLog(null)} />

      <DeleteConfirmDialog
        open={Boolean(deletingLog)}
        title={
          deletingLog
            ? `Delete ${deletingLog.ml} ml ${DRINK_LABELS[deletingLog.drinkType]}?`
            : 'Delete drink?'
        }
        description="Are you sure you want to remove this drink from today’s hydration log?"
        confirmLabel="Delete drink"
        onCancel={() => setDeletingLog(null)}
        onConfirm={async () => {
          if (deletingLog) {
            await deleteLog(deletingLog.id);
          }
          setDeletingLog(null);
        }}
      />
    </div>
  );
};
