import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { ChevronDown, Lock, RefreshCw, Share2 } from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import type { GlassSkin } from '../types';
import { formatVolume } from '../utils/patternEngine';
import { toDateKey } from '../utils/scheduleEngine';
import { generateShareCardBlob } from '../utils/shareCard';
import { BadgeMedallion } from '../components/Achievements';
import {
  DropletLogoIcon,
  RewardChestIcon,
  StarNodeIcon,
  StreakFlame,
} from '../components/BrandIcons';
import { GlassFill } from '../components/GlassFill';
import { Mascot } from '../components/Mascot';

const SKINS: { id: GlassSkin; label: string; req: string }[] = [
  { id: 'classic', label: 'Classic', req: 'Default' },
  { id: 'mason', label: 'Mason Jar', req: '7-day streak' },
  { id: 'sports', label: 'Sports Bottle', req: '14-day streak' },
  { id: 'boba', label: 'Boba Cup', req: '30-day streak' },
];

// Duolingo-style S-curve horizontal offsets (px) for the 7-day path
const PATH_OFFSETS = [-14, 34, 62, 24, -24, -56, -24];

export const StatsScreen: React.FC = () => {
  const {
    profile,
    days,
    todayTotalMl,
    effectiveGoalMl,
    currentStreak,
    bestStreak,
    goalHitRate,
    avgDailyMl,
    achievementBadges,
    unlockedSkins,
    pattern,
    patternStats,
    aiLoading,
    aiError,
    refreshAIInsight,
    updateProfile,
    setFeelingSheetOpen,
  } = useSippy();

  const [range, setRange] = useState<'week' | 'month'>('week');
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [sharing, setSharing] = useState(false);

  const chartDays = useMemo(() => {
    const count = range === 'week' ? 7 : 14;
    const todayKey = toDateKey(Date.now());
    const base = new Date(`${todayKey}T12:00:00`);
    const list = [];
    for (let i = count - 1; i >= 0; i--) {
      const d = new Date(base);
      d.setDate(base.getDate() - i);
      const dk = toDateKey(d.getTime());
      const summary = days.find((x) => x.date === dk);
      const goal = summary?.goalMl || effectiveGoalMl || profile?.goalMl || 2500;
      const total = dk === todayKey ? todayTotalMl : (summary?.totalMl ?? 0);
      const pct = Math.min(120, Math.round((total / Math.max(1, goal)) * 100));
      const hit = Boolean(summary?.hit) || total >= goal;
      list.push({
        date: dk,
        isToday: dk === todayKey,
        hit,
        weekdayShort: d.toLocaleDateString([], { weekday: 'short' }).slice(0, 3),
        dayNum: d.getDate(),
        monthDayLabel: d.toLocaleDateString([], { month: 'short', day: 'numeric' }).toUpperCase(),
        total,
        goal,
        pct,
      });
    }
    return list;
  }, [range, days, profile?.goalMl, todayTotalMl, effectiveGoalMl]);

  const feelingStats = useMemo(() => {
    const allFeelings = days.flatMap((d) => d.feelings || []);
    const totalCount = allFeelings.length;
    const byLevel: Record<string, { sum: number; count: number }> = {
      drained: { sum: 0, count: 0 },
      okay: { sum: 0, count: 0 },
      good: { sum: 0, count: 0 },
      great: { sum: 0, count: 0 },
    };
    for (const f of allFeelings) {
      if (byLevel[f.level]) {
        byLevel[f.level].sum += f.totalMlAtCheckin;
        byLevel[f.level].count += 1;
      }
    }
    return { totalCount, byLevel };
  }, [days]);

  if (!profile) return null;

  const weekDays = chartDays.slice(-7);
  const weekHits = weekDays.filter((d) => d.hit).length;
  const dateRangeLabel =
    weekDays.length >= 2
      ? `${weekDays[0].monthDayLabel} – ${weekDays[weekDays.length - 1].dayNum}`
      : 'THIS WEEK';

  const bestDayItem = weekDays.reduce(
    (best, d) => (d.total > best.total ? d : best),
    weekDays[0] || { total: todayTotalMl, weekdayShort: 'Today' }
  );

  const nextMilestone = currentStreak < 7 ? 7 : currentStreak < 14 ? 14 : 30;
  const activeIdx = selectedIdx !== null && chartDays[selectedIdx] ? selectedIdx : chartDays.length - 1;
  const activeDay = chartDays[activeIdx];
  const avgFmt = formatVolume(avgDailyMl, profile.unit);
  const formatLitres = (ml: number) => `${(ml / 1000).toFixed(1)} L`;

  const insightText =
    pattern?.insight ||
    (patternStats.hasEnoughData
      ? `Your strongest day is ${patternStats.bestWeekday}, usually starting around ${patternStats.usualFirstDrink}.`
      : 'Keep logging for 3 days so Sippy can map your easiest hydration windows.');

  const handleShare = async () => {
    setSharing(true);
    try {
      const blob = await generateShareCardBlob({
        totalMl: todayTotalMl,
        goalMl: effectiveGoalMl,
        streak: Math.max(1, currentStreak),
        unit: profile.unit,
        dateLabel: toDateKey(Date.now()),
      });
      const file = new File([blob], `sippy-${toDateKey(Date.now())}.png`, { type: 'image/png' });
      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({ title: 'Sippy Progress', files: [file] });
      } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sippy-${toDateKey(Date.now())}.png`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } finally {
      setSharing(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header: "Your week" + Week/Month switcher */}
      <header className="pt-safe flex items-center justify-between gap-2 min-h-[44px]">
        <h1 className="text-[26px] leading-[32px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
          {range === 'week' ? 'Your week' : 'Your month'}
        </h1>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setRange((r) => (r === 'week' ? 'month' : 'week'));
              setSelectedIdx(null);
            }}
            className="h-10 px-3.5 rounded-full bg-[var(--card-tint)] text-[var(--ink-900)] text-[14px] font-bold flex items-center gap-1 sippy-press-tint cursor-pointer"
          >
            <span className="capitalize">{range}</span>
            <ChevronDown size={15} />
          </button>

          <button
            type="button"
            onClick={() => void handleShare()}
            disabled={sharing}
            aria-label="Share progress card"
            className="h-10 px-3 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <Share2 size={14} />
            <span>{sharing ? '...' : 'Share'}</span>
          </button>
        </div>
      </header>

      {range === 'week' ? (
        <>
          {/* Navy Headline Banner with Cheering Mascot */}
          <section
            className="rounded-[24px] bg-[#0B1633] text-white px-5 py-4 flex items-center justify-between gap-3 overflow-hidden"
            style={{ boxShadow: '0 4px 0 #040A1A' }}
          >
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-[#A3AECB]">
                {dateRangeLabel}
              </p>
              <p className="mt-1 text-[26px] leading-[30px] font-extrabold sippy-num">
                {weekHits} of 7 goals hit
              </p>
              <p className="mt-1 text-[12.5px] font-semibold text-[#C7D2FE]">
                {weekHits >= 5
                  ? 'Strong weekly momentum!'
                  : weekHits > 0
                    ? 'Keep stacking daily wins'
                    : 'Your next goal starts today'}
              </p>
            </div>

            <div className="shrink-0 flex items-center justify-center">
              <Mascot mood="hyped" persona={profile.tone} size={84} hideShadow interactive />
            </div>
          </section>

          {/* Duolingo-style Zig-Zag 7-Day Path + Cheering Sippy + Chest */}
          <section className="relative py-2 flex flex-col items-center">
            <div className="w-full space-y-4 relative">
              {/* Subtle dashed S-curve path connecting nodes */}
              <svg
                aria-hidden="true"
                viewBox="0 0 320 500"
                className="pointer-events-none absolute left-1/2 -translate-x-1/2 top-4 w-[320px] h-[calc(100%-32px)] overflow-visible"
              >
                <path
                  d="M 180 28 C 235 88, 262 146, 224 220 C 186 294, 114 338, 128 456"
                  fill="none"
                  stroke="#DCE5F8"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray="6 10"
                />
              </svg>

              {weekDays.map((day, idx) => {
                const offset = PATH_OFFSETS[idx] ?? 0;
                const labelOnLeft = idx < 5;
                return (
                  <motion.div
                    key={day.date}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05, duration: 0.28 }}
                    className="flex items-center justify-center relative z-10"
                    style={{ transform: `translateX(${offset}px)` }}
                  >
                    {labelOnLeft && (
                      <div className="w-[74px] text-right pr-3">
                        <p className="text-[12px] font-bold text-[var(--ink-500)]">
                          {day.isToday ? 'Today' : day.weekdayShort}
                        </p>
                        <p className="text-[16px] font-extrabold text-[var(--ink-900)] sippy-num">
                          {formatLitres(day.total)}
                        </p>
                      </div>
                    )}

                    {/* 60px Path Node */}
                    {day.hit ? (
                      <div
                        className="w-[60px] h-[60px] rounded-full bg-[var(--mint-500)] text-white flex items-center justify-center shrink-0"
                        style={{ boxShadow: '0 6px 0 var(--edge-mint)' }}
                        aria-label={`${day.weekdayShort} goal hit ${formatLitres(day.total)}`}
                      >
                        <StarNodeIcon size={26} />
                      </div>
                    ) : day.isToday ? (
                      <div
                        className="w-[60px] h-[60px] rounded-full bg-white border-[4px] border-[var(--brand-500)] text-[var(--brand-500)] flex items-center justify-center shrink-0"
                        style={{ boxShadow: '0 6px 0 var(--edge-today)' }}
                        aria-label={`Today ${formatLitres(day.total)}`}
                      >
                        <DropletLogoIcon size={22} />
                      </div>
                    ) : (
                      <div
                        className="w-[60px] h-[60px] rounded-full bg-white border-[3px] border-[var(--line)] text-[var(--ink-300)] flex items-center justify-center shrink-0"
                        style={{ boxShadow: '0 5px 0 var(--edge-tint)' }}
                        aria-label={`${day.weekdayShort} ${formatLitres(day.total)}`}
                      >
                        <DropletLogoIcon size={20} />
                      </div>
                    )}

                    {!labelOnLeft && (
                      <div className="w-[74px] text-left pl-3">
                        <p className="text-[12px] font-bold text-[var(--ink-500)]">
                          {day.isToday ? 'Today' : day.weekdayShort}
                        </p>
                        <p className="text-[16px] font-extrabold text-[var(--ink-900)] sippy-num">
                          {formatLitres(day.total)}
                        </p>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>

            {/* Reward Chest at Path End */}
            <div className="mt-5 flex items-center gap-3.5 px-4 py-2">
              <RewardChestIcon size={40} />
              <div>
                <p className="text-[12px] font-semibold text-[var(--ink-500)]">Next reward</p>
                <p className="text-[17px] font-extrabold text-[var(--ink-900)] tabular-nums">
                  {nextMilestone}-day streak
                </p>
              </div>
            </div>
          </section>

          {/* 2 Bottom Metric Tiles — Daily average (saturated blue) + Best day (warm amber-flame tint) */}
          <section className="grid grid-cols-2 gap-3">
            <div
              className="rounded-[24px] sippy-blue-card text-white p-4 flex flex-col justify-between min-h-[124px]"
              style={{ boxShadow: '0 4px 0 var(--edge-brand)' }}
            >
              <p className="text-[16px] font-extrabold text-white">Daily average</p>
              <p className="text-[36px] leading-none font-extrabold sippy-num">
                {(avgDailyMl / 1000).toFixed(1)}{' '}
                <span className="text-[17px] font-bold text-[var(--brand-100)]">L</span>
              </p>
            </div>

            <div className="sippy-flame-card rounded-[24px] p-4 flex flex-col justify-between min-h-[124px]">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[16px] font-extrabold text-[var(--ink-900)]">Best day</p>
                <span className="w-9 h-9 rounded-full bg-white/85 flex items-center justify-center shrink-0">
                  <StreakFlame size={20} />
                </span>
              </div>
              <p className="text-[30px] leading-none font-extrabold text-[var(--ink-900)] sippy-num">
                {(bestDayItem.total / 1000).toFixed(1)}{' '}
                <span className="text-[13.5px] font-bold text-[var(--ink-500)]">
                  L · {bestDayItem.isToday ? 'Today' : bestDayItem.weekdayShort}
                </span>
              </p>
            </div>
          </section>
        </>
      ) : (
        <>
          {/* Month Detailed Bar Chart + 3 Stat Rings */}
          <section className="sippy-card rounded-[24px] p-4">
            <div className="flex items-baseline justify-between mb-3">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
                  {activeDay.date}
                </p>
                <p className="text-xl font-extrabold text-[var(--ink-900)] tabular-nums">
                  {formatVolume(activeDay.total, profile.unit).value}{' '}
                  <span className="text-sm font-medium text-[var(--ink-500)]">
                    {formatVolume(activeDay.total, profile.unit).unitLabel}
                  </span>
                </p>
              </div>
              <span className="text-xs font-bold text-[var(--brand-600)] tabular-nums">
                {activeDay.pct}% of goal
              </span>
            </div>

            <svg
              viewBox={`0 0 ${chartDays.length * 44} 146`}
              className="w-full h-40 overflow-visible"
              role="img"
              aria-label="Hydration history bar chart"
            >
              <defs>
                <pattern
                  id="sippy-hatch"
                  width="6"
                  height="6"
                  patternTransform="rotate(45 0 0)"
                  patternUnits="userSpaceOnUse"
                >
                  <line x1="0" y1="0" x2="0" y2="6" stroke="#8A93A6" strokeOpacity="0.4" strokeWidth="2.5" />
                </pattern>
              </defs>

              <line
                x1="4"
                y1="28"
                x2={chartDays.length * 44 - 4}
                y2="28"
                stroke="var(--line)"
                strokeDasharray="3 3"
                strokeWidth="1"
              />

              {chartDays.map((day, idx) => {
                const x = idx * 44 + 8;
                const maxH = 84;
                const barH = Math.max(8, Math.round((Math.min(105, day.pct) / 100) * maxH));
                const y = 112 - barH;
                const isSelected = idx === activeIdx;

                return (
                  <g key={day.date} className="cursor-pointer" onClick={() => setSelectedIdx(idx)}>
                    <text
                      x={x + 14}
                      y={y - 7}
                      textAnchor="middle"
                      fontSize="10"
                      fontWeight="700"
                      fill={isSelected ? 'var(--brand-600)' : 'var(--ink-500)'}
                      className="sippy-num"
                    >
                      {day.pct}%
                    </text>
                    <rect
                      x={x}
                      y={y}
                      width="28"
                      height={barH}
                      rx="10"
                      fill={isSelected ? 'var(--brand-500)' : 'url(#sippy-hatch)'}
                    />
                    <text
                      x={x + 14}
                      y={134}
                      textAnchor="middle"
                      fontSize="11"
                      fontWeight={isSelected ? '700' : '500'}
                      fill={isSelected ? 'var(--ink-900)' : 'var(--ink-500)'}
                      className="sippy-num"
                    >
                      {day.dayNum}
                    </text>
                  </g>
                );
              })}
            </svg>
          </section>

          <section className="grid grid-cols-3 gap-2.5">
            <div className="sippy-card rounded-[24px] p-3.5 flex flex-col justify-between">
              <svg width="36" height="36" viewBox="0 0 44 44" aria-hidden="true">
                <circle cx="22" cy="22" r="16" stroke="var(--water-100)" strokeWidth="5.5" fill="none" />
                <circle
                  cx="22"
                  cy="22"
                  r="16"
                  stroke="var(--water-500)"
                  strokeWidth="5.5"
                  strokeLinecap="round"
                  fill="none"
                  strokeDasharray={`${Math.min(100, Math.round((avgDailyMl / Math.max(1, profile.goalMl)) * 100))} 100`}
                  transform="rotate(-90 22 22)"
                />
              </svg>
              <div className="mt-2">
                <p className="text-[19px] font-extrabold text-[var(--ink-900)] tabular-nums leading-tight">
                  {avgFmt.value}
                  <span className="ml-1 text-xs font-medium text-[var(--ink-500)]">{avgFmt.unitLabel}</span>
                </p>
                <p className="text-[11px] font-semibold text-[var(--ink-500)]">Avg / day</p>
              </div>
            </div>

            <div className="sippy-card rounded-[24px] p-3.5 flex flex-col justify-between">
              <span className="w-9 h-9 rounded-full bg-[var(--flame-tint)] flex items-center justify-center">
                <StreakFlame size={22} />
              </span>
              <div className="mt-2">
                <p className="text-[19px] font-extrabold text-[var(--ink-900)] tabular-nums leading-tight">
                  {bestStreak}
                  <span className="ml-1 text-xs font-medium text-[var(--ink-500)]">days</span>
                </p>
                <p className="text-[11px] font-semibold text-[var(--ink-500)]">Best streak</p>
              </div>
            </div>

            <div className="sippy-card rounded-[24px] p-3.5 flex flex-col justify-between">
              <svg width="36" height="36" viewBox="0 0 44 44" aria-hidden="true">
                <circle cx="22" cy="22" r="16" stroke="var(--mint-100)" strokeWidth="5.5" fill="none" />
                <circle
                  cx="22"
                  cy="22"
                  r="16"
                  stroke="var(--mint-500)"
                  strokeWidth="5.5"
                  strokeLinecap="round"
                  fill="none"
                  strokeDasharray={`${goalHitRate} 100`}
                  transform="rotate(-90 22 22)"
                />
              </svg>
              <div className="mt-2">
                <p className="text-[19px] font-extrabold text-[var(--ink-900)] tabular-nums leading-tight">
                  {goalHitRate}
                  <span className="ml-0.5 text-xs font-medium text-[var(--ink-500)]">%</span>
                </p>
                <p className="text-[11px] font-semibold text-[var(--ink-500)]">Goal hit rate</p>
              </div>
            </div>
          </section>
        </>
      )}

      {/* Mint-Tinted Sippy Noticed Pattern Coach Card */}
      <section className="sippy-mint-card rounded-[24px] p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <Mascot mood="thinking" persona={profile.tone} size={44} hideShadow />
            <div className="min-w-0">
              <h2 className="text-[17px] leading-tight font-extrabold text-[var(--ink-900)]">
                Sippy noticed
              </h2>
              <p className="text-[11.5px] font-bold text-[var(--mint-500)]">
                Pattern coach
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void refreshAIInsight()}
            disabled={aiLoading}
            className="min-h-[38px] px-3.5 rounded-[14px] bg-[var(--card)] text-[var(--ink-900)] text-xs font-extrabold flex items-center gap-1.5 sippy-press-tint cursor-pointer shrink-0"
          >
            <RefreshCw size={13} className={aiLoading ? 'animate-spin text-[var(--mint-500)]' : 'text-[var(--mint-500)]'} />
            <span>{aiLoading ? 'Updating...' : 'Refresh'}</span>
          </button>
        </div>

        <div className="rounded-[16px] bg-[var(--card)]/92 p-3.5">
          <p className="text-[14px] font-semibold leading-relaxed text-[var(--ink-900)]">{insightText}</p>
          {aiError && (
            <p className="mt-1.5 text-xs text-[var(--ink-500)]">
              Using built-in pattern rules right now.
            </p>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 text-xs pt-0.5">
          <div className="rounded-[12px] bg-[var(--card)]/70 px-2.5 py-2">
            <p className="text-[11px] font-semibold text-[var(--ink-500)]">Best day</p>
            <p className="mt-0.5 font-extrabold text-[var(--ink-900)]">{patternStats.bestWeekday}</p>
          </div>
          <div className="rounded-[12px] bg-[var(--card)]/70 px-2.5 py-2">
            <p className="text-[11px] font-semibold text-[var(--ink-500)]">First sip</p>
            <p className="mt-0.5 font-extrabold text-[var(--ink-900)] sippy-num">{patternStats.usualFirstDrink}</p>
          </div>
          <div className="rounded-[12px] bg-[var(--card)]/70 px-2.5 py-2">
            <p className="text-[11px] font-semibold text-[var(--ink-500)]">Push reply</p>
            <p className="mt-0.5 font-extrabold text-[var(--ink-900)] sippy-num">
              {patternStats.medianResponseMin !== null ? `${patternStats.medianResponseMin}m` : '—'}
            </p>
          </div>
        </div>
      </section>

      {/* Feeling Check-In Card */}
      <section className="rounded-[24px] bg-[var(--card)] sippy-card p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-[17px] font-bold text-[var(--ink-900)]">How hydration feels</h2>
          <button
            type="button"
            onClick={() => setFeelingSheetOpen(true)}
            className="text-xs font-bold text-[var(--brand-600)] min-h-[36px] px-2 cursor-pointer"
          >
            Check in
          </button>
        </div>

        {feelingStats.totalCount >= 10 ? (
          <div className="mt-3 grid grid-cols-4 gap-2 text-center">
            {(['drained', 'okay', 'good', 'great'] as const).map((lvl) => {
              const bucket = feelingStats.byLevel[lvl];
              const avg = bucket.count > 0 ? Math.round(bucket.sum / bucket.count) : 0;
              return (
                <div key={lvl} className="rounded-2xl bg-[var(--lav-100)] p-2.5">
                  <p className="text-xs font-bold capitalize text-[var(--ink-900)]">{lvl}</p>
                  <p className="mt-1 text-sm font-extrabold text-[var(--lav-500)] tabular-nums">
                    {avg > 0 ? `${avg} ml` : '—'}
                  </p>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="mt-1.5 text-sm text-[var(--ink-500)]">
            {feelingStats.totalCount} of 10 check-ins logged. Keep checking in after drinks to unlock your mood vs. intake card.
          </p>
        )}
      </section>

      {/* Glass Skins */}
      <section className="sippy-card rounded-[24px] p-4">
        <h2 className="text-[17px] font-bold text-[var(--ink-900)] mb-3">Glass skins</h2>
        <div className="grid grid-cols-2 gap-2.5">
          {SKINS.map((s) => {
            const unlocked = unlockedSkins.includes(s.id);
            const equipped = profile.activeSkin === s.id;
            return (
              <button
                key={s.id}
                type="button"
                disabled={!unlocked}
                onClick={() => unlocked && void updateProfile({ activeSkin: s.id })}
                className={`rounded-[20px] p-3 flex items-center gap-2.5 text-left border-2 transition-colors cursor-pointer ${
                  equipped
                    ? 'border-[var(--brand-500)] bg-[var(--brand-50)]'
                    : 'border-transparent bg-[var(--canvas)]'
                } ${!unlocked ? 'opacity-60 cursor-not-allowed' : ''}`}
              >
                <GlassFill level={0.65} skin={s.id} size={44} />
                <div className="min-w-0">
                  <p className="text-[13px] leading-tight font-bold text-[var(--ink-900)]">{s.label}</p>
                  <p className="mt-0.5 text-[11px] font-semibold text-[var(--ink-500)] flex items-center gap-1">
                    {!unlocked && <Lock size={10} />}
                    <span>{equipped ? 'Equipped' : s.req}</span>
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Badges Grid */}
      <section className="sippy-card rounded-[24px] p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-[17px] font-bold text-[var(--ink-900)]">Badges</h2>
          <span className="text-xs font-extrabold text-[var(--brand-600)] sippy-num">
            {achievementBadges.filter((b) => b.unlocked).length} / {achievementBadges.length} unlocked
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2.5">
          {achievementBadges.slice(0, 6).map((b) => (
            <div
              key={b.id}
              className={`rounded-[20px] p-3 flex flex-col items-center text-center border ${
                b.unlocked
                  ? 'bg-[var(--brand-50)]/70 border-[var(--brand-100)]'
                  : 'bg-[var(--canvas)] border-[var(--line)]'
              }`}
            >
              <BadgeMedallion icon={b.icon} palette={b.palette} unlocked={b.unlocked} size={52} />
              <p className="mt-2 text-xs font-extrabold text-[var(--ink-900)]">{b.title}</p>
              <p
                className={`mt-0.5 text-[10px] font-bold leading-tight sippy-num ${
                  b.unlocked ? 'text-[var(--mint-500)]' : 'text-[var(--ink-500)]'
                }`}
              >
                {b.unlocked ? 'Unlocked' : `${b.currentValue}/${b.targetValue} ${b.unitLabel}`}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
