import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bell, Check, Clock, Dumbbell, RotateCw, XCircle } from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import type { ReminderSlot } from '../types';
import { formatVolume } from '../utils/patternEngine';
import { formatTimeShort } from '../utils/scheduleEngine';
import { Mascot } from '../components/Mascot';
import { SlotDetailSheet } from '../components/Sheets';

export const PlanScreen: React.FC = () => {
  const {
    profile,
    todaySlots,
    toggleWorkoutBoost,
    setLogSheetOpen,
    setReminderPreviewOpen,
  } = useSippy();

  const [selectedSlot, setSelectedSlot] = useState<ReminderSlot | null>(null);

  if (!profile) return null;

  const workoutActive = profile.workoutBoostMl > 0;

  return (
    <div className="space-y-5">
      <header className="pt-safe flex items-center justify-between gap-3 min-h-[44px]">
        <div>
          <h1 className="text-[26px] leading-[32px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
            Plan
          </h1>
          <p className="mt-0.5 text-[13px] font-medium text-[var(--ink-500)]">
            Adaptive sips for today
          </p>
        </div>

        <button
          type="button"
          onClick={() => setReminderPreviewOpen(true)}
          className="h-10 px-3.5 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <Bell size={14} />
          <span>Preview alert</span>
        </button>
      </header>

      {/* Workout Boost Card */}
      <section
        className={`rounded-[24px] p-4 flex items-center justify-between gap-3 transition-colors ${
          workoutActive ? 'sippy-mint-card' : 'sippy-card'
        }`}
      >
        <div className="flex items-center gap-3">
          <span
            className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${
              workoutActive
                ? 'bg-[var(--mint-500)] text-white'
                : 'bg-[var(--brand-50)] text-[var(--brand-500)]'
            }`}
          >
            <Dumbbell size={20} />
          </span>
          <div>
            <p className="text-[16px] font-extrabold text-[var(--ink-900)]">Workout today?</p>
            <p className="text-xs text-[var(--ink-500)] sippy-num">
              Adds +{formatVolume(500, profile.unit).value} {formatVolume(500, profile.unit).unitLabel} to your goal
            </p>
          </div>
        </div>

        <button
          type="button"
          role="switch"
          aria-checked={workoutActive}
          aria-label="Toggle workout hydration boost"
          onClick={() => void toggleWorkoutBoost()}
          className={`relative w-14 h-8 rounded-full transition-colors shrink-0 cursor-pointer ${
            workoutActive ? 'bg-[var(--mint-500)]' : 'bg-[var(--card-tint)]'
          }`}
        >
          <span
            className={`absolute top-1 left-1 w-6 h-6 rounded-full bg-white shadow-sm transition-transform ${
              workoutActive ? 'translate-x-6' : 'translate-x-0'
            }`}
          />
        </button>
      </section>

      {/* Vertical Timeline */}
      {todaySlots.length === 0 ? (
        <div className="sippy-card rounded-[24px] p-8 text-center flex flex-col items-center">
          <Mascot mood="hyped" persona={profile.tone} size={88} />
          <p className="mt-3 text-[15px] font-medium text-[var(--ink-700)]">
            Your planned slots are all wrapped up for today.
          </p>
          <button
            type="button"
            onClick={() => setLogSheetOpen(true)}
            className="mt-4 h-12 px-5 rounded-[18px] bg-[var(--brand-500)] text-white font-bold text-sm sippy-press-brand cursor-pointer"
          >
            Log an extra sip
          </button>
        </div>
      ) : (
        <section aria-label="Hydration timeline" className="sippy-card rounded-[24px] p-4">
          <ul className="space-y-3">
            {todaySlots.map((slot, index) => {
              const isLast = index === todaySlots.length - 1;
              const fmt = formatVolume(slot.targetMl, profile.unit);

              const badgeStyle =
                slot.status === 'done'
                  ? 'bg-[var(--mint-100)] text-[var(--mint-500)]'
                  : slot.status === 'missed'
                    ? 'bg-[var(--coral-100)] text-[var(--coral-500)]'
                    : slot.status === 'skipped'
                      ? 'bg-[var(--card-tint)] text-[var(--ink-500)]'
                      : 'bg-[var(--brand-50)] text-[var(--brand-600)]';

              const dotColor =
                slot.status === 'done'
                  ? 'bg-[var(--mint-500)]'
                  : slot.status === 'missed'
                    ? 'bg-[var(--coral-500)]'
                    : slot.status === 'skipped'
                      ? 'bg-[var(--ink-300)]'
                      : 'bg-[var(--brand-500)]';

              return (
                <motion.li
                  key={slot.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04, duration: 0.22 }}
                  className="relative flex gap-3"
                >
                  {/* Timeline rail */}
                  <div className="flex flex-col items-center pt-3">
                    <span className={`w-3.5 h-3.5 rounded-full ${dotColor} shrink-0`} />
                    {!isLast && <span className="w-[2px] flex-1 bg-[var(--line)] mt-1.5" />}
                  </div>

                  {/* Slot Card */}
                  <button
                    type="button"
                    onClick={() => setSelectedSlot(slot)}
                    className="flex-1 min-h-[64px] rounded-[18px] bg-[var(--canvas)] p-3.5 text-left flex items-center justify-between gap-3 hover:bg-[var(--brand-50)]/60 transition-colors cursor-pointer"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-[var(--ink-900)] sippy-num">
                          {formatTimeShort(slot.notifyAt)}
                        </span>
                        <span className={`px-2 py-0.5 rounded-[8px] text-xs font-bold capitalize ${badgeStyle}`}>
                          {slot.status === 'pending' ? 'Upcoming' : slot.status}
                        </span>
                      </div>

                      <p className="mt-1 text-[17px] font-extrabold text-[var(--ink-900)] sippy-num">
                        {fmt.value} {fmt.unitLabel}
                      </p>

                      {slot.movedFrom && (
                        <p className="mt-0.5 inline-flex items-center gap-1 text-xs font-semibold text-[var(--brand-600)]">
                          <RotateCw size={12} />
                          <span>moved from {formatTimeShort(slot.movedFrom)}</span>
                        </p>
                      )}
                    </div>

                    <div className="shrink-0">
                      {slot.status === 'done' ? (
                        <span className="w-8 h-8 rounded-full bg-[var(--mint-100)] text-[var(--mint-500)] flex items-center justify-center">
                          <Check size={16} />
                        </span>
                      ) : slot.status === 'missed' ? (
                        <span className="w-8 h-8 rounded-full bg-[var(--coral-100)] text-[var(--coral-500)] flex items-center justify-center">
                          <XCircle size={16} />
                        </span>
                      ) : (
                        <span className="w-8 h-8 rounded-full bg-[var(--brand-100)] text-[var(--brand-600)] flex items-center justify-center">
                          <Clock size={16} />
                        </span>
                      )}
                    </div>
                  </button>
                </motion.li>
              );
            })}
          </ul>
        </section>
      )}

      <SlotDetailSheet slot={selectedSlot} onClose={() => setSelectedSlot(null)} />
    </div>
  );
};
