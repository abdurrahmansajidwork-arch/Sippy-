import React, { useState } from 'react';
import {
  Bell,
  Check,
  CloudSun,
  Download,
  LogIn,
  LogOut,
  Minus,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import type { GlassIconType, GlassPreset, NotificationTone, UnitType } from '../types';
import { Achievements } from '../components/Achievements';
import { DrinkGlyph } from '../components/BrandIcons';
import { MysteryRecipeBox } from '../components/MysteryRecipeBox';
import { PWAInstallButton } from '../components/PWAInstallBanner';
import { DeleteConfirmDialog } from '../components/Sheets';

const ICON_CHOICES: GlassIconType[] = ['tumbler', 'bottle', 'mug', 'cup', 'jug', 'boba'];

export const MeScreen: React.FC = () => {
  const {
    profile,
    isDemo,
    glasses,
    weatherInfo,
    signInWithGoogle,
    signOutUser,
    updateProfile,
    addGlass,
    deleteGlass,
    toggleWeatherBoost,
    enablePushNotifications,
    exportAllDataJson,
    deleteAccountAndData,
    setReminderPreviewOpen,
  } = useSippy();

  const [newGlassOpen, setNewGlassOpen] = useState(false);
  const [newGlassName, setNewGlassName] = useState('');
  const [newGlassMl, setNewGlassMl] = useState(350);
  const [newGlassIcon, setNewGlassIcon] = useState<GlassIconType>('bottle');
  const [pushMessage, setPushMessage] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmSignOut, setConfirmSignOut] = useState(false);
  const [deletingGlass, setDeletingGlass] = useState<GlassPreset | null>(null);
  const [editingName, setEditingName] = useState(false);
  const [draftName, setDraftName] = useState('');

  if (!profile) return null;

  const handleSaveName = async () => {
    const clean = draftName.trim();
    if (clean) {
      await updateProfile({ name: clean.slice(0, 32) });
    }
    setEditingName(false);
  };

  const handleCreateGlass = async () => {
    await addGlass({
      name: newGlassName || `${newGlassMl} ml Glass`,
      ml: newGlassMl,
      icon: newGlassIcon,
    });
    setNewGlassName('');
    setNewGlassOpen(false);
  };

  const handleEnablePush = async () => {
    const res = await enablePushNotifications();
    setPushMessage(res.reason || (res.granted ? 'Push reminders enabled!' : 'Permission declined.'));
  };

  return (
    <div className="space-y-5">
      <header className="pt-safe flex items-center justify-between min-h-[44px]">
        <h1 className="text-[26px] leading-[32px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
          Settings
        </h1>
      </header>

      {/* Profile Card */}
      <section className="sippy-card rounded-[24px] p-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            {profile.photoURL ? (
              <img
                src={profile.photoURL}
                alt={profile.name}
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-full object-cover shrink-0"
              />
            ) : (
              <div className="w-12 h-12 rounded-full bg-[var(--brand-500)] text-white font-extrabold text-lg flex items-center justify-center shrink-0">
                {profile.name.charAt(0).toUpperCase()}
              </div>
            )}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="text-[17px] font-bold text-[var(--ink-900)] truncate">{profile.name}</p>
                <button
                  type="button"
                  aria-label="Edit display name"
                  onClick={() => {
                    setDraftName(profile.name);
                    setEditingName((v) => !v);
                  }}
                  className="w-7 h-7 rounded-full flex items-center justify-center text-[var(--ink-300)] hover:text-[var(--brand-600)] hover:bg-[var(--brand-50)] cursor-pointer shrink-0"
                >
                  <Pencil size={13} />
                </button>
              </div>
              <p className="text-xs text-[var(--ink-500)] truncate">
                {isDemo ? 'Local & preview profile' : profile.email || 'Google account'}
              </p>
            </div>
          </div>

          {isDemo ? (
            <button
              type="button"
              onClick={() => void signInWithGoogle()}
              className="h-10 px-4 rounded-full bg-[var(--brand-500)] text-white text-xs font-bold flex items-center gap-1.5 shrink-0 sippy-press-brand cursor-pointer"
            >
              <LogIn size={14} />
              <span>Sign in</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmSignOut(true)}
              className="h-10 px-4 rounded-full bg-[var(--card-tint)] text-[var(--ink-700)] text-xs font-bold flex items-center gap-1.5 shrink-0 sippy-press-tint cursor-pointer"
            >
              <LogOut size={14} />
              <span>Sign out</span>
            </button>
          )}
        </div>

        {editingName && (
          <div className="flex items-center gap-2 pt-2 border-t border-[var(--line)]">
            <input
              type="text"
              maxLength={32}
              value={draftName}
              aria-label="Display name"
              onChange={(e) => setDraftName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') void handleSaveName();
              }}
              className="flex-1 h-10 px-3 rounded-xl bg-[var(--canvas)] border border-[var(--line)] text-sm font-bold text-[var(--ink-900)] focus:outline-2 focus:outline-[var(--brand-500)]"
            />
            <button
              type="button"
              onClick={() => void handleSaveName()}
              className="h-10 px-3.5 rounded-xl bg-[var(--brand-500)] text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <Check size={14} />
              <span>Save</span>
            </button>
          </div>
        )}
      </section>

      {/* PWA Install Prompt */}
      <PWAInstallButton />

      {/* Dew Tokens & Mystery Recipe Box */}
      <MysteryRecipeBox />

      {/* Achievements & Custom Badges */}
      <Achievements />

      {/* Goal & Window */}
      <section className="sippy-card rounded-[24px] p-4 space-y-4">
        <h2 className="text-[17px] font-bold text-[var(--ink-900)]">Daily target & window</h2>

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-[var(--ink-700)]">Base daily goal</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-label="Decrease base goal"
              onClick={() => void updateProfile({ goalMl: Math.max(1000, profile.goalMl - 100) })}
              className="w-10 h-10 rounded-full bg-white text-[var(--brand-600)] flex items-center justify-center sippy-press-white cursor-pointer"
            >
              <Minus size={15} strokeWidth={2.5} />
            </button>
            <span className="min-w-[82px] text-center text-sm font-extrabold text-[var(--ink-900)] sippy-num">
              {profile.goalMl} ml
            </span>
            <button
              type="button"
              aria-label="Increase base goal"
              onClick={() => void updateProfile({ goalMl: Math.min(5000, profile.goalMl + 100) })}
              className="w-10 h-10 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center sippy-press-brand cursor-pointer"
            >
              <Plus size={15} strokeWidth={2.5} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="text-xs font-semibold text-[var(--ink-500)]">Wake time</span>
            <input
              type="time"
              value={profile.wakeTime}
              onChange={(e) => void updateProfile({ wakeTime: e.target.value })}
              className="mt-1 w-full h-11 px-3 rounded-[14px] bg-[var(--card-tint)] text-sm font-bold text-[var(--ink-900)] tabular-nums"
            />
          </label>
          <label className="block">
            <span className="text-xs font-semibold text-[var(--ink-500)]">Bedtime</span>
            <input
              type="time"
              value={profile.bedTime}
              onChange={(e) => void updateProfile({ bedTime: e.target.value })}
              className="mt-1 w-full h-11 px-3 rounded-[14px] bg-[var(--card-tint)] text-sm font-bold text-[var(--ink-900)] tabular-nums"
            />
          </label>
        </div>

        {/* Units */}
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-[var(--ink-700)]">Units</span>
          <div className="p-1 rounded-full bg-[var(--card-tint)] flex gap-1">
            {(['ml', 'oz'] as UnitType[]).map((u) => (
              <button
                key={u}
                type="button"
                onClick={() => void updateProfile({ unit: u })}
                className={`h-8 px-4 rounded-full text-xs font-bold cursor-pointer ${
                  profile.unit === u
                    ? 'bg-[var(--brand-500)] text-white'
                    : 'text-[var(--ink-700)]'
                }`}
              >
                {u}
              </button>
            ))}
          </div>
        </div>

        {/* Weather boost */}
        <div className="flex items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2.5">
            <CloudSun size={18} className="text-[var(--water-500)] shrink-0" />
            <div>
              <p className="text-sm font-semibold text-[var(--ink-900)]">Hot-weather boost</p>
              <p className="text-xs text-[var(--ink-500)]">
                {weatherInfo ? weatherInfo.reason : '+10% at 30°C+, +20% at 35°C+'}
              </p>
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={profile.weatherBoost}
            aria-label="Toggle hot weather boost"
            onClick={() => void toggleWeatherBoost(!profile.weatherBoost)}
            className={`relative w-12 h-7 rounded-full transition-colors shrink-0 cursor-pointer ${
              profile.weatherBoost ? 'bg-[var(--brand-500)]' : 'bg-[var(--card-tint)]'
            }`}
          >
            <span
              className={`absolute top-0.5 left-0.5 w-6 h-6 rounded-full bg-white shadow-sm transition-transform ${
                profile.weatherBoost ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </section>

      {/* Sippy Persona & Reminders */}
      <section className="sippy-card rounded-[24px] p-4 space-y-4">
        <h2 className="text-[17px] font-bold text-[var(--ink-900)]">Sippy persona & voice</h2>

        <div>
          <span className="text-xs font-semibold text-[var(--ink-500)]">
            Mascot style & reminder tone
          </span>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {(['coach', 'gentle', 'playful'] as NotificationTone[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => void updateProfile({ tone: t })}
                className={`h-10 rounded-[14px] text-xs font-bold capitalize cursor-pointer ${
                  profile.tone === t
                    ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                    : 'bg-[var(--card-tint)] text-[var(--ink-700)] sippy-press-tint'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-[var(--ink-700)]">Max reminders / day</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-label="Decrease max reminders"
              onClick={() =>
                void updateProfile({ maxPushPerDay: Math.max(3, profile.maxPushPerDay - 1) })
              }
              className="w-10 h-10 rounded-full bg-white text-[var(--brand-600)] flex items-center justify-center sippy-press-white cursor-pointer"
            >
              <Minus size={15} strokeWidth={2.5} />
            </button>
            <span className="min-w-[36px] text-center text-sm font-extrabold text-[var(--ink-900)] sippy-num">
              {profile.maxPushPerDay}
            </span>
            <button
              type="button"
              aria-label="Increase max reminders"
              onClick={() =>
                void updateProfile({ maxPushPerDay: Math.min(12, profile.maxPushPerDay + 1) })
              }
              className="w-10 h-10 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center sippy-press-brand cursor-pointer"
            >
              <Plus size={15} strokeWidth={2.5} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => void handleEnablePush()}
            className="h-11 rounded-[16px] bg-[var(--brand-500)] text-white text-xs font-bold flex items-center justify-center gap-1.5 sippy-press-brand cursor-pointer"
          >
            <Bell size={15} />
            <span>Enable push</span>
          </button>
          <button
            type="button"
            onClick={() => setReminderPreviewOpen(true)}
            className="h-11 rounded-[16px] bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sparkles size={15} />
            <span>Preview alert</span>
          </button>
        </div>

        {pushMessage && (
          <p className="text-xs text-[var(--ink-500)]">{pushMessage}</p>
        )}
      </section>

      {/* Glasses Manager */}
      <section className="sippy-card rounded-[24px] p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[17px] font-bold text-[var(--ink-900)]">My glasses</h2>
          <button
            type="button"
            onClick={() => setNewGlassOpen((v) => !v)}
            className="text-xs font-bold text-[var(--brand-600)] min-h-[36px] px-2 cursor-pointer"
          >
            + Add glass
          </button>
        </div>

        {newGlassOpen && (
          <div className="rounded-[18px] bg-[var(--canvas)] p-3.5 space-y-3">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Name (optional)"
                value={newGlassName}
                onChange={(e) => setNewGlassName(e.target.value)}
                className="flex-1 h-10 px-3 rounded-xl bg-[var(--card)] text-sm text-[var(--ink-900)]"
              />
              <input
                type="number"
                min={50}
                max={1500}
                step={25}
                value={newGlassMl}
                onChange={(e) => setNewGlassMl(Number(e.target.value))}
                className="w-24 h-10 px-3 rounded-xl bg-[var(--card)] text-sm font-bold text-[var(--ink-900)] tabular-nums"
              />
            </div>
            <div className="flex items-center justify-between gap-1">
              {ICON_CHOICES.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  aria-label={`Icon ${ic}`}
                  onClick={() => setNewGlassIcon(ic)}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center cursor-pointer ${
                    newGlassIcon === ic ? 'bg-[var(--brand-500)] text-white' : 'bg-[var(--card)]'
                  }`}
                >
                  <DrinkGlyph type={ic} size={18} color={newGlassIcon === ic ? '#FFFFFF' : '#19B4F2'} />
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => void handleCreateGlass()}
              className="w-full h-11 rounded-xl bg-[var(--brand-500)] text-white text-sm font-bold sippy-press-brand cursor-pointer"
            >
              Save glass
            </button>
          </div>
        )}

        <ul className="divide-y divide-[var(--line)]">
          {glasses.map((g) => {
            const isDef = g.id === profile.defaultGlassId;
            return (
              <li key={g.id} className="py-2.5 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => void updateProfile({ defaultGlassId: g.id })}
                  className="flex items-center gap-3 text-left min-w-0 flex-1 cursor-pointer"
                >
                  <span className="w-10 h-10 rounded-xl bg-[var(--water-100)] flex items-center justify-center shrink-0">
                    <DrinkGlyph type={g.icon} size={18} color="#19B4F2" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-[var(--ink-900)] truncate">
                      {g.name} · <span className="sippy-num">{g.ml} ml</span>
                    </p>
                    <p className="text-xs text-[var(--brand-600)] font-semibold">
                      {isDef ? 'Default one-tap glass' : 'Tap to set default'}
                    </p>
                  </div>
                </button>
                {glasses.length > 1 && (
                  <button
                    type="button"
                    aria-label={`Delete ${g.name}`}
                    onClick={() => setDeletingGlass(g)}
                    className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-[var(--coral-500)] hover:bg-[var(--coral-100)] cursor-pointer"
                  >
                    <Trash2 size={17} />
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      </section>

      {/* Data, Account & About */}
      <section className="sippy-card rounded-[24px] p-4 space-y-3">
        <button
          type="button"
          onClick={exportAllDataJson}
          className="w-full h-11 rounded-[16px] bg-[var(--card-tint)] text-[var(--ink-900)] text-sm font-bold flex items-center justify-center gap-2 sippy-press-tint cursor-pointer"
        >
          <Download size={16} />
          <span>Export data (JSON)</span>
        </button>

        {!confirmDelete ? (
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            className="w-full h-11 rounded-[16px] text-[var(--coral-500)] text-sm font-bold cursor-pointer"
          >
            Delete account and data
          </button>
        ) : (
          <div className="rounded-[16px] bg-[var(--coral-100)] p-3.5 space-y-2.5">
            <p className="text-xs font-semibold text-[var(--ink-900)]">
              This permanently removes all your hydration logs and settings.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirmDelete(false)}
                className="flex-1 h-10 rounded-xl bg-[var(--card)] text-xs font-bold text-[var(--ink-700)] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void deleteAccountAndData()}
                className="flex-1 h-10 rounded-xl bg-[var(--coral-500)] text-xs font-bold text-white sippy-press-coral cursor-pointer"
              >
                Confirm delete
              </button>
            </div>
          </div>
        )}

        <div className="pt-2 border-t border-[var(--line)] text-xs text-[var(--ink-500)] space-y-1">
          <p className="font-semibold text-[var(--ink-700)]">About Sippy</p>
          <p>
            Sippy helps you build steady daily hydration habits. Not medical advice.
          </p>
        </div>
      </section>

      <DeleteConfirmDialog
        open={confirmSignOut}
        title="Sign out of Sippy?"
        description="Your hydration logs and unlocked recipes stay safely backed up when you sign back in."
        cancelLabel="Stay signed in"
        confirmLabel="Sign out"
        variant="primary"
        icon={<LogOut size={22} />}
        onCancel={() => setConfirmSignOut(false)}
        onConfirm={async () => {
          setConfirmSignOut(false);
          await signOutUser();
        }}
      />

      <DeleteConfirmDialog
        open={Boolean(deletingGlass)}
        title={deletingGlass ? `Remove ${deletingGlass.name}?` : 'Remove glass?'}
        description="This removes the preset from your quick glasses list. Past hydration logs stay untouched."
        confirmLabel="Remove glass"
        onCancel={() => setDeletingGlass(null)}
        onConfirm={async () => {
          if (deletingGlass) {
            await deleteGlass(deletingGlass.id);
          }
          setDeletingGlass(null);
        }}
      />
    </div>
  );
};
