import type {
  DaySummary,
  GlassPreset,
  HydrationLog,
  ReminderSlot,
  UserProfile,
} from '../types';
import { snapTo5Min, toDateKey } from './scheduleEngine';

export function createDefaultGlasses(uid: string): GlassPreset[] {
  return [
    { id: 'glass_150', uid, name: 'Small Cup', ml: 150, icon: 'cup' },
    { id: 'glass_250', uid, name: 'Daily Glass', ml: 250, icon: 'tumbler' },
    { id: 'glass_300', uid, name: 'Tall Mug', ml: 300, icon: 'mug' },
    { id: 'glass_500', uid, name: 'Water Bottle', ml: 500, icon: 'bottle' },
  ];
}

export function createDemoSeedData(nowMs = Date.now()): {
  profile: UserProfile;
  glasses: GlassPreset[];
  logs: HydrationLog[];
  days: DaySummary[];
  slots: ReminderSlot[];
} {
  const uid = 'demo-alex';
  const todayKey = toDateKey(nowMs);
  const todayBase = new Date(`${todayKey}T00:00:00`).getTime();
  const nowHour = new Date(nowMs).getHours();
  const wakeHour = Math.min(7, Math.max(0, nowHour - 2));
  const wakeTime = `${String(wakeHour).padStart(2, '0')}:00`;
  const bedTime = nowHour >= 23 ? '23:59' : '23:00';

  const pastToday = (minsAgo: number, fallbackMinsFromMidnight: number) =>
    Math.max(todayBase + fallbackMinsFromMidnight * 60000, nowMs - minsAgo * 60000);

  const profile: UserProfile = {
    uid,
    name: 'Alex',
    email: 'alex@sippy.demo',
    goalMl: 2500,
    wakeTime,
    bedTime,
    tone: 'playful',
    maxPushPerDay: 8,
    unit: 'ml',
    defaultGlassId: 'glass_250',
    weatherBoost: true,
    workoutBoostMl: 0,
    shields: 1,
    activeSkin: 'mason',
    createdAt: nowMs - 14 * 86400000,
    updatedAt: nowMs,
  };

  const glasses = createDefaultGlasses(uid);

  const log1Ts = pastToday(220, 15);
  const log2Ts = pastToday(145, 30);
  const log3Ts = pastToday(85, 45);
  const log4Ts = pastToday(24, 60);

  const logs: HydrationLog[] = [
    {
      id: 'demo_log_1',
      uid,
      ts: log1Ts,
      date: todayKey,
      ml: 300,
      countedMl: 300,
      glassId: 'glass_300',
      drinkType: 'water',
      source: 'app',
    },
    {
      id: 'demo_log_2',
      uid,
      ts: log2Ts,
      date: todayKey,
      ml: 250,
      countedMl: 225,
      glassId: 'glass_250',
      drinkType: 'tea',
      source: 'app',
    },
    {
      id: 'demo_log_3',
      uid,
      ts: log3Ts,
      date: todayKey,
      ml: 500,
      countedMl: 500,
      glassId: 'glass_500',
      drinkType: 'water',
      source: 'push',
    },
    {
      id: 'demo_log_4',
      uid,
      ts: log4Ts,
      date: todayKey,
      ml: 250,
      countedMl: 250,
      glassId: 'glass_250',
      drinkType: 'sparkling',
      source: 'app',
    },
  ];

  // Historical logs for pattern richness across last 7 days
  const days: DaySummary[] = [];
  const sampleTotals = [2550, 2600, 2500, 2100, 2750, 2500, 2650];
  for (let i = 7; i >= 1; i--) {
    const dt = new Date(todayBase - i * 86400000);
    const dk = toDateKey(dt.getTime());
    const tot = sampleTotals[7 - i];
    const hit = tot >= 2500;
    const shieldUsed = i === 4; // Shield protected day 4
    days.push({
      id: dk,
      uid,
      date: dk,
      goalMl: 2500,
      totalMl: tot,
      hit,
      shieldUsed,
      boostMl: i === 2 ? 250 : 0,
      feelings: [
        {
          ts: dt.getTime() + 14 * 3600000,
          level: hit ? 'great' : 'okay',
          totalMlAtCheckin: tot,
        },
      ],
    });

    // Seed morning & afternoon historical logs
    logs.push(
      {
        id: `hist_${dk}_1`,
        uid,
        ts: dt.getTime() + 8 * 3600000,
        date: dk,
        ml: 500,
        countedMl: 500,
        glassId: 'glass_500',
        drinkType: 'water',
        source: 'app',
      },
      {
        id: `hist_${dk}_2`,
        uid,
        ts: dt.getTime() + 11 * 3600000,
        date: dk,
        ml: 500,
        countedMl: 500,
        glassId: 'glass_500',
        drinkType: 'water',
        source: 'app',
      },
      {
        id: `hist_${dk}_3`,
        uid,
        ts: dt.getTime() + 15 * 3600000,
        date: dk,
        ml: 300,
        countedMl: 300,
        glassId: 'glass_300',
        drinkType: 'water',
        source: 'push',
      }
    );
  }

  const todayCounted = logs
    .filter((l) => l.date === todayKey)
    .reduce((sum, l) => sum + l.countedMl, 0);

  days.push({
    id: todayKey,
    uid,
    date: todayKey,
    goalMl: 2500,
    totalMl: todayCounted,
    hit: todayCounted >= 2500,
    shieldUsed: false,
    boostMl: 0,
    feelings: [],
  });

  const missedAt = snapTo5Min(pastToday(55, 35));

  // Seed today's adaptive slots including a shifted slot example
  const slots: ReminderSlot[] = [
    {
      id: `slot_${todayKey}_1`,
      uid,
      date: todayKey,
      notifyAt: snapTo5Min(pastToday(215, 10)),
      targetMl: 300,
      status: 'done',
      title: 'Sip time',
      body: 'Start the morning with 300 ml.',
      notified: true,
      updatedAt: log1Ts,
    },
    {
      id: `slot_${todayKey}_2`,
      uid,
      date: todayKey,
      notifyAt: snapTo5Min(pastToday(140, 25)),
      targetMl: 250,
      status: 'done',
      title: 'Sippy is parched',
      body: "250 ml and I'll stop dramatically fainting.",
      notified: true,
      updatedAt: log2Ts,
    },
    {
      id: `slot_${todayKey}_3`,
      uid,
      date: todayKey,
      notifyAt: missedAt,
      targetMl: 300,
      status: 'missed',
      title: 'Sippy is parched',
      body: "300 ml and I'll stop dramatically fainting.",
      notified: true,
      updatedAt: missedAt + 30 * 60000,
    },
    {
      id: `slot_${todayKey}_4`,
      uid,
      date: todayKey,
      notifyAt: snapTo5Min(nowMs + 25 * 60000),
      targetMl: 350,
      status: 'pending',
      movedFrom: missedAt,
      title: 'Still here',
      body: 'No stress. I moved your plan: 350 ml next.',
      notified: false,
    },
    {
      id: `slot_${todayKey}_5`,
      uid,
      date: todayKey,
      notifyAt: snapTo5Min(nowMs + 115 * 60000),
      targetMl: 300,
      status: 'pending',
      title: 'Sippy is parched',
      body: "300 ml and I'll stop dramatically fainting.",
      notified: false,
    },
    {
      id: `slot_${todayKey}_6`,
      uid,
      date: todayKey,
      notifyAt: snapTo5Min(nowMs + 205 * 60000),
      targetMl: 300,
      status: 'pending',
      title: 'Sip time',
      body: '300 ml before winding down tonight.',
      notified: false,
    },
  ];

  return { profile, glasses, logs, days, slots };
}
