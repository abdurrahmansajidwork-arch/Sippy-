import type {
  BadgeInfo,
  DaySummary,
  DrinkType,
  GlassSkin,
  HydrationLog,
  NotificationTone,
  PatternStats,
  ReminderSlot,
  SippyMood,
  UnitType,
} from '../types';
import { parseTimeMinutes } from './scheduleEngine';

export const DRINK_FACTORS: Record<DrinkType, number> = {
  water: 1.0,
  sparkling: 1.0,
  milk: 0.9,
  tea: 0.9,
  juice: 0.85,
  coffee: 0.8,
};

export const DRINK_LABELS: Record<DrinkType, string> = {
  water: 'Water',
  sparkling: 'Sparkling',
  tea: 'Tea',
  coffee: 'Coffee',
  juice: 'Juice',
  milk: 'Milk',
};

export function calculateCountedMl(ml: number, drinkType: DrinkType): number {
  const factor = DRINK_FACTORS[drinkType] ?? 1.0;
  return Math.max(1, Math.round(ml * factor));
}

export function formatVolume(ml: number, unit: UnitType): { value: string; unitLabel: string } {
  if (unit === 'oz') {
    const oz = Math.round((ml / 29.5735) * 10) / 10;
    return {
      value: Number.isInteger(oz) ? String(oz) : oz.toFixed(1),
      unitLabel: 'oz',
    };
  }
  return {
    value: Math.round(ml).toLocaleString(),
    unitLabel: 'ml',
  };
}

export function calculateWeatherBoost(baseGoalMl: number, maxTempC: number): number {
  if (maxTempC >= 35) return Math.round((baseGoalMl * 0.2) / 50) * 50;
  if (maxTempC >= 30) return Math.round((baseGoalMl * 0.1) / 50) * 50;
  return 0;
}

export function calculatePaceExpectedRatio(
  wakeTime: string,
  bedTime: string,
  nowMs: number
): number {
  const d = new Date(nowMs);
  const nowMin = d.getHours() * 60 + d.getMinutes();
  const wakeMin = parseTimeMinutes(wakeTime);
  let bedMin = parseTimeMinutes(bedTime);
  if (bedMin <= wakeMin) bedMin += 24 * 60;

  let adjustedNow = nowMin;
  if (adjustedNow < wakeMin && nowMin + 24 * 60 <= bedMin) {
    adjustedNow += 24 * 60;
  }

  if (adjustedNow < wakeMin) return 0;
  if (adjustedNow >= bedMin) return 1;

  const linear = (adjustedNow - wakeMin) / Math.max(60, bedMin - wakeMin);
  // Slight ease-out curve so earlier hours pace smoothly
  return Math.min(1, Math.max(0, 1 - Math.pow(1 - linear, 1.3)));
}

export function isWithinDayWindow(wakeTime: string, bedTime: string, nowMs: number): boolean {
  const d = new Date(nowMs);
  const nowMin = d.getHours() * 60 + d.getMinutes();
  const wakeMin = parseTimeMinutes(wakeTime);
  let bedMin = parseTimeMinutes(bedTime);
  if (bedMin <= wakeMin) {
    return nowMin >= wakeMin || nowMin <= bedMin - 24 * 60;
  }
  return nowMin >= wakeMin && nowMin <= bedMin;
}

export function getSippyMood(params: {
  loggedMl: number;
  goalMl: number;
  wakeTime: string;
  bedTime: string;
  nowMs: number;
  slots: ReminderSlot[];
  isStreakMilestone?: boolean;
  cheekyNudge?: boolean;
  tone?: NotificationTone;
}): { mood: SippyMood; message: string } {
  const {
    loggedMl,
    goalMl,
    wakeTime,
    bedTime,
    nowMs,
    slots,
    isStreakMilestone,
    cheekyNudge,
    tone = 'playful',
  } = params;

  if (!isWithinDayWindow(wakeTime, bedTime, nowMs)) {
    return {
      mood: 'sleepy',
      message:
        tone === 'coach'
          ? 'Recovery hours. Back at it at wake-up.'
          : tone === 'gentle'
            ? 'Rest easy tonight. See you in the morning.'
            : 'All done for tonight. See you at wake-up!',
    };
  }

  if (isStreakMilestone) {
    return {
      mood: 'proud',
      message:
        tone === 'coach'
          ? 'Streak locked in! Keep stacking wins.'
          : tone === 'gentle'
            ? 'Milestone reached—your steady care is paying off.'
            : 'Milestone unlocked! Your rhythm is glowing.',
    };
  }

  const ratio = goalMl > 0 ? loggedMl / goalMl : 0;
  const expected = calculatePaceExpectedRatio(wakeTime, bedTime, nowMs);

  if (ratio >= 1) {
    return {
      mood: 'hyped',
      message:
        tone === 'coach'
          ? 'Target crushed! 100% locked in today.'
          : tone === 'gentle'
            ? 'Daily goal reached—nice and steady today.'
            : 'Goal reached! You crushed hydration today.',
    };
  }

  // Check 2 missed slots in a row
  const pastSlots = slots
    .filter((s) => s.status === 'missed' || s.status === 'done' || s.status === 'skipped')
    .sort((a, b) => b.notifyAt - a.notifyAt);
  if (pastSlots.length >= 2 && pastSlots[0].status === 'missed' && pastSlots[1].status === 'missed') {
    return {
      mood: 'worried',
      message:
        tone === 'coach'
          ? 'Two gaps spotted—I tightened your next slots.'
          : tone === 'gentle'
            ? 'No rush—I gently shifted your next sips.'
            : 'Two sips slipped—I shifted your next ones.',
    };
  }

  if (ratio >= expected + 0.1) {
    return {
      mood: 'hyped',
      message:
        tone === 'coach'
          ? 'Ahead of split! Keep that lead.'
          : tone === 'gentle'
            ? 'Lovely pace today—plenty of breathing room.'
            : 'Ahead of pace! Smooth sailing from here.',
    };
  }

  if (expected - ratio >= 0.15) {
    return {
      mood: 'thirsty',
      message:
        tone === 'coach'
          ? 'Time to close the gap—grab 250 ml now.'
          : tone === 'gentle'
            ? 'Whenever you have a moment, a small glass helps.'
            : 'Running a bit dry. One small glass helps!',
    };
  }

  if (cheekyNudge) {
    return {
      mood: 'cheeky',
      message: 'One quick sip and no more puppy eyes!',
    };
  }

  return {
    mood: tone === 'coach' ? 'proud' : 'happy',
    message:
      tone === 'coach'
        ? 'Right on target pace. Stay sharp!'
        : tone === 'gentle'
          ? 'Easy and balanced. Take a calm sip when ready.'
          : 'Right on pace! Keep those easy sips coming.',
  };
}

const WEEKDAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function computeHydrationPatterns(
  logs: HydrationLog[],
  slots: ReminderSlot[],
  days: DaySummary[]
): { stats: PatternStats; deterministicInsight: string } {
  const intakeByHour = new Array<number>(24).fill(0);
  const firstDrinkMinutes: number[] = [];
  const lastDrinkMinutes: number[] = [];

  const logsByDate = new Map<string, HydrationLog[]>();
  for (const log of logs) {
    const h = new Date(log.ts).getHours();
    intakeByHour[h] += log.countedMl;
    const arr = logsByDate.get(log.date) || [];
    arr.push(log);
    logsByDate.set(log.date, arr);
  }

  for (const dayLogs of logsByDate.values()) {
    const sorted = [...dayLogs].sort((a, b) => a.ts - b.ts);
    const first = new Date(sorted[0].ts);
    const last = new Date(sorted[sorted.length - 1].ts);
    firstDrinkMinutes.push(first.getHours() * 60 + first.getMinutes());
    lastDrinkMinutes.push(last.getHours() * 60 + last.getMinutes());
  }

  const hourTotals: Record<number, { done: number; total: number }> = {};
  const weekdayTotals: Record<number, { done: number; total: number }> = {};
  const responseDeltas: number[] = [];

  for (const slot of slots) {
    if (slot.status === 'pending') continue;
    const d = new Date(slot.notifyAt);
    const h = d.getHours();
    const wd = d.getDay();

    hourTotals[h] = hourTotals[h] || { done: 0, total: 0 };
    hourTotals[h].total += 1;
    if (slot.status === 'done') hourTotals[h].done += 1;

    weekdayTotals[wd] = weekdayTotals[wd] || { done: 0, total: 0 };
    weekdayTotals[wd].total += 1;
    if (slot.status === 'done') weekdayTotals[wd].done += 1;

    if (slot.status === 'done' && slot.updatedAt && slot.updatedAt >= slot.notifyAt) {
      const diffMin = Math.round((slot.updatedAt - slot.notifyAt) / 60000);
      if (diffMin <= 180) responseDeltas.push(diffMin);
    }
  }

  const completionByHour: Record<number, number> = {};
  for (const [h, v] of Object.entries(hourTotals)) {
    completionByHour[Number(h)] = v.total > 0 ? Math.round((v.done / v.total) * 100) / 100 : 1;
  }

  const completionByWeekday: Record<number, number> = {};
  let bestWd = 2; // Tue default
  let bestScore = -1;
  let worstWd = 0; // Sun default
  let worstScore = 2;

  for (let wd = 0; wd < 7; wd++) {
    const v = weekdayTotals[wd];
    const rate = v && v.total > 0 ? v.done / v.total : 0.75;
    completionByWeekday[wd] = Math.round(rate * 100) / 100;
    if (v && v.total > 0) {
      if (rate > bestScore) {
        bestScore = rate;
        bestWd = wd;
      }
      if (rate < worstScore) {
        worstScore = rate;
        worstWd = wd;
      }
    }
  }

  responseDeltas.sort((a, b) => a - b);
  const medianResponseMin =
    responseDeltas.length > 0 ? responseDeltas[Math.floor(responseDeltas.length / 2)] : null;

  const avgMin = (arr: number[], fallback: number) =>
    arr.length > 0 ? Math.round(arr.reduce((s, n) => s + n, 0) / arr.length) : fallback;

  const fmtMin = (m: number) => {
    const h = Math.floor(m / 60) % 24;
    const min = m % 60;
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 || 12;
    return `${h12}:${String(min).padStart(2, '0')} ${ampm}`;
  };

  const daysTracked = Math.max(days.length, logsByDate.size);
  const hasEnoughData = daysTracked >= 3;

  // Find peak intake hour & weakest slot hour
  let peakHour = 10;
  let peakVal = -1;
  for (let h = 0; h < 24; h++) {
    if (intakeByHour[h] > peakVal) {
      peakVal = intakeByHour[h];
      peakHour = h;
    }
  }

  let weakHour: number | null = null;
  let weakRate = 1;
  for (const [hStr, rate] of Object.entries(completionByHour)) {
    if (rate < 0.6 && rate < weakRate) {
      weakRate = rate;
      weakHour = Number(hStr);
    }
  }

  const fmtHour = (h: number) => `${h % 12 || 12} ${h >= 12 ? 'PM' : 'AM'}`;
  const deterministicInsight = !hasEnoughData
    ? 'Log for 3 days so Sippy can learn your easiest hours and adapt your reminders.'
    : weakHour !== null
      ? `You hydrate best around ${fmtHour(peakHour)} and tend to skip near ${fmtHour(weakHour)}. I’ll nudge 30 min earlier before ${fmtHour(weakHour)}.`
      : `${WEEKDAY_NAMES[bestWd]}s are your strongest hydration days, usually starting around ${fmtMin(avgMin(firstDrinkMinutes, 465))}.`;

  return {
    stats: {
      intakeByHour,
      completionByHour,
      completionByWeekday,
      medianResponseMin,
      bestWeekday: WEEKDAY_NAMES[bestWd],
      worstWeekday: WEEKDAY_NAMES[worstWd],
      usualFirstDrink: fmtMin(avgMin(firstDrinkMinutes, 465)),
      usualLastDrink: fmtMin(avgMin(lastDrinkMinutes, 1290)),
      daysTracked,
      hasEnoughData,
    },
    deterministicInsight,
  };
}

export function computeStreakAndBadges(
  days: DaySummary[],
  logs: HydrationLog[],
  todayKey: string,
  shieldsAvailable = 0
): {
  currentStreak: number;
  bestStreak: number;
  shieldsEarned: number;
  shieldSavedDates: string[];
  badges: BadgeInfo[];
  unlockedSkins: GlassSkin[];
  goalHitRate: number;
  avgDailyMl: number;
} {
  const dayMap = new Map<string, DaySummary>();
  for (const d of days) {
    dayMap.set(d.date, d);
  }

  const sortedDates = [...dayMap.keys()].sort();
  const shieldSavedDates: string[] = [];

  // Calculate historical streaks & shield auto-saves
  let bestStreak = 0;
  let run = 0;
  let shields = Math.min(2, Math.max(0, shieldsAvailable));

  for (let i = 0; i < sortedDates.length; i++) {
    const key = sortedDates[i];
    const d = dayMap.get(key)!;
    if (d.hit) {
      run += 1;
      if (run % 7 === 0 && shields < 2) {
        shields += 1;
      }
      bestStreak = Math.max(bestStreak, run);
    } else if (key !== todayKey) {
      if (d.shieldUsed) {
        shieldSavedDates.push(key);
        run += 1;
        bestStreak = Math.max(bestStreak, run);
      } else if (shields > 0 && run > 0) {
        shields -= 1;
        shieldSavedDates.push(key);
        run += 1;
        bestStreak = Math.max(bestStreak, run);
      } else {
        run = 0;
      }
    }
  }

  // Current streak backwards from today (if today isn't hit yet, check yesterday)
  let currentStreak = 0;
  const todaySummary = dayMap.get(todayKey);
  const startOffset = todaySummary?.hit ? 0 : 1;
  const todayDate = new Date(`${todayKey}T12:00:00`);

  for (let offset = startOffset; offset < 365; offset++) {
    const dt = new Date(todayDate);
    dt.setDate(dt.getDate() - offset);
    const k = dt.toISOString().slice(0, 10);
    const summary = dayMap.get(k);
    if (summary && (summary.hit || summary.shieldUsed || shieldSavedDates.includes(k))) {
      currentStreak += 1;
    } else {
      break;
    }
  }

  bestStreak = Math.max(bestStreak, currentStreak);

  // Early bird: >= 500 ml before 10 AM on any day
  const morningTotals = new Map<string, number>();
  for (const l of logs) {
    if (new Date(l.ts).getHours() < 10) {
      morningTotals.set(l.date, (morningTotals.get(l.date) || 0) + l.countedMl);
    }
  }
  const hasEarlyBird = [...morningTotals.values()].some((v) => v >= 500);

  const pastDays = days.filter((d) => d.date !== todayKey || d.totalMl > 0);
  const hitsCount = pastDays.filter((d) => d.hit).length;
  const goalHitRate = pastDays.length > 0 ? Math.round((hitsCount / pastDays.length) * 100) : 0;
  const avgDailyMl =
    pastDays.length > 0
      ? Math.round(pastDays.reduce((s, d) => s + d.totalMl, 0) / pastDays.length)
      : 0;

  const badges: BadgeInfo[] = [
    {
      id: 'first_sip',
      title: 'First Sip',
      description: 'Logged your very first drink',
      unlocked: logs.length > 0,
    },
    {
      id: 'streak_3',
      title: '3-Day Flow',
      description: 'Hit your goal 3 days in a row',
      unlocked: bestStreak >= 3,
    },
    {
      id: 'streak_7',
      title: '7-Day Wave',
      description: 'Hit your goal 7 days in a row',
      unlocked: bestStreak >= 7,
    },
    {
      id: 'streak_30',
      title: '30-Day Ocean',
      description: '30 days of steady hydration',
      unlocked: bestStreak >= 30,
    },
    {
      id: 'early_bird',
      title: 'Early Bird',
      description: '500 ml logged before 10 AM',
      unlocked: hasEarlyBird,
    },
    {
      id: 'perfect_week',
      title: 'Perfect Week',
      description: '7 consecutive days without a miss',
      unlocked: currentStreak >= 7 || bestStreak >= 7,
    },
  ];

  const unlockedSkins: GlassSkin[] = ['classic'];
  if (bestStreak >= 7) unlockedSkins.push('mason');
  if (bestStreak >= 14) unlockedSkins.push('sports');
  if (bestStreak >= 30) unlockedSkins.push('boba');

  return {
    currentStreak,
    bestStreak,
    shieldsEarned: shields,
    shieldSavedDates,
    badges,
    unlockedSkins,
    goalHitRate,
    avgDailyMl,
  };
}
