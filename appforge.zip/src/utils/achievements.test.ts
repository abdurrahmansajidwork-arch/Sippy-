import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeStreakAchievements,
  createStarterCustomBadges,
  evaluateCustomBadges,
  validateCustomBadgeInput,
} from './achievements';
import type { CustomBadge, DaySummary, HydrationLog } from '../types';

test('computeStreakAchievements tracks streak milestones and habit progress', () => {
  const days: DaySummary[] = Array.from({ length: 10 }, (_, idx) => ({
    id: `2026-11-${String(idx + 10).padStart(2, '0')}`,
    uid: 'u1',
    date: `2026-11-${String(idx + 10).padStart(2, '0')}`,
    goalMl: 2500,
    totalMl: 2600,
    hit: true,
    shieldUsed: false,
    boostMl: 0,
    feelings: [],
  }));
  const logs: HydrationLog[] = [
    {
      id: 'l1',
      uid: 'u1',
      ts: new Date('2026-11-20T08:30:00').getTime(),
      date: '2026-11-20',
      ml: 500,
      countedMl: 500,
      glassId: 'g1',
      drinkType: 'water',
      source: 'app',
    },
  ];

  const list = computeStreakAchievements({
    days,
    logs,
    currentStreak: 7,
    bestStreak: 10,
  });

  assert.equal(list.length, 8);
  assert.equal(list.find((b) => b.id === 'first_sip')?.unlocked, true);
  assert.equal(list.find((b) => b.id === 'streak_7')?.unlocked, true);
  assert.equal(list.find((b) => b.id === 'streak_14')?.unlocked, false);
  assert.equal(list.find((b) => b.id === 'streak_14')?.currentValue, 10);
  assert.equal(list.find((b) => b.id === 'early_bird')?.unlocked, true);
  assert.equal(list.find((b) => b.id === 'hydration_hero')?.unlocked, true);
});

test('validateCustomBadgeInput enforces non-empty names and valid targets', () => {
  const emptyRes = validateCustomBadgeInput({
    title: '   ',
    targetValue: 5,
    ruleType: 'streak_days',
  });
  assert.equal(emptyRes.valid, false);
  assert.ok(emptyRes.error);

  const longRes = validateCustomBadgeInput({
    title: 'A very overly verbose badge title exceeding limit',
    targetValue: 5,
    ruleType: 'streak_days',
  });
  assert.equal(longRes.valid, false);

  const okRes = validateCustomBadgeInput({
    title: '  Morning   Flow ',
    targetValue: 12,
    ruleType: 'streak_days',
  });
  assert.equal(okRes.valid, true);
  assert.equal(okRes.cleanTitle, 'Morning Flow');
  assert.equal(okRes.cleanTarget, 12);
});

test('evaluateCustomBadges unlocks streak_days and total_logs badges accurately', () => {
  const custom: CustomBadge[] = [
    ...createStarterCustomBadges(1000),
    {
      id: 'c2',
      title: '25 Sips Club',
      ruleType: 'total_logs',
      targetValue: 25,
      icon: 'droplet',
      palette: 'water',
      createdAt: 1000,
    },
  ];

  const evaluated = evaluateCustomBadges(custom, {
    currentStreak: 4,
    bestStreak: 6,
    totalLogsCount: 15,
  });

  assert.equal(evaluated[0].unlocked, true); // 6 >= 5
  assert.equal(evaluated[0].progressPct, 100);

  assert.equal(evaluated[1].unlocked, false); // 15 < 25
  assert.equal(evaluated[1].currentValue, 15);
  assert.equal(evaluated[1].progressPct, 60);
});
