import type { UnitType } from '../types';
import { formatVolume } from './patternEngine';

export async function generateShareCardBlob(params: {
  totalMl: number;
  goalMl: number;
  streak: number;
  unit: UnitType;
  dateLabel: string;
}): Promise<Blob> {
  const { totalMl, goalMl, streak, unit, dateLabel } = params;
  const width = 1080;
  const height = 1350;
  const pct = Math.min(100, Math.round((totalMl / Math.max(1, goalMl)) * 100));
  const totalFmt = formatVolume(totalMl, unit);
  const goalFmt = formatVolume(goalMl, unit);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable');

  // Soft Aqua background gradient
  const bg = ctx.createLinearGradient(0, 0, 0, height);
  bg.addColorStop(0, '#EEF3FF');
  bg.addColorStop(1, '#CFE0FF');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  // Diagonal soft light ray
  ctx.fillStyle = 'rgba(255,255,255,0.28)';
  ctx.beginPath();
  ctx.moveTo(140, 0);
  ctx.lineTo(420, 0);
  ctx.lineTo(820, height);
  ctx.lineTo(540, height);
  ctx.closePath();
  ctx.fill();

  // White centered card
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.roundRect(96, 110, width - 192, height - 220, 56);
  ctx.fill();

  // Date overline (no personal name/email)
  ctx.fillStyle = '#5B6578';
  ctx.font = '700 28px "Plus Jakarta Sans", system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(dateLabel.toUpperCase(), width / 2, 200);

  // Progress ring
  const cx = width / 2;
  const cy = 500;
  const radius = 190;
  ctx.lineWidth = 28;
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#D9F2FD';
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.stroke();

  const ringGrad = ctx.createLinearGradient(cx - radius, cy - radius, cx + radius, cy + radius);
  ringGrad.addColorStop(0, '#6FD3FF');
  ringGrad.addColorStop(1, '#3D6EF5');
  ctx.strokeStyle = ringGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * pct) / 100);
  ctx.stroke();

  // Sippy droplet inside ring
  ctx.save();
  ctx.translate(cx, cy - 10);
  const dropGrad = ctx.createLinearGradient(0, -110, 0, 100);
  dropGrad.addColorStop(0, '#6FD3FF');
  dropGrad.addColorStop(1, '#3D6EF5');
  ctx.fillStyle = dropGrad;
  ctx.beginPath();
  ctx.moveTo(0, -110);
  ctx.bezierCurveTo(-90, -20, -100, 95, 0, 95);
  ctx.bezierCurveTo(100, 95, 90, -20, 0, -110);
  ctx.fill();

  // Eyes & smile
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.ellipse(-28, 12, 16, 20, 0, 0, Math.PI * 2);
  ctx.ellipse(28, 12, 16, 20, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#0B1633';
  ctx.beginPath();
  ctx.arc(-26, 14, 9, 0, Math.PI * 2);
  ctx.arc(26, 14, 9, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#0B1633';
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(0, 36, 16, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
  ctx.restore();

  // Big numbers
  ctx.fillStyle = '#0B1633';
  ctx.font = '800 84px "Plus Jakarta Sans", system-ui, sans-serif';
  ctx.fillText(`${totalFmt.value} ${totalFmt.unitLabel}`, cx, 815);

  ctx.fillStyle = '#5B6578';
  ctx.font = '600 36px "Plus Jakarta Sans", system-ui, sans-serif';
  ctx.fillText(`of ${goalFmt.value} ${goalFmt.unitLabel} · ${pct}% hydrated`, cx, 875);

  // Streak badge
  ctx.fillStyle = '#FFF1E3';
  ctx.beginPath();
  ctx.roundRect(cx - 170, 935, 340, 84, 42);
  ctx.fill();
  ctx.fillStyle = '#FF6B2C';
  ctx.font = '700 34px "Plus Jakarta Sans", system-ui, sans-serif';
  ctx.fillText(`🔥 ${streak}-day streak`, cx, 990);

  // Brand footer
  ctx.fillStyle = '#3D6EF5';
  ctx.font = '800 42px "Plus Jakarta Sans", system-ui, sans-serif';
  ctx.fillText('Sippy', cx, 1140);

  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('Failed to generate PNG'));
    }, 'image/png');
  });
}
