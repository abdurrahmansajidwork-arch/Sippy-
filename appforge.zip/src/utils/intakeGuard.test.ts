import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evaluateIntakeSafety,
  getCurrentIntakeStatus,
  getOverGoalToleranceMl,
} from './intakeGuard';

test('getOverGoalToleranceMl scales at least +500 ml or 20% of goal', () => {
  assert.equal(getOverGoalToleranceMl(2500), 500);
  assert.equal(getOverGoalToleranceMl(3000), 600);
});

test('evaluateIntakeSafety skips confirmation when well below daily goal', () => {
  const res = evaluateIntakeSafety(1500, 250, 2800, 'water');
  assert.equal(res.projectedTotalMl, 1750);
  assert.equal(res.needsConfirmation, false);
  assert.equal(res.breaksTooMuch, false);
  assert.equal(res.reason, 'safe');
});

test('evaluateIntakeSafety asks for confirmation when adding 250 ml near max goal', () => {
  // 2,300 of 2,500 ml + 250 ml = 2,550 ml (crosses goal, within tolerance <= 3,000 ml)
  const nearCross = evaluateIntakeSafety(2300, 250, 2500, 'water');
  assert.equal(nearCross.needsConfirmation, true);
  assert.equal(nearCross.isNearMaxGoal, true);
  assert.equal(nearCross.breaksTooMuch, false);
  assert.equal(nearCross.reason, 'over_goal');

  // 2,220 of 2,500 ml + 250 ml = 2,470 ml (at 88.8%, right near max goal)
  const rightBeforeGoal = evaluateIntakeSafety(2220, 250, 2500, 'water');
  assert.equal(rightBeforeGoal.needsConfirmation, true);
  assert.equal(rightBeforeGoal.isNearMaxGoal, true);
  assert.equal(rightBeforeGoal.breaksTooMuch, false);
  assert.equal(rightBeforeGoal.reason, 'near_goal');
});

test('evaluateIntakeSafety triggers breaksTooMuch warning badge when far above goal', () => {
  // 2,850 of 2,500 ml + 250 ml = 3,100 ml (> 3,000 ml tolerance threshold)
  const res = evaluateIntakeSafety(2850, 250, 2500, 'water');
  assert.equal(res.needsConfirmation, true);
  assert.equal(res.breaksTooMuch, true);
  assert.equal(res.excessOverGoalMl, 600);
  assert.equal(res.reason, 'breaks_too_much');
});

test('getCurrentIntakeStatus outputs warning badge text when intake breaks too much of goal', () => {
  const normal = getCurrentIntakeStatus(2600, 2500);
  assert.equal(normal.isGoalMet, true);
  assert.equal(normal.breaksTooMuch, false);
  assert.equal(normal.badgeText, null);

  const high = getCurrentIntakeStatus(3250, 2500);
  assert.equal(high.breaksTooMuch, true);
  assert.equal(high.excessOverGoalMl, 750);
  assert.match(high.badgeText || '', /Well over goal/);
});
