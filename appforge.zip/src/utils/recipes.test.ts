import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canOpenMysteryBox,
  computeGoalRewardTokens,
  GOAL_HIT_BASE_TOKENS,
  MYSTERY_BOX_COST,
  pickMysteryRecipe,
  STREAK_BONUS_TOKENS,
  WATER_RECIPES,
} from './recipes';

test('computeGoalRewardTokens awards base tokens and streak bonus at 3+ days', () => {
  assert.equal(computeGoalRewardTokens(0), GOAL_HIT_BASE_TOKENS);
  assert.equal(computeGoalRewardTokens(2), GOAL_HIT_BASE_TOKENS);
  assert.equal(computeGoalRewardTokens(3), GOAL_HIT_BASE_TOKENS + STREAK_BONUS_TOKENS);
  assert.equal(computeGoalRewardTokens(12), GOAL_HIT_BASE_TOKENS + STREAK_BONUS_TOKENS);
});

test('canOpenMysteryBox requires at least MYSTERY_BOX_COST tokens', () => {
  assert.equal(canOpenMysteryBox(MYSTERY_BOX_COST - 1), false);
  assert.equal(canOpenMysteryBox(MYSTERY_BOX_COST), true);
  assert.equal(canOpenMysteryBox(MYSTERY_BOX_COST + 5), true);
});

test('pickMysteryRecipe prioritizes uncollected recipes before repeating', () => {
  const allExceptLast = WATER_RECIPES.slice(0, -1).map((r) => r.id);
  const picked = pickMysteryRecipe(allExceptLast, () => 0);
  assert.equal(picked.id, WATER_RECIPES[WATER_RECIPES.length - 1].id);
});

test('every recipe in WATER_RECIPES is water-based and includes valid steps', () => {
  assert.ok(WATER_RECIPES.length >= 10);
  for (const recipe of WATER_RECIPES) {
    assert.ok(recipe.waterMl >= 200);
    assert.ok(recipe.ingredients.length >= 3);
    assert.ok(recipe.steps.length >= 3);
    const hasWaterIngredient = recipe.ingredients.some((i) => i.toLowerCase().includes('water'));
    assert.equal(hasWaterIngredient, true, `${recipe.id} should list water as an ingredient`);
  }
});
