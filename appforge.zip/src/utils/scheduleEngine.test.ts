import test from 'node:test';
import assert from 'node:assert/strict';
import {
  adjustScheduleForIntake,
  buildScheduleSlots,
  getNotificationCopy,
  MIN_SLOT_GAP_MS,
  shiftPlanForMissedSlots,
} from './scheduleEngine';

const DATE_KEY = '2026-11-23';
const BASE_MORNING = new Date('2026-11-23T07:00:00').getTime();

test('buildScheduleSlots respects window bounds, 45m min gap, 5m snapping, and front-loading', () => {
  const slots = buildScheduleSlots({
    uid: 'u1',
    dateKey: DATE_KEY,
    goalMl: 2500,
    loggedMl: 0,
    defaultGlassMl: 250,
    wakeTime: '07:00',
    bedTime: '23:00',
    maxPushPerDay: 8,
    tone: 'playful',
    nowMs: BASE_MORNING,
  });

  assert.equal(slots.length, 8);
  for (let i = 0; i < slots.length; i++) {
    assert.equal(slots[i].notifyAt % (5 * 60 * 1000), 0, 'slot must be snapped to 5 min');
    if (i > 0) {
      assert.ok(
        slots[i].notifyAt - slots[i - 1].notifyAt >= MIN_SLOT_GAP_MS,
        'slots must respect 45 min minimum gap'
      );
    }
  }

  const firstHalfSum = slots.slice(0, 4).reduce((s, x) => s + x.targetMl, 0);
  const secondHalfSum = slots.slice(4).reduce((s, x) => s + x.targetMl, 0);
  assert.ok(firstHalfSum >= secondHalfSum, 'first half should front-load ~55%');
});

test('shiftPlanForMissedSlots marks 30m overdue slot missed and shifts ml with movedFrom', () => {
  const baseSlots = buildScheduleSlots({
    uid: 'u1',
    dateKey: DATE_KEY,
    goalMl: 2000,
    loggedMl: 0,
    defaultGlassMl: 250,
    wakeTime: '07:00',
    bedTime: '23:00',
    maxPushPerDay: 8,
    tone: 'gentle',
    nowMs: BASE_MORNING,
  });

  // Simulate first slot was notified and 35 minutes passed
  const simulated = baseSlots.map((s, idx) =>
    idx === 0 ? { ...s, notified: true } : s
  );
  const checkNow = simulated[0].notifyAt + 35 * 60 * 1000;

  const res = shiftPlanForMissedSlots({
    uid: 'u1',
    dateKey: DATE_KEY,
    slots: simulated,
    goalMl: 2000,
    loggedMl: 0,
    wakeTime: '07:00',
    bedTime: '23:00',
    maxPushPerDay: 8,
    tone: 'gentle',
    nowMs: checkNow,
  });

  assert.equal(res.newlyMissedCount, 1);
  assert.equal(res.slots[0].status, 'missed');
  assert.ok(res.shiftedCount >= 1);
  assert.ok(res.slots.some((s) => s.movedFrom === simulated[0].notifyAt));
  assert.ok(res.slots.length <= 8, 'must not exceed maxPushPerDay');
});

test('adjustScheduleForIntake completes nearest slot and trims remaining slots when drinking ahead', () => {
  const baseSlots = buildScheduleSlots({
    uid: 'u1',
    dateKey: DATE_KEY,
    goalMl: 1000,
    loggedMl: 0,
    defaultGlassMl: 250,
    wakeTime: '07:00',
    bedTime: '23:00',
    maxPushPerDay: 8,
    tone: 'coach',
    nowMs: BASE_MORNING,
  });

  const updated = adjustScheduleForIntake({
    slots: baseSlots,
    dateKey: DATE_KEY,
    goalMl: 1000,
    newTotalLoggedMl: 750,
    nowMs: baseSlots[0].notifyAt,
    tone: 'coach',
  });

  const pendingSum = updated
    .filter((s) => s.status === 'pending')
    .reduce((sum, s) => sum + s.targetMl, 0);
  assert.ok(pendingSum <= 250, 'remaining pending slots should shrink to <= 250 ml');
});

test('getNotificationCopy obeys character length limits and avoids all caps', () => {
  const tones = ['gentle', 'playful', 'coach'] as const;
  const cases = ['slot', 'followup', 'missed', 'streak_risk', 'pattern', 'goal_hit'] as const;
  for (const tone of tones) {
    for (const c of cases) {
      const { title, body } = getNotificationCopy(tone, c, { ml: 250, streak: 7, remainingMl: 500 });
      assert.ok(title.length <= 60 && title.length > 0);
      assert.ok(body.length <= 110 && body.length > 0);
      assert.notEqual(title, title.toUpperCase());
    }
  }
});

test('repeated adjustScheduleForIntake and buildScheduleSlots rebuilds keep slot IDs unique and spaced', () => {
  let slots = buildScheduleSlots({
    uid: 'u1',
    dateKey: DATE_KEY,
    goalMl: 2500,
    loggedMl: 0,
    defaultGlassMl: 250,
    wakeTime: '07:00',
    bedTime: '23:00',
    maxPushPerDay: 8,
    tone: 'playful',
    nowMs: BASE_MORNING,
  });

  // Simulate 3 rapid drink logs followed by full schedule rebuilds in the same 5-min window
  let logged = 0;
  for (let step = 1; step <= 3; step++) {
    logged += 250;
    const adjusted = adjustScheduleForIntake({
      slots,
      dateKey: DATE_KEY,
      goalMl: 2500,
      newTotalLoggedMl: logged,
      nowMs: BASE_MORNING + step * 1000,
      tone: 'playful',
    });
    slots = buildScheduleSlots({
      uid: 'u1',
      dateKey: DATE_KEY,
      goalMl: 2500,
      loggedMl: logged,
      defaultGlassMl: 250,
      wakeTime: '07:00',
      bedTime: '23:00',
      maxPushPerDay: 8,
      tone: 'playful',
      nowMs: BASE_MORNING + step * 2000,
      existingSlots: adjusted,
    });

    const ids = slots.map((s) => s.id);
    assert.equal(new Set(ids).size, ids.length, 'slot IDs must remain strictly unique');
    for (let i = 1; i < slots.length; i++) {
      assert.ok(
        slots[i].notifyAt - slots[i - 1].notifyAt >= MIN_SLOT_GAP_MS,
        'slots after rebuild must stay spaced by MIN_SLOT_GAP_MS'
      );
    }
  }
});

