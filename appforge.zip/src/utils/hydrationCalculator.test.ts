import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRecommendedWaterGoal, clampCalculatorInput } from './hydrationCalculator';

test('calculateRecommendedWaterGoal computes realistic baseline for average adult without workouts', () => {
  const res = calculateRecommendedWaterGoal({
    age: 32,
    weightKg: 70,
    heightCm: 170,
    workoutLevel: 'moderate',
    workoutsPerWeek: 0,
  });
  assert.equal(res.baseMl, 2250);
  assert.equal(res.activityBonusMl, 0);
  assert.equal(res.goalMl, 2250);
  assert.equal(res.glassesOf250Ml, 9);
});

test('calculateRecommendedWaterGoal scales up with higher weight, height, and intense frequent workouts', () => {
  const sedentary = calculateRecommendedWaterGoal({
    age: 26,
    weightKg: 65,
    heightCm: 168,
    workoutLevel: 'light',
    workoutsPerWeek: 1,
  });

  const athletic = calculateRecommendedWaterGoal({
    age: 26,
    weightKg: 82,
    heightCm: 185,
    workoutLevel: 'intense',
    workoutsPerWeek: 6,
  });

  assert.ok(athletic.goalMl > sedentary.goalMl + 700);
  assert.ok(athletic.activityBonusMl >= 600);
  assert.equal(athletic.goalMl % 50, 0);
});

test('clampCalculatorInput bounds extreme physiological inputs safely', () => {
  const clamped = clampCalculatorInput({
    age: 4,
    weightKg: 300,
    heightCm: 90,
    workoutLevel: 'intense',
    workoutsPerWeek: 14,
  });
  assert.equal(clamped.age, 12);
  assert.equal(clamped.weightKg, 180);
  assert.equal(clamped.heightCm, 120);
  assert.equal(clamped.workoutsPerWeek, 7);

  const res = calculateRecommendedWaterGoal(clamped);
  assert.ok(res.goalMl >= 1500 && res.goalMl <= 4500);
});
