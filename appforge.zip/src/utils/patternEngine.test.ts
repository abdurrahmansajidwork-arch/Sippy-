import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateCountedMl,
  calculatePaceExpectedRatio,
  calculateWeatherBoost,
  computeHydrationPatterns,
  computeStreakAndBadges,
  getSippyMood,
} from './patternEngine';
import type { DaySummary, HydrationLog } from '../types';

test('calculateCountedMl applies drink hydration factors', () => {
  assert.equal(calculateCountedMl(250, 'water'), 250);
  assert.equal(calculateCountedMl(250, 'sparkling'), 250);
  assert.equal(calculateCountedMl(200, 'tea'), 180);
  assert.equal(calculateCountedMl(200, 'milk'), 180);
  assert.equal(calculateCountedMl(200, 'juice'), 170);
  assert.equal(calculateCountedMl(200, 'coffee'), 160);
});

test('calculateWeatherBoost triggers +10% at 30C and +20% at 35C', () => {
  assert.equal(calculateWeatherBoost(2500, 26), 0);
  assert.equal(calculateWeatherBoost(2500, 30), 250);
  assert.equal(calculateWeatherBoost(2500, 35), 500);
});

test('getSippyMood transitions across sleepy, hyped, thirsty, and worried', () => {
  const morningOnPace = new Date('2026-11-23T11:00:00').getTime();
  const lateNight = new Date('2026-11-23T23:30:00').getTime();

  assert.equal(
    getSippyMood({
      loggedMl: 500,
      goalMl: 2500,
      wakeTime: '07:00',
      bedTime: '23:00',
      nowMs: lateNight,
      slots: [],
    }).mood,
    'sleepy'
  );

  assert.equal(
    getSippyMood({
      loggedMl: 2500,
      goalMl: 2500,
      wakeTime: '07:00',
      bedTime: '23:00',
      nowMs: morningOnPace,
      slots: [],
    }).mood,
    'hyped'
  );

  const expected = calculatePaceExpectedRatio('07:00', '23:00', morningOnPace);
  assert.ok(expected > 0.2);

  assert.equal(
    getSippyMood({
      loggedMl: 100,
      goalMl: 2500,
      wakeTime: '07:00',
      bedTime: '23:00',
      nowMs: morningOnPace,
      slots: [],
    }).mood,
    'thirsty'
  );
});

test('computeStreakAndBadges awards streak shields, badges, and skins', () => {
  const days: DaySummary[] = [];
  const logs: HydrationLog[] = [];
  for (let i = 7; i >= 1; i--) {
    const dt = new Date('2026-11-23T09:00:00');
    dt.setDate(dt.getDate() - i);
    const dk = dt.toISOString().slice(0, 10);
    days.push({
      id: dk,
      uid: 'u1',
      date: dk,
      goalMl: 2500,
      totalMl: 2500,
      hit: true,
      shieldUsed: false,
      boostMl: 0,
      feelings: [],
    });
    logs.push({
      id: `l_${i}`,
      uid: 'u1',
      ts: dt.getTime(),
      date: dk,
      ml: 500,
      countedMl: 500,
      glassId: 'g1',
      drinkType: 'water',
      source: 'app',
    });
  }

  const res = computeStreakAndBadges(days, logs, '2026-11-23', 0);
  assert.equal(res.currentStreak, 7);
  assert.equal(res.shieldsEarned, 1);
  assert.ok(res.unlockedSkins.includes('mason'));
  assert.ok(res.badges.find((b) => b.id === 'streak_7')?.unlocked);
  assert.ok(res.badges.find((b) => b.id === 'early_bird')?.unlocked);

  const patterns = computeHydrationPatterns(logs, [], days);
  assert.equal(patterns.stats.hasEnoughData, true);
});
