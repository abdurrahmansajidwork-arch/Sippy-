import type { NotificationTone, ReminderSlot, ScheduleTweak } from '../types';

export const MIN_SLOT_GAP_MS = 45 * 60 * 1000;
export const MISSED_CUTOFF_MS = 30 * 60 * 1000;
export const FIVE_MIN_MS = 5 * 60 * 1000;

export function toDateKey(ms: number): string {
  const d = new Date(ms);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function parseTimeMinutes(hhmm: string): number {
  const parts = (hhmm || '07:00').split(':');
  const h = Math.max(0, Math.min(23, Number(parts[0]) || 0));
  const m = Math.max(0, Math.min(59, Number(parts[1]) || 0));
  return h * 60 + m;
}

export function snapTo5Min(ms: number): number {
  return Math.round(ms / FIVE_MIN_MS) * FIVE_MIN_MS;
}

export function formatTimeShort(ms: number): string {
  return new Date(ms).toLocaleTimeString([], {
    hour: 'numeric',
    minute: '2-digit',
  });
}

export function getWindowBounds(dateKey: string, wakeTime: string, bedTime: string) {
  const [y, m, d] = dateKey.split('-').map(Number);
  const base = new Date(y, (m || 1) - 1, d || 1, 0, 0, 0, 0).getTime();
  const wakeMin = parseTimeMinutes(wakeTime);
  let bedMin = parseTimeMinutes(bedTime);
  if (bedMin <= wakeMin) {
    bedMin += 24 * 60;
  }

  const wakeMs = base + wakeMin * 60 * 1000;
  const bedMs = base + bedMin * 60 * 1000;
  const windowStartMs = wakeMs + 30 * 60 * 1000;
  const windowEndMs = Math.max(windowStartMs + 60 * 60 * 1000, bedMs - 90 * 60 * 1000);

  return { wakeMs, bedMs, windowStartMs, windowEndMs };
}

export type NotificationCase =
  | 'slot'
  | 'followup'
  | 'missed'
  | 'streak_risk'
  | 'pattern'
  | 'goal_hit';

export function getNotificationCopy(
  tone: NotificationTone,
  kind: NotificationCase,
  ctx: { ml?: number; streak?: number; remainingMl?: number; extraCount?: number } = {}
): { title: string; body: string } {
  const ml = ctx.ml ?? 250;
  const streak = ctx.streak ?? 1;
  const remainingMl = ctx.remainingMl ?? 500;
  const extraCount = ctx.extraCount ?? 2;

  let title = 'Sip time';
  let body = `${ml} ml keeps your afternoon easy.`;

  if (kind === 'missed') {
    title = 'Still here';
    body = `No stress. I moved your plan: ${extraCount} small sips to stay on pace.`;
  } else if (kind === 'streak_risk') {
    title = `Day ${streak} is on the line`;
    body = `${remainingMl} ml to go. You've got time.`;
  } else if (kind === 'pattern') {
    title = 'I noticed something';
    body = 'Mornings are your best time. Let’s front-load today.';
  } else if (kind === 'goal_hit') {
    title = 'You did it';
    body = `Goal reached. That's day ${streak} in a row.`;
  } else if (kind === 'followup') {
    title = tone === 'coach' ? `Still open: ${ml} ml` : 'Gentle check-in';
    body =
      tone === 'gentle'
        ? `Whenever you're ready, ${ml} ml is waiting.`
        : `A quick ${ml} ml sip keeps your rhythm smooth.`;
  } else if (tone === 'gentle') {
    title = 'Sip time';
    body = `A little ${ml} ml now keeps the day easy.`;
  } else if (tone === 'playful') {
    title = 'Sippy is parched';
    body = `${ml} ml and I'll stop dramatically fainting.`;
  } else {
    title = `Next ${ml} ml`;
    body = `Stay steady on pace. Log ${ml} ml now.`;
  }

  return {
    title: title.slice(0, 60),
    body: body.slice(0, 110),
  };
}

export interface BuildScheduleInput {
  uid: string;
  dateKey: string;
  goalMl: number;
  loggedMl: number;
  defaultGlassMl: number;
  wakeTime: string;
  bedTime: string;
  maxPushPerDay: number;
  tone: NotificationTone;
  nowMs: number;
  existingSlots?: ReminderSlot[];
  aiTweaks?: ScheduleTweak[];
}

export function buildScheduleSlots(input: BuildScheduleInput): ReminderSlot[] {
  const {
    uid,
    dateKey,
    goalMl,
    loggedMl,
    defaultGlassMl,
    wakeTime,
    bedTime,
    maxPushPerDay,
    tone,
    nowMs,
    existingSlots = [],
    aiTweaks = [],
  } = input;

  const { windowStartMs, windowEndMs } = getWindowBounds(dateKey, wakeTime, bedTime);
  const fixedSlots = existingSlots
    .filter((s) => s.date === dateKey && s.status !== 'pending')
    .sort((a, b) => a.notifyAt - b.notifyAt);

  const remainingMl = Math.max(0, goalMl - loggedMl);
  if (remainingMl <= 0) {
    return fixedSlots;
  }

  const pushCap = Math.min(12, Math.max(3, maxPushPerDay));
  const usedPushBudget = fixedSlots.length;
  const availableBudget = Math.max(0, pushCap - usedPushBudget);
  if (availableBudget === 0) {
    return fixedSlots;
  }

  const usedIds = new Set(fixedSlots.map((s) => s.id));
  const latestFixedAt =
    fixedSlots.length > 0 ? fixedSlots[fixedSlots.length - 1].notifyAt : 0;

  const safeGlass = Math.max(50, Math.min(1500, defaultGlassMl || 250));
  const baseStart = snapTo5Min(Math.max(windowStartMs, nowMs + 15 * 60 * 1000));
  const startCursor =
    latestFixedAt > 0
      ? Math.max(baseStart, snapTo5Min(latestFixedAt + MIN_SLOT_GAP_MS))
      : baseStart;
  if (startCursor >= windowEndMs) {
    return fixedSlots;
  }

  const spanMs = windowEndMs - startCursor;
  const maxSlotsByGap = Math.max(1, Math.floor(spanMs / MIN_SLOT_GAP_MS) + 1);
  const desiredCount = Math.ceil(remainingMl / safeGlass);
  const count = Math.max(1, Math.min(desiredCount, availableBudget, maxSlotsByGap));

  // Front-load ~55% of remaining hydration in the first half of the remaining window
  const midCount = Math.max(1, Math.ceil(count / 2));
  const firstHalfTotal = count > 1 ? Math.round(remainingMl * 0.55) : remainingMl;
  const secondHalfTotal = Math.max(0, remainingMl - firstHalfTotal);

  const generated: ReminderSlot[] = [];
  for (let i = 0; i < count; i++) {
    const ratio = count === 1 ? 0 : i / (count - 1);
    let notifyAt = snapTo5Min(startCursor + ratio * spanMs);

    // Apply optional AI hourly shift if valid within window and gap
    const hour = new Date(notifyAt).getHours();
    const tweak = aiTweaks.find((t) => t.hour === hour);
    if (tweak) {
      const shifted = snapTo5Min(notifyAt + tweak.shiftMinutes * 60 * 1000);
      if (shifted >= startCursor && shifted <= windowEndMs) {
        notifyAt = shifted;
      }
    }

    // Enforce minimum 45-minute gap from previous slot
    if (generated.length > 0) {
      const prevAt = generated[generated.length - 1].notifyAt;
      if (notifyAt - prevAt < MIN_SLOT_GAP_MS) {
        notifyAt = snapTo5Min(prevAt + MIN_SLOT_GAP_MS);
      }
    }
    if (notifyAt > windowEndMs) {
      break;
    }

    const isFirstHalf = i < midCount;
    const halfSlots = isFirstHalf ? midCount : Math.max(1, count - midCount);
    const halfBudget = isFirstHalf ? firstHalfTotal : secondHalfTotal;
    const rawMl = Math.round(halfBudget / halfSlots / 10) * 10;
    const targetMl = Math.max(50, Math.min(1500, rawMl || safeGlass));
    const copy = getNotificationCopy(tone, 'slot', { ml: targetMl });

    let candidateId = `slot_${dateKey}_${i}_${notifyAt}`;
    let bump = 1;
    while (usedIds.has(candidateId)) {
      candidateId = `slot_${dateKey}_${i}_${notifyAt}_${bump++}`;
    }
    usedIds.add(candidateId);

    generated.push({
      id: candidateId,
      uid,
      date: dateKey,
      notifyAt,
      targetMl,
      status: 'pending',
      title: copy.title,
      body: copy.body,
      notified: false,
      createdAt: nowMs,
      updatedAt: nowMs,
    });
  }

  return [...fixedSlots, ...generated].sort((a, b) => a.notifyAt - b.notifyAt);
}

export interface ShiftPlanInput {
  uid: string;
  dateKey: string;
  slots: ReminderSlot[];
  goalMl: number;
  loggedMl: number;
  wakeTime: string;
  bedTime: string;
  maxPushPerDay: number;
  tone: NotificationTone;
  nowMs: number;
  skipSlotId?: string;
}

export function shiftPlanForMissedSlots(input: ShiftPlanInput): {
  slots: ReminderSlot[];
  shiftedCount: number;
  newlyMissedCount: number;
} {
  const {
    uid,
    dateKey,
    slots,
    goalMl,
    loggedMl,
    wakeTime,
    bedTime,
    maxPushPerDay,
    tone,
    nowMs,
    skipSlotId,
  } = input;

  const { windowEndMs } = getWindowBounds(dateKey, wakeTime, bedTime);
  const pushCap = Math.min(12, Math.max(3, maxPushPerDay));
  let newlyMissedCount = 0;
  let missedMl = 0;
  let latestMissedAt = 0;

  const updated = slots.map((slot) => {
    if (slot.date !== dateKey) return slot;
    if (skipSlotId && slot.id === skipSlotId && slot.status === 'pending') {
      newlyMissedCount += 1;
      missedMl += slot.targetMl;
      latestMissedAt = Math.max(latestMissedAt, slot.notifyAt);
      return { ...slot, status: 'skipped' as const, updatedAt: nowMs };
    }
    if (
      slot.status === 'pending' &&
      (slot.notified || slot.notifyAt < nowMs) &&
      nowMs - slot.notifyAt >= MISSED_CUTOFF_MS
    ) {
      newlyMissedCount += 1;
      missedMl += slot.targetMl;
      latestMissedAt = Math.max(latestMissedAt, slot.notifyAt);
      return { ...slot, status: 'missed' as const, updatedAt: nowMs };
    }
    return slot;
  });

  if (newlyMissedCount === 0 || loggedMl >= goalMl) {
    return { slots: updated, shiftedCount: 0, newlyMissedCount };
  }

  const remainingNeeded = Math.max(0, goalMl - loggedMl);
  let toRedistribute = Math.min(missedMl, remainingNeeded);
  let shiftedCount = 0;

  const pendingIndices = updated
    .map((s, idx) => ({ s, idx }))
    .filter(({ s }) => s.date === dateKey && s.status === 'pending' && s.notifyAt >= nowMs - 10 * 60 * 1000)
    .sort((a, b) => a.s.notifyAt - b.s.notifyAt);

  for (const { idx } of pendingIndices) {
    if (toRedistribute <= 0) break;
    const slot = updated[idx];
    const maxIncrease = Math.round(slot.targetMl * 0.5);
    const addMl = Math.min(toRedistribute, maxIncrease);
    if (addMl > 0) {
      const nextTarget = Math.min(1500, slot.targetMl + addMl);
      const copy = getNotificationCopy(tone, 'missed', {
        ml: nextTarget,
        extraCount: pendingIndices.length,
      });
      updated[idx] = {
        ...slot,
        targetMl: nextTarget,
        movedFrom: slot.movedFrom ?? latestMissedAt,
        title: copy.title,
        body: copy.body,
        updatedAt: nowMs,
      };
      toRedistribute -= addMl;
      shiftedCount += 1;
    }
  }

  // If no room in existing pending slots, add up to 2 small extra slots before window end
  const usedIds = new Set(updated.map((s) => s.id));
  let extraAdded = 0;
  while (toRedistribute >= 50 && extraAdded < 2 && updated.length < pushCap) {
    const lastPending = [...updated]
      .filter((s) => s.date === dateKey)
      .sort((a, b) => b.notifyAt - a.notifyAt)[0];
    const candidateAt = snapTo5Min(
      Math.max(nowMs + 20 * 60 * 1000, (lastPending?.notifyAt ?? nowMs) + MIN_SLOT_GAP_MS)
    );
    if (candidateAt > windowEndMs) break;

    const addMl = Math.min(200, Math.max(100, Math.round(toRedistribute / 10) * 10));
    const copy = getNotificationCopy(tone, 'missed', { ml: addMl, extraCount: 2 - extraAdded });
    let extraId = `slot_extra_${dateKey}_${candidateAt}_${extraAdded}`;
    let suffix = 1;
    while (usedIds.has(extraId)) {
      extraId = `slot_extra_${dateKey}_${candidateAt}_${extraAdded}_${suffix++}`;
    }
    usedIds.add(extraId);

    updated.push({
      id: extraId,
      uid,
      date: dateKey,
      notifyAt: candidateAt,
      targetMl: addMl,
      status: 'pending',
      movedFrom: latestMissedAt || nowMs,
      title: copy.title,
      body: copy.body,
      notified: false,
      createdAt: nowMs,
      updatedAt: nowMs,
    });
    toRedistribute -= addMl;
    extraAdded += 1;
    shiftedCount += 1;
  }

  return {
    slots: updated.sort((a, b) => a.notifyAt - b.notifyAt),
    shiftedCount,
    newlyMissedCount,
  };
}

export function adjustScheduleForIntake(input: {
  slots: ReminderSlot[];
  dateKey: string;
  goalMl: number;
  newTotalLoggedMl: number;
  nowMs: number;
  tone: NotificationTone;
}): ReminderSlot[] {
  const { slots, dateKey, goalMl, newTotalLoggedMl, nowMs, tone } = input;
  const remainingMl = Math.max(0, goalMl - newTotalLoggedMl);

  let markedDone = false;
  const nextSlots = slots
    .map((slot) => {
      if (slot.date !== dateKey || slot.status !== 'pending') return slot;
      if (!markedDone && Math.abs(slot.notifyAt - nowMs) <= 60 * 60 * 1000) {
        markedDone = true;
        return { ...slot, status: 'done' as const, updatedAt: nowMs };
      }
      return slot;
    })
    .sort((a, b) => a.notifyAt - b.notifyAt);

  // If no slot was within 60m, complete the earliest pending slot
  if (!markedDone) {
    const firstPendingIdx = nextSlots.findIndex(
      (s) => s.date === dateKey && s.status === 'pending'
    );
    if (firstPendingIdx !== -1) {
      nextSlots[firstPendingIdx] = {
        ...nextSlots[firstPendingIdx],
        status: 'done',
        updatedAt: nowMs,
      };
    }
  }

  // Trim or shrink remaining pending slots to match remainingMl
  let budgetLeft = remainingMl;
  const result: ReminderSlot[] = [];
  for (const slot of nextSlots) {
    if (slot.date !== dateKey || slot.status !== 'pending') {
      result.push(slot);
      continue;
    }
    if (budgetLeft <= 0) {
      continue;
    }
    if (slot.targetMl > budgetLeft) {
      const shrunk = Math.max(50, Math.round(budgetLeft / 10) * 10);
      const copy = getNotificationCopy(tone, 'slot', { ml: shrunk });
      result.push({
        ...slot,
        targetMl: shrunk,
        title: copy.title,
        body: copy.body,
        updatedAt: nowMs,
      });
      budgetLeft = 0;
    } else {
      result.push(slot);
      budgetLeft -= slot.targetMl;
    }
  }

  return result;
}
