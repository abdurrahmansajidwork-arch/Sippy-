import type {
  AchievementIconKey,
  AchievementPaletteKey,
  BadgeProgressInfo,
  CustomBadge,
  CustomBadgeRuleType,
  CustomBadgeStatus,
  DaySummary,
  HydrationLog,
} from '../types';

export const ACHIEVEMENT_PALETTES: Record<
  AchievementPaletteKey,
  { label: string; from: string; to: string; edge: string }
> = {
  brand: { label: 'Ocean', from: '#6C93FA', to: '#3D6EF5', edge: '#2347B8' },
  water: { label: 'Sky', from: '#6FD3FF', to: '#19B4F2', edge: '#0E8AC0' },
  mint: { label: 'Mint', from: '#47D6A0', to: '#22B07D', edge: '#178A62' },
  flame: { label: 'Ember', from: '#FFB347', to: '#FF6B2C', edge: '#CC4E19' },
  lav: { label: 'Iris', from: '#A396FA', to: '#7C6CF2', edge: '#5848C7' },
};

export function createStarterCustomBadges(nowMs = Date.now()): CustomBadge[] {
  return [
    {
      id: 'custom_starter_5day',
      title: '5-Day Rhythm',
      ruleType: 'streak_days',
      targetValue: 5,
      icon: 'star',
      palette: 'lav',
      createdAt: nowMs,
    },
  ];
}

export function computeStreakAchievements(params: {
  days: DaySummary[];
  logs: HydrationLog[];
  currentStreak: number;
  bestStreak: number;
}): BadgeProgressInfo[] {
  const { days, logs, currentStreak, bestStreak } = params;
  const peakStreak = Math.max(currentStreak, bestStreak);
  const goalHitDays = days.filter((d) => d.hit).length;

  const morningTotals = new Map<string, number>();
  for (const l of logs) {
    if (new Date(l.ts).getHours() < 10) {
      morningTotals.set(l.date, (morningTotals.get(l.date) || 0) + l.countedMl);
    }
  }
  const bestMorningMl = Math.max(0, ...morningTotals.values());

  const defs: Array<{
    id: BadgeProgressInfo['id'];
    title: string;
    description: string;
    category: 'streak' | 'habit';
    currentValue: number;
    targetValue: number;
    unitLabel: string;
    palette: AchievementPaletteKey;
    icon: AchievementIconKey;
    unlockedOverride?: boolean;
  }> = [
    {
      id: 'first_sip',
      title: 'First Sip',
      description: 'Log your very first drink',
      category: 'habit',
      currentValue: Math.min(1, logs.length),
      targetValue: 1,
      unitLabel: 'drink',
      palette: 'water',
      icon: 'droplet',
      unlockedOverride: logs.length > 0,
    },
    {
      id: 'streak_3',
      title: '3-Day Flow',
      description: 'Reach a 3-day hydration streak',
      category: 'streak',
      currentValue: peakStreak,
      targetValue: 3,
      unitLabel: 'days',
      palette: 'flame',
      icon: 'flame',
    },
    {
      id: 'streak_7',
      title: '7-Day Wave',
      description: 'Keep your streak going for 7 days',
      category: 'streak',
      currentValue: peakStreak,
      targetValue: 7,
      unitLabel: 'days',
      palette: 'brand',
      icon: 'star',
    },
    {
      id: 'streak_14',
      title: '14-Day Surge',
      description: 'Two steady weeks of hitting goal',
      category: 'streak',
      currentValue: peakStreak,
      targetValue: 14,
      unitLabel: 'days',
      palette: 'mint',
      icon: 'shield',
    },
    {
      id: 'streak_30',
      title: '30-Day Ocean',
      description: 'A full month of consistent hydration',
      category: 'streak',
      currentValue: peakStreak,
      targetValue: 30,
      unitLabel: 'days',
      palette: 'lav',
      icon: 'trophy',
    },
    {
      id: 'early_bird',
      title: 'Early Bird',
      description: 'Log 500 ml before 10:00 AM',
      category: 'habit',
      currentValue: Math.min(500, bestMorningMl),
      targetValue: 500,
      unitLabel: 'ml',
      palette: 'flame',
      icon: 'sun',
      unlockedOverride: bestMorningMl >= 500,
    },
    {
      id: 'perfect_week',
      title: 'Perfect Week',
      description: '7 consecutive days without a miss',
      category: 'streak',
      currentValue: peakStreak,
      targetValue: 7,
      unitLabel: 'days',
      palette: 'mint',
      icon: 'sparkles',
    },
    {
      id: 'hydration_hero',
      title: '10 Goals Hit',
      description: 'Hit your daily goal 10 total times',
      category: 'habit',
      currentValue: goalHitDays,
      targetValue: 10,
      unitLabel: 'goals',
      palette: 'brand',
      icon: 'trophy',
    },
  ];

  return defs.map((d) => {
    const unlocked = d.unlockedOverride ?? d.currentValue >= d.targetValue;
    const progressPct = unlocked
      ? 100
      : Math.min(99, Math.round((Math.max(0, d.currentValue) / Math.max(1, d.targetValue)) * 100));
    return {
      id: d.id,
      title: d.title,
      description: d.description,
      unlocked,
      category: d.category,
      currentValue: Math.min(d.targetValue, Math.max(0, d.currentValue)),
      targetValue: d.targetValue,
      unitLabel: d.unitLabel,
      progressPct,
      palette: d.palette,
      icon: d.icon,
    };
  });
}

export function validateCustomBadgeInput(params: {
  title: string;
  targetValue: number;
  ruleType: CustomBadgeRuleType;
}): {
  valid: boolean;
  error?: string;
  cleanTitle: string;
  cleanTarget: number;
} {
  const cleanTitle = params.title.trim().replace(/\s+/g, ' ');
  if (!cleanTitle) {
    return {
      valid: false,
      error: 'Give your badge a short name (e.g. 5-Day Focus).',
      cleanTitle: '',
      cleanTarget: 3,
    };
  }
  if (cleanTitle.length > 28) {
    return {
      valid: false,
      error: 'Badge name must be 28 characters or fewer.',
      cleanTitle: cleanTitle.slice(0, 28),
      cleanTarget: params.targetValue,
    };
  }
  const maxTarget = params.ruleType === 'streak_days' ? 365 : 500;
  const rawNum = Number(params.targetValue);
  if (!Number.isFinite(rawNum) || rawNum < 1) {
    return {
      valid: false,
      error: 'Target must be at least 1.',
      cleanTitle,
      cleanTarget: 1,
    };
  }
  const cleanTarget = Math.min(maxTarget, Math.max(1, Math.round(rawNum)));
  return {
    valid: true,
    cleanTitle,
    cleanTarget,
  };
}

export function evaluateCustomBadges(
  customBadges: CustomBadge[],
  metrics: {
    currentStreak: number;
    bestStreak: number;
    totalLogsCount: number;
  }
): CustomBadgeStatus[] {
  const peakStreak = Math.max(metrics.currentStreak, metrics.bestStreak);

  return customBadges.map((badge) => {
    const rawCurrent =
      badge.ruleType === 'streak_days' ? peakStreak : Math.max(0, metrics.totalLogsCount);
    const unlocked = rawCurrent >= badge.targetValue;
    const currentValue = Math.min(badge.targetValue, Math.max(0, rawCurrent));
    const progressPct = unlocked
      ? 100
      : Math.min(99, Math.round((currentValue / Math.max(1, badge.targetValue)) * 100));

    return {
      badge,
      currentValue,
      progressPct,
      unlocked,
    };
  });
}
