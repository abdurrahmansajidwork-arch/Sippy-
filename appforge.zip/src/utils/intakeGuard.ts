import type { DrinkType } from '../types';
import { calculateCountedMl } from './patternEngine';

export interface IntakeSafetyEvaluation {
  countedAddMl: number;
  projectedTotalMl: number;
  excessToleranceMl: number;
  overLimitThresholdMl: number;
  isNearMaxGoal: boolean;
  breaksTooMuch: boolean;
  needsConfirmation: boolean;
  excessOverGoalMl: number;
  reason: 'safe' | 'near_goal' | 'over_goal' | 'breaks_too_much';
}

export interface CurrentIntakeWarningState {
  isNearGoal: boolean;
  isGoalMet: boolean;
  breaksTooMuch: boolean;
  excessOverGoalMl: number;
  overLimitThresholdMl: number;
  badgeText: string | null;
}

/**
 * Computes the soft upper tolerance above the user's daily hydration goal
 * before Sippy considers additional drinks as breaking too far past the goal.
 */
export function getOverGoalToleranceMl(goalMl: number): number {
  const safeGoal = Math.max(500, Math.round(goalMl));
  return Math.max(500, Math.round((safeGoal * 0.2) / 50) * 50);
}

/**
 * Evaluates current daily hydration total against the daily goal to determine
 * whether a passive warning badge should appear in the UI.
 */
export function getCurrentIntakeStatus(
  currentTotalMl: number,
  goalMl: number
): CurrentIntakeWarningState {
  const safeGoal = Math.max(500, Math.round(goalMl));
  const tolerance = getOverGoalToleranceMl(safeGoal);
  const overLimitThresholdMl = safeGoal + tolerance;
  const nearThreshold = Math.round(safeGoal * 0.88);

  const isNearGoal = currentTotalMl >= nearThreshold && currentTotalMl < safeGoal;
  const isGoalMet = currentTotalMl >= safeGoal && currentTotalMl <= overLimitThresholdMl;
  const breaksTooMuch = currentTotalMl > overLimitThresholdMl;
  const excessOverGoalMl = Math.max(0, Math.round(currentTotalMl - safeGoal));

  return {
    isNearGoal,
    isGoalMet,
    breaksTooMuch,
    excessOverGoalMl,
    overLimitThresholdMl,
    badgeText: breaksTooMuch
      ? `Well over goal (+${excessOverGoalMl.toLocaleString()} ml) · Pace gently`
      : null,
  };
}

/**
 * Evaluates whether adding a drink requires a user confirmation prompt
 * (near max goal or exceeding goal) and/or a warning badge (breaks too far past goal).
 */
export function evaluateIntakeSafety(
  currentTotalMl: number,
  addMl: number,
  goalMl: number,
  drinkType: DrinkType = 'water'
): IntakeSafetyEvaluation {
  const safeGoal = Math.max(500, Math.round(goalMl));
  const countedAddMl = calculateCountedMl(Math.max(1, Math.round(addMl)), drinkType);
  const projectedTotalMl = Math.max(0, Math.round(currentTotalMl)) + countedAddMl;

  const excessToleranceMl = getOverGoalToleranceMl(safeGoal);
  const overLimitThresholdMl = safeGoal + excessToleranceMl;
  const nearGoalStartMl = Math.round(safeGoal * 0.88);

  const isNearMaxGoal =
    currentTotalMl >= nearGoalStartMl || projectedTotalMl > safeGoal;
  const breaksTooMuch = projectedTotalMl > overLimitThresholdMl;
  const needsConfirmation = isNearMaxGoal || breaksTooMuch;
  const excessOverGoalMl = Math.max(0, projectedTotalMl - safeGoal);

  let reason: IntakeSafetyEvaluation['reason'] = 'safe';
  if (breaksTooMuch) {
    reason = 'breaks_too_much';
  } else if (projectedTotalMl > safeGoal) {
    reason = 'over_goal';
  } else if (isNearMaxGoal) {
    reason = 'near_goal';
  }

  return {
    countedAddMl,
    projectedTotalMl,
    excessToleranceMl,
    overLimitThresholdMl,
    isNearMaxGoal,
    breaksTooMuch,
    needsConfirmation,
    excessOverGoalMl,
    reason,
  };
}
