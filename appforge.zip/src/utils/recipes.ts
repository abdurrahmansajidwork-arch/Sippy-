import type { DrinkType, HydrationRecipe, RecipeCategory } from '../types';

export const MYSTERY_BOX_COST = 10;
export const GOAL_HIT_BASE_TOKENS = 5;
export const STREAK_BONUS_TOKENS = 2;

export const RECIPE_CATEGORY_LABELS: Record<RecipeCategory, string> = {
  coffee: 'Water & Coffee',
  infused: 'Infused Water',
  tea: 'Botanical Tea',
  sparkling: 'Sparkling Tonic',
};

export const RECIPE_DRINK_TYPE: Record<RecipeCategory, DrinkType> = {
  coffee: 'coffee',
  infused: 'water',
  tea: 'tea',
  sparkling: 'sparkling',
};

export const WATER_RECIPES: HydrationRecipe[] = [
  {
    id: 'espresso_yuzu_fizz',
    title: 'Sparkling Yuzu Espresso Tonic',
    category: 'coffee',
    tagline: 'Bright citrus sparkling water layered under crisp espresso.',
    waterMl: 260,
    prepMinutes: 3,
    accentBg: 'var(--tile-flame)',
    accentColor: '#D95B16',
    ingredients: [
      '220 ml chilled sparkling water',
      '40 ml fresh espresso (or strong coffee)',
      '1 tsp yuzu or lemon juice + zest',
      '4–5 clear ice cubes',
    ],
    steps: [
      'Fill a tall glass with ice and pour in the cold sparkling water.',
      'Stir in the yuzu juice gently to keep the fizz lively.',
      'Slowly pour the espresso over the back of a spoon to float on top.',
    ],
    hydrationTip: 'Pairs morning coffee rituals with over a full glass of sparkling water.',
  },
  {
    id: 'cardamom_cold_brew',
    title: 'Honey Cardamom Iced Americano',
    category: 'coffee',
    tagline: 'Silky chilled water, crushed cardamom, and warm floral honey.',
    waterMl: 280,
    prepMinutes: 4,
    accentBg: 'var(--tile-lav)',
    accentColor: '#6252D6',
    ingredients: [
      '240 ml filtered cold water',
      '45 ml double-shot espresso or cold brew concentrate',
      '1 tsp wildflower honey',
      '1 lightly crushed green cardamom pod',
    ],
    steps: [
      'Whisk the honey into 2 tbsp warm water until completely dissolved.',
      'Pour over ice with the cold filtered water and crushed cardamom.',
      'Top with espresso and stir slowly for an aromatic finish.',
    ],
    hydrationTip: 'Extra cold water dilutes acidity for a smooth, hydrating afternoon lift.',
  },
  {
    id: 'coconut_americano_cloud',
    title: 'Toasted Coconut Water Americano',
    category: 'coffee',
    tagline: 'Half crisp spring water, half coconut water over dark roast.',
    waterMl: 300,
    prepMinutes: 3,
    accentBg: 'var(--tile-water)',
    accentColor: '#0E8AC4',
    ingredients: [
      '150 ml cold spring water',
      '120 ml pure unsweetened coconut water',
      '40 ml chilled espresso',
      'Pinch of sea salt',
    ],
    steps: [
      'Combine the spring water, coconut water, and salt over ice.',
      'Pour chilled espresso over the top and watch it marble.',
      'Give one gentle swirl before sipping.',
    ],
    hydrationTip: 'Adds natural potassium electrolytes alongside refreshing water.',
  },
  {
    id: 'maple_cinnamon_americano',
    title: 'Cinnamon Maple Long Black',
    category: 'coffee',
    tagline: 'Light, crisp iced water coffee with a hint of cinnamon bark.',
    waterMl: 250,
    prepMinutes: 3,
    accentBg: 'var(--tile-flame)',
    accentColor: '#C96320',
    ingredients: [
      '210 ml cold filtered water',
      '40 ml freshly pulled espresso',
      '1/2 tsp pure maple syrup',
      '1 small cinnamon stick',
    ],
    steps: [
      'Swirl maple syrup in the bottom of your glass with cold water.',
      'Add ice and tuck the cinnamon stick along the glass wall.',
      'Pull espresso directly over the cold water to lock in aroma.',
    ],
    hydrationTip: 'Zero heavy cream—keeps your hydration score crisp and light.',
  },
  {
    id: 'cucumber_mint_fresca',
    title: 'Cucumber Mint Spa Cooler',
    category: 'infused',
    tagline: 'Garden-fresh crushed cucumber water with bright lime zest.',
    waterMl: 350,
    prepMinutes: 4,
    accentBg: 'var(--tile-mint)',
    accentColor: '#178A62',
    ingredients: [
      '350 ml chilled filtered water',
      '5 thin English cucumber ribbons',
      '6 fresh mint leaves',
      'Juice of half a lime',
    ],
    steps: [
      'Lightly press the mint leaves and cucumber in your glass.',
      'Add ice, squeeze in fresh lime, and top with cold water.',
      'Let steep for 2 minutes so the crisp cucumber aroma opens up.',
    ],
    hydrationTip: 'Counts as 100% pure water and makes 350 ml disappear effortlessly.',
  },
  {
    id: 'watermelon_lime_agua',
    title: 'Watermelon Basil Agua Fresca',
    category: 'infused',
    tagline: 'Muddled summer melon shaken into ice-cold spring water.',
    waterMl: 320,
    prepMinutes: 5,
    accentBg: 'var(--coral-100)',
    accentColor: '#D94848',
    ingredients: [
      '300 ml ice-cold water',
      '1/2 cup ripe cubed watermelon',
      '3 sweet basil leaves',
      'Squeeze of fresh lime + tiny pinch of sea salt',
    ],
    steps: [
      'Mudddle watermelon cubes and basil gently in a shaker or jar.',
      'Add cold water, lime, and sea salt, then shake with ice for 10 seconds.',
      'Strain into a tall glass over fresh ice.',
    ],
    hydrationTip: 'Naturally sweet without syrups—great post-walk refresher.',
  },
  {
    id: 'grapefruit_rosemary_sparkle',
    title: 'Rosemary Pink Grapefruit Splash',
    category: 'sparkling',
    tagline: 'Botanical sparkling water lifted by ruby citrus and piney herb.',
    waterMl: 300,
    prepMinutes: 3,
    accentBg: 'var(--tile-flame)',
    accentColor: '#D95B16',
    ingredients: [
      '260 ml chilled sparkling mineral water',
      '40 ml fresh pink grapefruit juice',
      '1 small sprig fresh rosemary',
      'Crushed ice',
    ],
    steps: [
      'Gently clap the rosemary sprig between your palms to release oils.',
      'Drop into a glass with crushed ice and grapefruit juice.',
      'Top with cold sparkling water and stir once from the bottom.',
    ],
    hydrationTip: 'Sparkling mineral water delivers crisp texture with full hydration.',
  },
  {
    id: 'blueberry_lemon_infusion',
    title: 'Crushed Blueberry Lemon Carafe',
    category: 'infused',
    tagline: 'Jewel-toned berry water bright with Meyer lemon slices.',
    waterMl: 400,
    prepMinutes: 4,
    accentBg: 'var(--tile-lav)',
    accentColor: '#5B4CE0',
    ingredients: [
      '400 ml chilled water',
      '12 fresh blueberries, lightly pressed',
      '2 thin lemon wheels',
      'Optional 1 tsp chia seeds',
    ],
    steps: [
      'Press blueberries lightly with the back of a spoon in your pitcher.',
      'Add lemon slices and pour in 400 ml cold water.',
      'Chill 5 minutes (or sip immediately) for gentle berry sweetness.',
    ],
    hydrationTip: 'Brewing a 400 ml carafe helps you finish a third of your afternoon goal.',
  },
  {
    id: 'hibiscus_ginger_tonic',
    title: 'Hibiscus Ginger Ice Tea',
    category: 'tea',
    tagline: 'Ruby-red caffeine-free hibiscus steeped in cool spiced water.',
    waterMl: 320,
    prepMinutes: 6,
    accentBg: 'var(--coral-100)',
    accentColor: '#D94848',
    ingredients: [
      '320 ml filtered water (half warm, half chilled)',
      '1 tbsp dried hibiscus petals (or 1 tea bag)',
      '3 thin coins fresh ginger',
      '1/2 tsp agave or honey (optional)',
    ],
    steps: [
      'Steep hibiscus and ginger in 120 ml hot water for 4 minutes.',
      'Strain into a tall glass packed with ice and 200 ml cold water.',
      'Swirl until ruby bright and frosty.',
    ],
    hydrationTip: 'Caffeine-free herbal infusion counts strongly toward evening hydration.',
  },
  {
    id: 'matcha_mint_mist',
    title: 'Matcha Mint Coconut Water',
    category: 'tea',
    tagline: 'Crisp whisked green tea layered over cool botanical water.',
    waterMl: 280,
    prepMinutes: 4,
    accentBg: 'var(--tile-mint)',
    accentColor: '#178A62',
    ingredients: [
      '200 ml cold filtered water + 80 ml coconut water',
      '1 tsp ceremonial matcha powder',
      '40 ml warm water (75°C) for whisking',
      '3 fresh mint leaves',
    ],
    steps: [
      'Whisk matcha in 40 ml warm water until smooth and frothy.',
      'Pour cold filtered water and coconut water over ice and mint.',
      'Float the vibrant green matcha slowly over the clear base.',
    ],
    hydrationTip: 'Gentle calm focus paired with steady water volume.',
  },
  {
    id: 'roasted_barley_vanilla',
    title: 'Cold-Steeped Vanilla Mugicha',
    category: 'tea',
    tagline: 'Toasty, nutty Japanese barley water with subtle vanilla bean.',
    waterMl: 350,
    prepMinutes: 5,
    accentBg: 'var(--tile-water)',
    accentColor: '#1986C4',
    ingredients: [
      '350 ml cold filtered water',
      '1 roasted barley (mugicha) tea bag',
      '1 drop pure vanilla extract',
      'Ice cubes',
    ],
    steps: [
      'Drop the barley tea bag into cold water and steep 5 minutes (or overnight).',
      'Remove the bag, add a tiny drop of vanilla, and pour over ice.',
      'Enjoy a coffee-like roasted depth with zero caffeine.',
    ],
    hydrationTip: '100% caffeine-free roasted refreshment ideal even right before bed.',
  },
  {
    id: 'pineapple_jalapeno_fizz',
    title: 'Pineapple Mint Sparkling Water',
    category: 'sparkling',
    tagline: 'Tropical sparkling splash that wakes up afternoon sluggishness.',
    waterMl: 300,
    prepMinutes: 3,
    accentBg: 'var(--tile-water)',
    accentColor: '#1986C4',
    ingredients: [
      '270 ml icy sparkling water',
      '30 ml fresh pineapple juice',
      '4 bruised mint leaves',
      'Lime wedge',
    ],
    steps: [
      'Clap the mint leaves and place at the bottom of a chilled glass.',
      'Add pineapple juice, ice, and sparkling mineral water.',
      'Finish with a quick squeeze of lime.',
    ],
    hydrationTip: 'Just 30 ml juice turns plain bubbly water into a treat.',
  },
];

export function computeGoalRewardTokens(currentStreak: number): number {
  const streakBonus = currentStreak >= 3 ? STREAK_BONUS_TOKENS : 0;
  return GOAL_HIT_BASE_TOKENS + streakBonus;
}

export function canOpenMysteryBox(tokens: number): boolean {
  return tokens >= MYSTERY_BOX_COST;
}

export function pickMysteryRecipe(
  unlockedRecipeIds: string[],
  rng: () => number = Math.random
): HydrationRecipe {
  const unlockedSet = new Set(unlockedRecipeIds);
  const uncollected = WATER_RECIPES.filter((r) => !unlockedSet.has(r.id));
  const pool = uncollected.length > 0 ? uncollected : WATER_RECIPES;
  const idx = Math.min(pool.length - 1, Math.max(0, Math.floor(rng() * pool.length)));
  return pool[idx];
}
