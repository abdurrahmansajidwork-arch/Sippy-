import type { HydrationCalculatorInput, WorkoutLevel } from '../types';

export interface HydrationGoalCalculation {
  goalMl: number;
  baseMl: number;
  activityBonusMl: number;
  glassesOf250Ml: number;
  tierLabel: string;
}

const SESSION_ML_BY_LEVEL: Record<WorkoutLevel, number> = {
  light: 300,
  moderate: 500,
  intense: 750,
};

export function clampCalculatorInput(input: HydrationCalculatorInput): HydrationCalculatorInput {
  return {
    age: Math.max(12, Math.min(95, Math.round(input.age))),
    weightKg: Math.max(35, Math.min(180, Math.round(input.weightKg))),
    heightCm: Math.max(120, Math.min(220, Math.round(input.heightCm))),
    workoutLevel: input.workoutLevel,
    workoutsPerWeek: Math.max(0, Math.min(7, Math.round(input.workoutsPerWeek))),
  };
}

/**
 * Computes a daily fluid goal in ml using:
 * - Weight baseline (~32 ml/kg)
 * - Height body-frame adjustment (+/- relative to 170 cm)
 * - Age turnover factor (<30 +4%, 30-55 baseline, >55 -5%)
 * - Weekly workout intensity & frequency fluid replacement
 */
export function calculateRecommendedWaterGoal(
  rawInput: HydrationCalculatorInput
): HydrationGoalCalculation {
  const input = clampCalculatorInput(rawInput);

  const ageFactor = input.age < 30 ? 1.04 : input.age <= 55 ? 1.0 : 0.95;
  const heightOffsetMl = Math.max(-150, Math.min(250, (input.heightCm - 170) * 4));

  const rawBase = input.weightKg * 32 * ageFactor + heightOffsetMl;
  const baseMl = Math.max(1400, Math.min(3800, Math.round(rawBase / 50) * 50));

  const perSessionMl = SESSION_ML_BY_LEVEL[input.workoutLevel] ?? 500;
  const rawActivity = (input.workoutsPerWeek / 7) * perSessionMl;
  const activityBonusMl =
    input.workoutsPerWeek === 0 ? 0 : Math.max(50, Math.round(rawActivity / 50) * 50);

  const totalUnclamped = Math.round((baseMl + activityBonusMl) / 50) * 50;
  const goalMl = Math.max(1500, Math.min(4500, totalUnclamped));

  const tierLabel =
    input.workoutsPerWeek === 0
      ? 'Everyday steady baseline'
      : input.workoutsPerWeek >= 5 && input.workoutLevel === 'intense'
        ? 'High-output training target'
        : input.workoutsPerWeek >= 3
          ? 'Active lifestyle target'
          : 'Balanced routine target';

  return {
    goalMl,
    baseMl,
    activityBonusMl,
    glassesOf250Ml: Math.max(1, Math.round(goalMl / 250)),
    tierLabel,
  };
}
