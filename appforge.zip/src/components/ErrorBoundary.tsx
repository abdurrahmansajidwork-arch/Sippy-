import React from 'react';
import { Mascot } from './Mascot';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'Something unexpected happened.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-dvh flex flex-col items-center justify-center p-6 text-center bg-[var(--canvas)]">
          <Mascot mood="worried" size={112} />
          <h1 className="mt-4 text-xl font-bold text-[var(--ink-900)]">Sippy hit a bump</h1>
          <p className="mt-2 text-sm text-[var(--ink-500)] max-w-xs">
            {this.state.message}
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-6 h-12 px-6 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-semibold text-sm"
          >
            Reload Sippy
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
