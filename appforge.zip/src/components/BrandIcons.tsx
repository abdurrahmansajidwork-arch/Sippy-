import React, { useId } from 'react';
import type { DrinkType, GlassIconType } from '../types';

export const DropletLogoIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 24,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
    <path d="M12 2.5C12 2.5 5.5 10.2 5.5 15.1C5.5 18.8 8.4 21.5 12 21.5C15.6 21.5 18.5 18.8 18.5 15.1C18.5 10.2 12 2.5 12 2.5Z" />
  </svg>
);

export const StreakFlame: React.FC<{
  size?: number;
  shieldSaved?: boolean;
  muted?: boolean;
}> = ({ size = 28, shieldSaved = false, muted = false }) => {
  const uid = useId().replace(/:/g, '');
  const gradId = `flame-${uid}`;

  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={gradId} x1="16" y1="3" x2="16" y2="29" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={muted ? '#CBD5E1' : shieldSaved ? '#6FD3FF' : '#FFB347'} />
          <stop offset="100%" stopColor={muted ? '#94A3B8' : shieldSaved ? '#3D6EF5' : '#FF6B2C'} />
        </linearGradient>
      </defs>
      <path
        d="M16.8 3.2C16.8 3.2 25 10.2 25 18.2C25 23.8 21.1 28.5 16 28.5C10.9 28.5 7 23.8 7 18.2C7 13.7 10 9.6 11.7 8C11.9 10.4 13.4 11.7 14.3 12C14.1 8.4 16.8 3.2 16.8 3.2Z"
        fill={`url(#${gradId})`}
      />
      {!muted && (
        <path
          d="M16 17.5C16 17.5 19.2 20.1 19.2 22.8C19.2 24.8 17.8 26.2 16 26.2C14.2 26.2 12.8 24.8 12.8 22.8C12.8 20.1 16 17.5 16 17.5Z"
          fill="#FFFFFF"
          fillOpacity="0.45"
        />
      )}
    </svg>
  );
};

export const StarNodeIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 24,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
    <path d="M12 2.4L14.8 8.3L21.2 9.1L16.4 13.6L17.7 20L12 16.9L6.3 20L7.6 13.6L2.8 9.1L9.2 8.3L12 2.4Z" />
  </svg>
);

export const RewardChestIcon: React.FC<{ size?: number }> = ({ size = 40 }) => (
  <svg width={size} height={size} viewBox="0 0 44 36" fill="none" aria-hidden="true">
    <rect x="4" y="13" width="36" height="19" rx="5" fill="#FF6B2C" />
    <path d="M4 12C4 7.6 7.6 4 12 4H32C36.4 4 40 7.6 40 12V15H4V12Z" fill="#FFB347" />
    <rect x="4" y="13" width="36" height="3" fill="#E85A1D" />
    <rect x="18" y="11" width="8" height="7" rx="2" fill="#FFFFFF" />
  </svg>
);

export const SmallGlassGauge: React.FC<{
  fillLevel?: number; // 0..1
  size?: number;
  variant?: 'tumbler' | 'bottle';
}> = ({ fillLevel = 0.65, size = 26, variant = 'tumbler' }) => {
  const clamped = Math.max(0, Math.min(1, fillLevel));
  if (variant === 'bottle') {
    return (
      <svg width={size} height={size * 1.2} viewBox="0 0 28 34" fill="none" aria-hidden="true">
        <rect x="10" y="2" width="8" height="3.5" rx="1.2" fill="#B7C6E6" />
        <path
          d="M8.5 8.5C8.5 6.8 9.8 6 11.2 6H16.8C18.2 6 19.5 6.8 19.5 8.5L21 12V28C21 30.2 19.2 32 17 32H11C8.8 32 7 30.2 7 28V12L8.5 8.5Z"
          fill="#FFFFFF"
          stroke="#B7C6E6"
          strokeWidth="2"
        />
        <rect x="8.5" y={30 - clamped * 16} width="11" height={clamped * 16} rx="2" fill="#19B4F2" />
      </svg>
    );
  }
  const liqHeight = Math.round(clamped * 20);
  const liqY = 29 - liqHeight;
  return (
    <svg width={size} height={size * 1.2} viewBox="0 0 28 34" fill="none" aria-hidden="true">
      <defs>
        <clipPath id={`sm-glass-${Math.round(clamped * 100)}`}>
          <path d="M5 5H23L20.8 29C20.6 30.4 19.5 31.5 18 31.5H10C8.5 31.5 7.4 30.4 7.2 29L5 5Z" />
        </clipPath>
      </defs>
      <path
        d="M5 5H23L20.8 29C20.6 30.4 19.5 31.5 18 31.5H10C8.5 31.5 7.4 30.4 7.2 29L5 5Z"
        fill="#FFFFFF"
      />
      <g clipPath={`url(#sm-glass-${Math.round(clamped * 100)})`}>
        {liqHeight > 0 && <rect x="4" y={liqY} width="20" height={liqHeight + 4} fill="#19B4F2" />}
      </g>
      <path
        d="M5 5H23L20.8 29C20.6 30.4 19.5 31.5 18 31.5H10C8.5 31.5 7.4 30.4 7.2 29L5 5Z"
        stroke="#B7C6E6"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export const DrinkGlyph: React.FC<{
  type: DrinkType | GlassIconType;
  size?: number;
  color?: string;
}> = ({ type, size = 22, color = '#19B4F2' }) => {
  if (type === 'coffee' || type === 'mug') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M5 7H16V15C16 18 13.5 20 10.5 20C7.5 20 5 18 5 15V7Z" fill={color} />
        <path d="M16 9H18C19.6 9 20.5 10 20.5 11.5C20.5 13 19.6 14 18 14H16" stroke={color} strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  if (type === 'tea') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M4 9H17V15C17 18.3 14.3 20.5 10.5 20.5C6.7 20.5 4 18.3 4 15V9Z" fill={color} />
        <path d="M17 11H18.5C19.9 11 21 12 21 13.3C21 14.6 19.9 15.5 18.5 15.5H17" stroke={color} strokeWidth="2" />
        <path d="M8.5 4.5C8.5 6 10 6 10 7.5M12.5 4.5C12.5 6 14 6 14 7.5" stroke={color} strokeWidth="1.75" strokeLinecap="round" />
      </svg>
    );
  }
  if (type === 'bottle' || type === 'jug') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="9" y="2.5" width="6" height="3" rx="1.2" fill={color} />
        <path d="M8 7.5C8 6.5 9 6 10 6H14C15 6 16 6.5 16 7.5L17 10.5V19.5C17 20.9 15.9 22 14.5 22H9.5C8.1 22 7 20.9 7 19.5V10.5L8 7.5Z" fill={color} />
        <rect x="9" y="12" width="6" height="3" rx="1" fill="#FFFFFF" fillOpacity="0.4" />
      </svg>
    );
  }
  if (type === 'juice' || type === 'milk' || type === 'boba') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="6.5" y="7" width="11" height="14" rx="3" fill={color} />
        <path d="M12 3V7" stroke={color} strokeWidth="2.2" strokeLinecap="round" />
        <circle cx="12" cy="14" r="2.2" fill="#FFFFFF" fillOpacity="0.45" />
      </svg>
    );
  }
  if (type === 'sparkling') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M6 5H18L16.5 19.5C16.4 20.6 15.5 21.5 14.3 21.5H9.7C8.5 21.5 7.6 20.6 7.5 19.5L6 5Z" fill={color} />
        <circle cx="10.5" cy="12" r="1.3" fill="#FFFFFF" />
        <circle cx="13.8" cy="15.5" r="1.6" fill="#FFFFFF" />
        <circle cx="12.5" cy="9.5" r="1" fill="#FFFFFF" />
      </svg>
    );
  }
  // Default water / tumbler / cup
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M6 5H18L16.6 19.3C16.5 20.5 15.5 21.5 14.2 21.5H9.8C8.5 21.5 7.5 20.5 7.4 19.3L6 5Z" fill={color} />
      <path d="M8.5 9L9 17" stroke="#FFFFFF" strokeOpacity="0.45" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
};

export const TokenCoinIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 24,
  className = '',
}) => {
  const uid = useId().replace(/:/g, '');
  const rimId = `tok-rim-${uid}`;
  const faceId = `tok-face-${uid}`;

  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={rimId} x1="4" y1="3" x2="28" y2="29" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFE17D" />
          <stop offset="52%" stopColor="#FFB02E" />
          <stop offset="100%" stopColor="#E07A0B" />
        </linearGradient>
        <linearGradient id={faceId} x1="8" y1="7" x2="24" y2="25" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFF7DC" />
          <stop offset="100%" stopColor="#FFE08A" />
        </linearGradient>
      </defs>
      {/* Minted 3D lower coin edge */}
      <circle cx="16" cy="17.4" r="13.2" fill="#B85D05" />
      {/* Outer beveled rim */}
      <circle cx="16" cy="15.2" r="13.2" fill={`url(#${rimId})`} />
      {/* Recessed matte coin face */}
      <circle cx="16" cy="15.2" r="9.8" fill={`url(#${faceId})`} stroke="#E88914" strokeWidth="1.2" />
      {/* Embossed two-tone water droplet core */}
      <path
        d="M16 8.8C16 8.8 11.4 13.7 11.4 17C11.4 19.6 13.5 21.6 16 21.6C18.5 21.6 20.6 19.6 20.6 17C20.6 13.7 16 8.8 16 8.8Z"
        fill="#2563EB"
      />
      <path
        d="M16 8.8C16 8.8 20.6 13.7 20.6 17C20.6 19.6 18.5 21.6 16 21.6V8.8Z"
        fill="#38BDF8"
      />
      <path
        d="M14.1 14.8C13.5 15.6 13.4 16.8 13.8 17.8"
        stroke="#FFFFFF"
        strokeOpacity="0.82"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
};

export const MysteryBoxIcon: React.FC<{ size?: number; open?: boolean; className?: string }> = ({
  size = 44,
  open = false,
  className = '',
}) => {
  const uid = useId().replace(/:/g, '');
  const boxId = `mbox-${uid}`;
  const lidId = `mlid-${uid}`;

  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={boxId} x1="8" y1="18" x2="40" y2="44" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#5D92FF" />
          <stop offset="100%" stopColor="#2C56D6" />
        </linearGradient>
        <linearGradient id={lidId} x1="6" y1="8" x2="42" y2="22" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#7AB8FF" />
          <stop offset="100%" stopColor="#3D6EF5" />
        </linearGradient>
      </defs>

      <ellipse cx="24" cy="43.5" rx="15" ry="2.5" fill="#0B1633" fillOpacity="0.1" />

      {/* Base */}
      <rect x="8" y="20" width="32" height="22" rx="6" fill={`url(#${boxId})`} />
      <rect x="21" y="20" width="6" height="22" fill="#FFB347" />
      <rect x="8" y="20" width="32" height="3.5" fill="#1F41AD" fillOpacity="0.3" />

      {/* Lid */}
      <g
        style={{
          transform: open ? 'translate(-2px, -6px) rotate(-14deg)' : 'none',
          transformOrigin: '10px 18px',
          transition: 'transform 380ms cubic-bezier(0.22, 1, 0.36, 1)',
        }}
      >
        <rect x="6" y="13" width="36" height="9" rx="4" fill={`url(#${lidId})`} />
        <rect x="21" y="13" width="6" height="9" fill="#FFCA6B" />
        {/* Ribbon bow */}
        <path
          d="M24 13C20.5 13 16 11.2 16 8.4C16 6.6 18.2 6 20.5 7.4C22.2 8.4 23.3 10.6 24 13Z"
          fill="#FFB347"
        />
        <path
          d="M24 13C27.5 13 32 11.2 32 8.4C32 6.6 29.8 6 27.5 7.4C25.8 8.4 24.7 10.6 24 13Z"
          fill="#FF9233"
        />
      </g>

      {/* Center water droplet badge */}
      <circle cx="24" cy="31" r="6" fill="#FFFFFF" />
      <path
        d="M24 27.2C24 27.2 21.2 30.2 21.2 32.1C21.2 33.7 22.5 35 24 35C25.5 35 26.8 33.7 26.8 32.1C26.8 30.2 24 27.2 24 27.2Z"
        fill="#19B4F2"
      />
    </svg>
  );
};

