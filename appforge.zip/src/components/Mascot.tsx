import React, { useEffect, useId, useRef, useState } from 'react';
import { motion } from 'motion/react';
import type { NotificationTone, SippyMood } from '../types';

interface MascotProps {
  mood: SippyMood;
  persona?: NotificationTone;
  size?: number;
  className?: string;
  interactive?: boolean;
  autoCycleFaces?: boolean;
  cycleTrigger?: number;
  onTap?: (nextMood?: SippyMood) => void;
  hideShadow?: boolean;
}

const FACE_CYCLE: SippyMood[] = ['happy', 'proud', 'cheeky', 'waving', 'hyped', 'thinking'];

export const Mascot: React.FC<MascotProps> = ({
  mood,
  persona,
  size = 104,
  className = '',
  interactive = false,
  autoCycleFaces = false,
  cycleTrigger = 0,
  onTap,
  hideShadow = false,
}) => {
  const uid = useId().replace(/:/g, '');
  const [blinking, setBlinking] = useState(false);
  const [glance, setGlance] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [faceIndex, setFaceIndex] = useState<number>(() => {
    const found = FACE_CYCLE.indexOf(mood);
    return found >= 0 ? found : 0;
  });
  const [swapCount, setSwapCount] = useState(0);
  const [userPinnedUntil, setUserPinnedUntil] = useState(0);
  const prevTriggerRef = useRef(cycleTrigger);

  const isUrgentState = mood === 'sleepy' || mood === 'thirsty' || mood === 'worried';

  useEffect(() => {
    const idx = FACE_CYCLE.indexOf(mood);
    if (idx >= 0) {
      setFaceIndex(idx);
    }
  }, [mood]);

  useEffect(() => {
    if (cycleTrigger !== prevTriggerRef.current) {
      prevTriggerRef.current = cycleTrigger;
      setFaceIndex((prev) => (prev + 1) % FACE_CYCLE.length);
      setSwapCount((c) => c + 1);
      setBlinking(true);
      const t = window.setTimeout(() => setBlinking(false), 110);
      return () => window.clearTimeout(t);
    }
  }, [cycleTrigger]);

  useEffect(() => {
    if (!autoCycleFaces || isUrgentState) return;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return;

    const interval = window.setInterval(() => {
      if (Date.now() < userPinnedUntil) return;
      setBlinking(true);
      window.setTimeout(() => {
        setFaceIndex((prev) => (prev + 1) % FACE_CYCLE.length);
        setSwapCount((c) => c + 1);
        setBlinking(false);
      }, 95);
    }, 3400);

    return () => window.clearInterval(interval);
  }, [autoCycleFaces, isUrgentState, userPinnedUntil]);

  const activeMood: SippyMood = isUrgentState
    ? mood
    : autoCycleFaces || swapCount > 0
      ? FACE_CYCLE[faceIndex % FACE_CYCLE.length]
      : mood;

  useEffect(() => {
    if (activeMood === 'sleepy' || activeMood === 'hyped') return;
    let blinkTimeout: number;
    let blinkEndTimeout: number;
    let glanceTimeout: number;

    const scheduleBlink = () => {
      const delay = 3100 + Math.random() * 2300;
      blinkTimeout = window.setTimeout(() => {
        setBlinking(true);
        blinkEndTimeout = window.setTimeout(() => {
          setBlinking(false);
          scheduleBlink();
        }, 115);
      }, delay);
    };

    const scheduleGlance = () => {
      const delay = 2200 + Math.random() * 2200;
      glanceTimeout = window.setTimeout(() => {
        const offsets = [
          { x: -1.4, y: 0 },
          { x: 0, y: 0 },
          { x: 1.4, y: -0.3 },
          { x: 0, y: 0.3 },
        ];
        setGlance(offsets[Math.floor(Math.random() * offsets.length)]);
        scheduleGlance();
      }, delay);
    };

    scheduleBlink();
    scheduleGlance();
    return () => {
      window.clearTimeout(blinkTimeout);
      window.clearTimeout(blinkEndTimeout);
      window.clearTimeout(glanceTimeout);
    };
  }, [activeMood]);

  const clipBodyId = `sippy-body-clip-${uid}`;
  const isThirsty = activeMood === 'thirsty';

  // Crisp 2D studio palette matching Sippy's Hydro Blue theme + persona tuning
  const bodyColor = isThirsty
    ? '#4E7AD9'
    : persona === 'coach'
      ? '#255CE0'
      : persona === 'gentle'
        ? '#397DF7'
        : '#2E6DF6';
  const bodyDarkEdge = isThirsty
    ? '#385EB8'
    : persona === 'coach'
      ? '#1A43B5'
      : '#1E4EC9';
  const maskColor = isThirsty
    ? '#89C4F8'
    : persona === 'gentle'
      ? '#7ED9FF'
      : '#65CCFF';
  const chestWaveColor = isThirsty ? '#7BB8F2' : '#58BEFA';
  const armColor = isThirsty ? '#3E67C8' : persona === 'coach' ? '#1F4CC2' : '#245AE0';
  const footColor = persona === 'gentle' ? '#FFA04D' : '#FF8A2B';
  const footSole = '#D96514';

  const handlePress = () => {
    if (!interactive && !onTap) return;
    const nextIdx = (faceIndex + 1) % FACE_CYCLE.length;
    const nextMood = FACE_CYCLE[nextIdx];
    setBlinking(true);
    window.setTimeout(() => {
      setFaceIndex(nextIdx);
      setSwapCount((c) => c + 1);
      setUserPinnedUntil(Date.now() + 2600);
      setBlinking(false);
    }, 85);
    onTap?.(nextMood);
  };

  // Sturdy, broad-shouldered water-spirit silhouette with twin dynamic splash crest tufts
  const bodyPath =
    'M37 22C41 12 49 15 54 22C57.5 18.5 62.5 18.5 66 22C71 15 79 12 83 22C86.5 31 94 45 94 64C94 86.5 79.5 101 60 101C40.5 101 26 86.5 26 64C26 45 33.5 31 37 22Z';

  // Signature twin-lobe lighter aqua face mask framing the eyes (inspired by classic flat mascot construction)
  const faceMaskPath =
    'M43 34C34 34 29 41.5 29 50.5C29 60 36 66 46 66C51.5 66 56.5 63.5 60 59.5C63.5 63.5 68.5 66 74 66C84 66 91 60 91 50.5C91 41.5 86 34 77 34C70 34 64 38 60 42.5C56 38 50 34 43 34Z';

  const renderEye = (side: 'left' | 'right') => {
    const cx = side === 'left' ? 45.5 : 74.5;
    const cy = 49.5;

    if (activeMood === 'hyped') {
      return (
        <path
          key={side}
          d={`M${cx - 8} ${cy + 2}C${cx - 5} ${cy - 6.5} ${cx + 5} ${cy - 6.5} ${cx + 8} ${cy + 2}`}
          stroke="#0B1633"
          strokeWidth="4.4"
          strokeLinecap="round"
        />
      );
    }

    if (activeMood === 'sleepy' || blinking) {
      return (
        <path
          key={side}
          d={`M${cx - 8} ${cy}C${cx - 4.5} ${cy + 4.5} ${cx + 4.5} ${cy + 4.5} ${cx + 8} ${cy}`}
          stroke="#0B1633"
          strokeWidth="4"
          strokeLinecap="round"
        />
      );
    }

    const px =
      activeMood === 'thinking'
        ? cx + 2.2
        : glance.x + (side === 'left' ? cx + 1.1 : cx - 1.1);
    const py =
      activeMood === 'thinking'
        ? cy - 2
        : activeMood === 'proud'
          ? cy + 1.2
          : cy + 0.5 + glance.y;

    return (
      <g key={side}>
        {/* Bold crisp white eye oval */}
        <ellipse cx={cx} cy={cy} rx="10.2" ry="11.4" fill="#FFFFFF" />

        {/* Pupil */}
        <g style={{ transition: 'transform 240ms cubic-bezier(0.22, 1, 0.36, 1)' }}>
          <ellipse cx={px} cy={py} rx="5.8" ry="6.6" fill="#0B1633" />
          {/* Crisp studio catchlight */}
          <circle cx={px + 2} cy={py - 2.4} r="2.2" fill="#FFFFFF" />
        </g>

        {/* Confident flat half-lid for proud/flexing look (inspired by reference image 1) */}
        {activeMood === 'proud' && (
          <>
            <path
              d={`M${cx - 11} ${cy - 3.2}H${cx + 11}V${cy - 12.5}H${cx - 11}Z`}
              fill={maskColor}
            />
            <path
              d={`M${cx - 10.5} ${cy - 3.2}L${cx + 10.5} ${side === 'left' ? cy - 2.2 : cy - 4.2}`}
              stroke="#0B1633"
              strokeWidth="2.8"
              strokeLinecap="round"
            />
          </>
        )}

        {/* Cheeky wink/squint on right eye */}
        {activeMood === 'cheeky' && side === 'right' && (
          <>
            <path
              d={`M${cx - 11} ${cy - 1.5}H${cx + 11}V${cy - 12.5}H${cx - 11}Z`}
              fill={maskColor}
            />
            <path
              d={`M${cx - 10} ${cy - 1}C${cx - 4} ${cy - 3} ${cx + 4} ${cy - 3} ${cx + 10} ${cy - 1}`}
              stroke="#0B1633"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
          </>
        )}

        {/* Heavy tired lids when thirsty */}
        {isThirsty && (
          <>
            <path
              d={`M${cx - 11} ${cy - 2.4}H${cx + 11}V${cy - 12.5}H${cx - 11}Z`}
              fill={maskColor}
            />
            <path
              d={`M${cx - 10.2} ${cy - 2.4}H${cx + 10.2}`}
              stroke="#0B1633"
              strokeWidth="2.6"
              strokeLinecap="round"
            />
          </>
        )}

        {/* Worried tilted top lid */}
        {activeMood === 'worried' && (
          <>
            <path
              d={
                side === 'left'
                  ? `M${cx - 11} ${cy - 2}L${cx + 11} ${cy - 7.5}V${cy - 13}H${cx - 11}Z`
                  : `M${cx - 11} ${cy - 7.5}L${cx + 11} ${cy - 2}V${cy - 13}H${cx - 11}Z`
              }
              fill={maskColor}
            />
            <path
              d={
                side === 'left'
                  ? `M${cx - 10} ${cy - 2}L${cx + 9.5} ${cy - 7}`
                  : `M${cx - 9.5} ${cy - 7}L${cx + 10} ${cy - 2}`
              }
              stroke="#0B1633"
              strokeWidth="2.8"
              strokeLinecap="round"
            />
          </>
        )}

        {/* Thinking brow */}
        {activeMood === 'thinking' && (
          <path
            d={
              side === 'left'
                ? `M${cx - 8} ${cy - 13.5}H${cx + 7}`
                : `M${cx - 7} ${cy - 15.5}C${cx - 2} ${cy - 18.5} ${cx + 4} ${cy - 18.5} ${cx + 8} ${cy - 15}`
            }
            stroke="#0B1633"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
        )}
      </g>
    );
  };

  const renderMouth = () => {
    if (activeMood === 'hyped') {
      return (
        <g>
          <path d="M51 60.5H69C69 72 51 72 51 60.5Z" fill="#0B1633" />
          <path d="M54 60.5H66V62.5C66 63.2 54 63.2 54 62.5Z" fill="#FFFFFF" />
          <path d="M54.8 68C57.2 64.8 62.8 64.8 65.2 68C62.8 70.6 57.2 70.6 54.8 68Z" fill="#FF6B6B" />
        </g>
      );
    }
    if (activeMood === 'proud') {
      return (
        <path
          d="M52.5 62.5C57.5 66.5 64 65.5 68 60.5"
          stroke="#0B1633"
          strokeWidth="3.6"
          strokeLinecap="round"
        />
      );
    }
    if (activeMood === 'cheeky') {
      return (
        <g>
          <path
            d="M52 62C56.5 66.8 63.5 66.8 68 62"
            stroke="#0B1633"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          <path d="M57 65C57 69.8 63 69.8 63 65Z" fill="#FF7B6B" stroke="#0B1633" strokeWidth="1.2" />
        </g>
      );
    }
    if (activeMood === 'thirsty') {
      return (
        <g>
          <path d="M54.5 62H65.5C65.5 68.5 54.5 68.5 54.5 62Z" fill="#0B1633" />
          <path d="M57 65.8C58.6 63.8 61.4 63.8 63 65.8C61.6 68.5 58.4 68.5 57 65.8Z" fill="#FF7B6B" />
        </g>
      );
    }
    if (activeMood === 'thinking') {
      return (
        <path
          d="M54.5 63.5C57.8 62.5 62.2 63.8 65.5 62"
          stroke="#0B1633"
          strokeWidth="3.2"
          strokeLinecap="round"
        />
      );
    }
    if (activeMood === 'worried') {
      return (
        <path
          d="M53.5 66.5C57 62 63 62 66.5 66.5"
          stroke="#0B1633"
          strokeWidth="3.3"
          strokeLinecap="round"
        />
      );
    }
    if (activeMood === 'sleepy') {
      return <ellipse cx="60" cy="64.5" rx="3.2" ry="2.6" fill="#0B1633" />;
    }
    if (persona === 'gentle' && (activeMood === 'happy' || activeMood === 'waving')) {
      return (
        <path
          d="M53.5 62.5C57.5 66.2 62.5 66.2 66.5 62.5"
          stroke="#0B1633"
          strokeWidth="3.3"
          strokeLinecap="round"
        />
      );
    }
    // happy & waving
    return (
      <g>
        <path d="M52 61H68C68 69.5 52 69.5 52 61Z" fill="#0B1633" />
        <path d="M55.5 66.2C57.8 63.8 62.2 63.8 64.5 66.2C62.2 68.5 57.8 68.5 55.5 66.2Z" fill="#FF7B6B" />
      </g>
    );
  };

  const renderArms = () => {
    if (activeMood === 'proud') {
      // Confident flexed hydro-bicep pose inspired by reference image 1
      return (
        <>
          <g>
            <path
              d="M28 60C18 61 11 54 12.5 46.5C13.6 41 19 39.5 22 44.5C22.8 48.5 26 51.5 31 52Z"
              fill={bodyColor}
              stroke={bodyDarkEdge}
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
            <ellipse cx="18.5" cy="52" rx="3" ry="1.8" transform="rotate(-24 18.5 52)" fill="#FFFFFF" fillOpacity="0.45" />
          </g>
          <g>
            <path
              d="M92 60C102 61 109 54 107.5 46.5C106.4 41 101 39.5 98 44.5C97.2 48.5 94 51.5 89 52Z"
              fill={bodyColor}
              stroke={bodyDarkEdge}
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
            <ellipse cx="101.5" cy="52" rx="3" ry="1.8" transform="rotate(24 101.5 52)" fill="#FFFFFF" fillOpacity="0.45" />
          </g>
        </>
      );
    }

    if (activeMood === 'hyped') {
      // Energetic cheering arms up
      return (
        <>
          <path
            d="M30 60C20 55 12 45 15.5 39C19 33.5 28 41 33 50Z"
            fill={armColor}
          />
          <path
            d="M90 60C100 55 108 45 104.5 39C101 33.5 92 41 87 50Z"
            fill={armColor}
          />
        </>
      );
    }

    if (activeMood === 'waving') {
      return (
        <>
          <path d="M29 58C20 63 14.5 72 19 76.5C23.2 80.5 30 73 33 65Z" fill={armColor} />
          <g className="anim-wave-arm">
            <path d="M89 58C98.5 52.5 106.5 42.5 103 37C99.5 31.5 91 39.5 86.5 49Z" fill={armColor} />
          </g>
        </>
      );
    }

    if (activeMood === 'thinking') {
      return (
        <>
          <path d="M29 58C20 63 14.5 72 19 76.5C23.2 80.5 30 73 33 65Z" fill={armColor} />
          <path d="M88 63C96 63 97 72 87 74.5C78 76.5 71 71.5 73 66.5C75 62.5 82 63 88 63Z" fill={armColor} />
        </>
      );
    }

    // Classic sturdy side flippers
    return (
      <>
        <path d="M29 58C20 63 14.5 72.5 19 77C23.5 81 30.5 73 33.5 65Z" fill={armColor} />
        <path d="M91 58C100 63 105.5 72.5 101 77C96.5 81 89.5 73 86.5 65Z" fill={armColor} />
      </>
    );
  };

  const bodyContent = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      className={`select-none overflow-visible ${className}`}
      aria-label={`Sippy${persona ? ` (${persona})` : ''} mascot looking ${activeMood}`}
      role="img"
    >
      <defs>
        <clipPath id={clipBodyId}>
          <path d={bodyPath} />
        </clipPath>
      </defs>

      {/* Stationary ground shadow */}
      {!hideShadow && (
        <ellipse
          cx="60"
          cy="112.5"
          rx="26"
          ry="4.5"
          fill="#0B1633"
          fillOpacity="0.11"
          className="anim-shadow-pulse"
        />
      )}

      {/* Grounded breathing rig */}
      <g className="anim-breathe">
        <motion.g
          key={swapCount}
          initial={swapCount > 0 ? { rotate: -3.5, scaleX: 1.04, scaleY: 0.94 } : false}
          animate={{ rotate: 0, scaleX: 1, scaleY: 1 }}
          transition={{ type: 'spring', stiffness: 430, damping: 18 }}
          style={{ transformOrigin: '60px 96px' }}
        >
          {/* Sturdy tangerine capsule feet (grounded mascot stance) */}
          <g>
            <rect x="38" y="99" width="17" height="10.5" rx="5.25" fill={footSole} />
            <rect x="38" y="97.5" width="17" height="9" rx="4.5" fill={footColor} />
            <rect x="65" y="99" width="17" height="10.5" rx="5.25" fill={footSole} />
            <rect x="65" y="97.5" width="17" height="9" rx="4.5" fill={footColor} />
          </g>

          {/* Expressive side flippers / flexed arms */}
          {renderArms()}

          {/* Main crisp vector water-spirit silhouette */}
          <path d={bodyPath} fill={bodyColor} />

          {/* Clean cel-shaded bottom crescent + crisp upper crest shine */}
          <g clipPath={`url(#${clipBodyId})`}>
            <path
              d="M24 81C32 95 45 101 60 101C75 101 88 95 96 81C88 90 75 94.5 60 94.5C45 94.5 32 90 24 81Z"
              fill={bodyDarkEdge}
            />
            <ellipse
              cx="39.5"
              cy="25.5"
              rx="3.2"
              ry="5.8"
              transform="rotate(-20 39.5 25.5)"
              fill="#FFFFFF"
              fillOpacity="0.45"
            />
          </g>

          {/* Signature lighter aqua face mask */}
          <path d={faceMaskPath} fill={maskColor} />

          {/* Gentle persona rosy cheek blushes */}
          {persona === 'gentle' && (
            <g fill="#FF94B2" fillOpacity="0.55">
              <ellipse cx="34.5" cy="57.5" rx="4.2" ry="2.3" />
              <ellipse cx="85.5" cy="57.5" rx="4.2" ry="2.3" />
            </g>
          )}

          {/* Three crisp chest wave scallops (hidden behind coach whistle when Coach persona is active) */}
          {persona !== 'coach' && (
            <>
              <path d="M46 76.5C46 80.5 52 80.5 52 76.5Z" fill={chestWaveColor} />
              <path d="M68 76.5C68 80.5 74 80.5 74 76.5Z" fill={chestWaveColor} />
              <path d="M56.5 82.5C56.5 87 63.5 87 63.5 82.5Z" fill={chestWaveColor} />
            </>
          )}

          {/* Eyes & Mouth */}
          {renderEye('left')}
          {renderEye('right')}
          {renderMouth()}

          {/* Coach Persona: Crisp Athletic Headband + Silver Whistle on Lanyard */}
          {persona === 'coach' && (
            <g>
              {/* Sweatband across brow */}
              <path
                d="M31.5 34.5Q60 28 88.5 34.5L90.5 40Q60 33.8 29.5 40Z"
                fill="#FFFFFF"
                stroke="#0B1633"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
              <path
                d="M30.5 36.8Q60 30.8 89.5 36.8"
                stroke="#FF6B2C"
                strokeWidth="2.4"
                strokeLinecap="round"
              />
              {/* Whistle lanyard & metallic whistle */}
              <path
                d="M44 68.5Q60 80 76 68.5"
                fill="none"
                stroke="#0B1633"
                strokeWidth="2.2"
                strokeLinecap="round"
              />
              <circle cx="60" cy="76" r="2.2" fill="#E4E9F2" stroke="#0B1633" strokeWidth="1.2" />
              <path
                d="M55 78.5H68.5C70 78.5 71 79.6 71 81V82.5C71 84.5 68.5 85 66 84.5L63.5 84C62.2 87 58.2 88.5 55 87.2C51.8 85.8 51.5 80.5 55 78.5Z"
                fill="#F8FAFC"
                stroke="#0B1633"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              <circle cx="57.8" cy="83" r="1.8" fill="#FF6B2C" />
            </g>
          )}

          {/* Gentle Persona: Calming Botanical Mint Leaf Sprout */}
          {persona === 'gentle' && (
            <g>
              <path
                d="M60 20.5C60 14 61 9 62 6.5"
                stroke="#178A62"
                strokeWidth="2.6"
                strokeLinecap="round"
              />
              <path
                d="M60.5 13C53 12 48.5 6.5 51.5 3.2C54.8 0 60 5.5 60.5 13Z"
                fill="#22B07D"
                stroke="#178A62"
                strokeWidth="1.3"
                strokeLinejoin="round"
              />
              <path
                d="M61.2 11C67.5 9.5 72.5 4.2 69.5 1.5C66.4 -1.2 61.5 4.2 61.2 11Z"
                fill="#6EE7B7"
                stroke="#178A62"
                strokeWidth="1.3"
                strokeLinejoin="round"
              />
            </g>
          )}

          {/* Playful Persona: Jaunty Tilted Backwards Snapback Cap */}
          {persona === 'playful' && (
            <g transform="rotate(-10 60 22)">
              {/* Backwards cap brim pointing left */}
              <path
                d="M42 25.5C32 25.5 23 27.5 22 30.8C21.5 32.5 26 33.5 33 32.2L44 29.8Z"
                fill="#FF6B2C"
                stroke="#0B1633"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              {/* Cap crown */}
              <path
                d="M41 28C41 16 51 11 61 11C71 11 79 16 79 28Z"
                fill="#FFB347"
                stroke="#0B1633"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
              {/* White front accent panel */}
              <path
                d="M52 27.5C52 17.5 56 12 61 12C66 12 70 17.5 70 27.5Z"
                fill="#FFF8EE"
              />
              {/* Cap button & strap */}
              <circle cx="60.5" cy="10.2" r="2.3" fill="#FF6B2C" stroke="#0B1633" strokeWidth="1.3" />
              <path d="M40 27.5H80" stroke="#0B1633" strokeWidth="2.2" strokeLinecap="round" />
            </g>
          )}

          {/* Sleepy z accents */}
          {activeMood === 'sleepy' && (
            <g fill="#0B1633" fillOpacity="0.52" fontSize="11.5" fontWeight="800">
              <text x="90" y="29">z</text>
              <text x="99" y="19" fontSize="9">z</text>
            </g>
          )}

          {/* Crisp golden 4-point cheer stars when hyped, flexing proud, or playful */}
          {(activeMood === 'hyped' || activeMood === 'proud' || persona === 'playful') && (
            <g fill="#FFB347">
              <path d="M16 21L17.8 25.6L22.4 27.4L17.8 29.2L16 33.8L14.2 29.2L9.6 27.4L14.2 25.6Z" />
              <path d="M101 16L102.4 19.6L106 21L102.4 22.4L101 26L99.6 22.4L96 21L99.6 19.6Z" />
            </g>
          )}
        </motion.g>
      </g>
    </svg>
  );

  if (interactive || onTap) {
    return (
      <motion.button
        type="button"
        onClick={handlePress}
        aria-label={`Tap Sippy (${activeMood})`}
        animate={
          swapCount > 0
            ? {
                y: [0, -7, 0],
                scaleX: [1, 0.94, 1.05, 1],
                scaleY: [1, 1.05, 0.95, 1],
              }
            : undefined
        }
        whileTap={{ scaleX: 1.07, scaleY: 0.92 }}
        transition={{ duration: 0.42, times: [0, 0.32, 0.68, 1], ease: [0.22, 1, 0.36, 1] }}
        style={{ transformOrigin: 'bottom center' }}
        className="inline-flex items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-[var(--brand-500)] cursor-pointer"
      >
        {bodyContent}
      </motion.button>
    );
  }

  return (
    <motion.div
      key={activeMood}
      initial={{ opacity: 0.92, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
      style={{ transformOrigin: 'bottom center' }}
      className="inline-flex items-center justify-center"
    >
      {bodyContent}
    </motion.div>
  );
};
