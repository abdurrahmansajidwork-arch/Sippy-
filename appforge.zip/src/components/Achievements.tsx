import React, { useId, useState } from 'react';
import { Lock, Minus, Plus, Sparkles, Trash2, X } from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import type {
  AchievementIconKey,
  AchievementPaletteKey,
  CustomBadge,
  CustomBadgeRuleType,
} from '../types';
import { ACHIEVEMENT_PALETTES } from '../utils/achievements';
import { DeleteConfirmDialog } from './Sheets';

const ICON_OPTIONS: { key: AchievementIconKey; label: string }[] = [
  { key: 'droplet', label: 'Droplet' },
  { key: 'flame', label: 'Flame' },
  { key: 'star', label: 'Star' },
  { key: 'trophy', label: 'Trophy' },
  { key: 'sun', label: 'Sun' },
  { key: 'sparkles', label: 'Sparkles' },
  { key: 'shield', label: 'Shield' },
];

const PALETTE_KEYS: AchievementPaletteKey[] = ['brand', 'water', 'mint', 'flame', 'lav'];

const MedallionGlyph: React.FC<{
  icon: AchievementIconKey;
  color: string;
  size?: number;
}> = ({ icon, color, size = 26 }) => {
  if (icon === 'flame') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M12.6 2.8C12.6 2.8 18.5 8 18.5 13.8C18.5 17.8 15.6 21 12 21C8.4 21 5.5 17.8 5.5 13.8C5.5 10.6 7.7 7.6 9 6.4C9.2 8.2 10.3 9.1 11 9.4C10.8 6.7 12.6 2.8 12.6 2.8Z"
          fill={color}
        />
      </svg>
    );
  }
  if (icon === 'star') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M12 2.8L14.7 8.4L20.8 9.2L16.3 13.4L17.5 19.5L12 16.5L6.5 19.5L7.7 13.4L3.2 9.2L9.3 8.4L12 2.8Z"
          fill={color}
        />
      </svg>
    );
  }
  if (icon === 'trophy') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M7 4H17V9.5C17 12.3 14.8 14.5 12 14.5C9.2 14.5 7 12.3 7 9.5V4Z"
          fill={color}
        />
        <path d="M7 5.5H4.5C4.5 8.5 5.4 10 7 10.5M17 5.5H19.5C19.5 8.5 18.6 10 17 10.5" stroke={color} strokeWidth="2" strokeLinecap="round" />
        <rect x="10.5" y="14.5" width="3" height="3.2" fill={color} />
        <rect x="7.5" y="17.5" width="9" height="2.6" rx="1.3" fill={color} />
      </svg>
    );
  }
  if (icon === 'sun') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="12" cy="12" r="5" fill={color} />
        <path
          d="M12 3V5.2M12 18.8V21M3 12H5.2M18.8 12H21M5.6 5.6L7.2 7.2M16.8 16.8L18.4 18.4M18.4 5.6L16.8 7.2M7.2 16.8L5.6 18.4"
          stroke={color}
          strokeWidth="2.1"
          strokeLinecap="round"
        />
      </svg>
    );
  }
  if (icon === 'sparkles') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 3L14 8.5L19.5 10.5L14 12.5L12 18L10 12.5L4.5 10.5L10 8.5L12 3Z" fill={color} />
        <path d="M18.5 15L19.3 17.2L21.5 18L19.3 18.8L18.5 21L17.7 18.8L15.5 18L17.7 17.2L18.5 15Z" fill={color} />
      </svg>
    );
  }
  if (icon === 'shield') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M12 3L19 6.2V11.5C19 16 16 19.6 12 21C8 19.6 5 16 5 11.5V6.2L12 3Z"
          fill={color}
        />
      </svg>
    );
  }
  // Default droplet
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M12 3C12 3 6.2 10.2 6.2 14.7C6.2 18 8.8 20.5 12 20.5C15.2 20.5 17.8 18 17.8 14.7C17.8 10.2 12 3 12 3Z"
        fill={color}
      />
    </svg>
  );
};

const BADGE_SHAPES: Record<AchievementIconKey, { outer: string; inner: string; bevelOffsetY?: number }> = {
  // Rounded arch shield
  droplet: {
    outer: 'M32 4L54 11.5V31C54 45.2 44.2 55.2 32 59.5C19.8 55.2 10 45.2 10 31V11.5L32 4Z',
    inner: 'M32 9.5L49 15.2V31C49 42.2 41.4 50.2 32 53.8C22.6 50.2 15 42.2 15 31V15.2L32 9.5Z',
  },
  // Bold rounded hexagon
  flame: {
    outer: 'M32 4.5L55 17.8V44.2L32 57.5L9 44.2V17.8L32 4.5Z',
    inner: 'M32 10L50 20.5V41.5L32 52L14 41.5V20.5L32 10Z',
  },
  // Heraldic crest shield
  shield: {
    outer: 'M12 10C12 7.5 14 6 16.5 6H47.5C50 6 52 7.5 52 10V32.5C52 46.5 41.5 55.5 32 59.5C22.5 55.5 12 46.5 12 32.5V10Z',
    inner: 'M17 11H47V32.5C47 43.2 39 50.4 32 53.8C25 50.4 17 43.2 17 32.5V11Z',
  },
  // 8-point scalloped rosette seal
  star: {
    outer: 'M32 4L39 10L48 9L50 18L58 23L55 32L58 41L50 46L48 55L39 54L32 60L25 54L16 55L14 46L6 41L9 32L6 23L14 18L16 9L25 10L32 4Z',
    inner: 'M32 10.5L37.5 14.8L44.5 14.2L46.2 21L52.2 24.8L49.8 32L52.2 39.2L46.2 43L44.5 49.8L37.5 49.2L32 53.5L26.5 49.2L19.5 49.8L17.8 43L11.8 39.2L14.2 32L11.8 24.8L17.8 21L19.5 14.2L26.5 14.8L32 10.5Z',
  },
  // Tapered victory pennant banner
  trophy: {
    outer: 'M13 8C13 6.2 14.4 5 16.2 5H47.8C49.6 5 51 6.2 51 8V45.5C51 47.2 50 48.8 48.4 49.6L34 57.5C32.8 58.2 31.2 58.2 30 57.5L15.6 49.6C14 48.8 13 47.2 13 45.5V8Z',
    inner: 'M18 10H46V43.8L32 51.5L18 43.8V10Z',
  },
  // Rounded gem diamond plaque
  sun: {
    outer: 'M32 4.5C33.8 4.5 35.6 5.2 36.9 6.5L57.5 27.1C60.2 29.8 60.2 34.2 57.5 36.9L36.9 57.5C34.2 60.2 29.8 60.2 27.1 57.5L6.5 36.9C3.8 34.2 3.8 29.8 6.5 27.1L27.1 6.5C28.4 5.2 30.2 4.5 32 4.5Z',
    inner: 'M32 11L53 32L32 53L11 32L32 11Z',
  },
  // Cut-corner octagon gem
  sparkles: {
    outer: 'M21 5H43L59 21V43L43 59H21L5 43V21L21 5Z',
    inner: 'M23 10.5H41L53.5 23V41L41 53.5H23L10.5 41V23L23 10.5Z',
  },
};

export const BadgeMedallion: React.FC<{
  icon: AchievementIconKey;
  palette: AchievementPaletteKey;
  unlocked: boolean;
  size?: number;
}> = ({ icon, palette, unlocked, size = 64 }) => {
  const uid = useId().replace(/:/g, '');
  const pal = ACHIEVEMENT_PALETTES[palette] || ACHIEVEMENT_PALETTES.brand;
  const gradId = `med-${uid}`;
  const shape = BADGE_SHAPES[icon] || BADGE_SHAPES.droplet;

  return (
    <div
      className="relative inline-flex items-center justify-center shrink-0"
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 66"
        fill="none"
        aria-hidden="true"
        className="select-none overflow-visible"
      >
        <defs>
          <linearGradient id={gradId} x1="32" y1="4" x2="32" y2="60" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor={unlocked ? pal.from : '#E4E9F2'} />
            <stop offset="100%" stopColor={unlocked ? pal.to : '#CFD7E6'} />
          </linearGradient>
        </defs>

        {/* Tactile 3D bottom bevel shadow */}
        <g transform="translate(0, 3)">
          <path d={shape.outer} fill={unlocked ? pal.edge : '#B9C3D6'} />
        </g>

        {/* Sculpted badge silhouette */}
        <path
          d={shape.outer}
          fill={`url(#${gradId})`}
          stroke={unlocked ? pal.edge : '#C3CCDD'}
          strokeWidth="1.5"
          strokeLinejoin="round"
        />

        {/* Recessed inner bevel border */}
        <path
          d={shape.inner}
          fill="none"
          stroke="#FFFFFF"
          strokeOpacity={unlocked ? 0.34 : 0.5}
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      </svg>

      {/* Center icon */}
      <div className="absolute inset-0 flex items-center justify-center pb-0.5">
        {unlocked ? (
          <MedallionGlyph icon={icon} color="#FFFFFF" size={Math.round(size * 0.4)} />
        ) : (
          <Lock size={Math.round(size * 0.32)} className="text-[#8A93A6]" strokeWidth={2.2} />
        )}
      </div>

      {/* Sparkle accent on earned badges */}
      {unlocked && (
        <span
          aria-hidden="true"
          className="absolute -top-0.5 -right-0.5 w-5 h-5 rounded-full bg-[#FFFFFF] border-2 border-[var(--line)] flex items-center justify-center shadow-xs"
        >
          <Sparkles size={10} className="text-[#FFB347]" fill="#FFB347" />
        </span>
      )}
    </div>
  );
};

export const Achievements: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const {
    achievementBadges,
    customBadgeStatuses,
    currentStreak,
    bestStreak,
    addCustomBadge,
    deleteCustomBadge,
  } = useSippy();

  const [creatorOpen, setCreatorOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [ruleType, setRuleType] = useState<CustomBadgeRuleType>('streak_days');
  const [targetValue, setTargetValue] = useState(5);
  const [icon, setIcon] = useState<AchievementIconKey>('star');
  const [palette, setPalette] = useState<AchievementPaletteKey>('brand');
  const [formError, setFormError] = useState<string | null>(null);
  const [deletingCustom, setDeletingCustom] = useState<CustomBadge | null>(null);

  const earnedBuiltIn = achievementBadges.filter((b) => b.unlocked).length;
  const earnedCustom = customBadgeStatuses.filter((b) => b.unlocked).length;
  const totalCount = achievementBadges.length + customBadgeStatuses.length;
  const totalEarned = earnedBuiltIn + earnedCustom;

  const handleCreateCustomBadge = (e: React.FormEvent) => {
    e.preventDefault();
    const res = addCustomBadge({
      title,
      ruleType,
      targetValue,
      icon,
      palette,
    });
    if (!res.ok) {
      setFormError(res.error || 'Please check your badge details.');
      return;
    }
    setFormError(null);
    setTitle('');
    setTargetValue(ruleType === 'streak_days' ? 5 : 15);
    setCreatorOpen(false);
  };

  const displayedBuiltIn = compact ? achievementBadges.slice(0, 6) : achievementBadges;

  return (
    <section aria-label="Achievements and custom badges" className="sippy-card rounded-[24px] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-[17px] font-bold text-[var(--ink-900)]">Achievements</h2>
          <p className="text-xs font-medium text-[var(--ink-500)] sippy-num">
            {totalEarned} of {totalCount} unlocked · Best streak {bestStreak}d (now {currentStreak}d)
          </p>
        </div>

        {!compact && (
          <button
            type="button"
            onClick={() => {
              setCreatorOpen((v) => !v);
              setFormError(null);
            }}
            className="min-h-[38px] px-3 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer hover:bg-[var(--brand-100)] transition-colors"
          >
            {creatorOpen ? <X size={14} /> : <Plus size={14} />}
            <span>{creatorOpen ? 'Close' : 'Custom badge'}</span>
          </button>
        )}
      </div>

      {/* Custom Badge Builder */}
      {!compact && creatorOpen && (
        <form
          onSubmit={handleCreateCustomBadge}
          className="rounded-[20px] bg-[var(--canvas)] border border-[var(--line)] p-4 space-y-3.5"
        >
          <div className="flex items-center gap-3.5">
            <BadgeMedallion icon={icon} palette={palette} unlocked size={64} />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                New custom badge
              </p>
              <p className="text-sm font-extrabold text-[var(--ink-900)] truncate">
                {title.trim() || 'Your badge title'}
              </p>
              <p className="text-xs font-medium text-[var(--ink-500)] tabular-nums">
                {ruleType === 'streak_days'
                  ? `Unlock at ${targetValue}-day streak`
                  : `Unlock after ${targetValue} drinks logged`}
              </p>
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-semibold text-[var(--ink-500)]">Badge name</span>
            <input
              type="text"
              maxLength={28}
              value={title}
              placeholder="e.g. 5-Day Focus"
              aria-label="Custom badge name"
              onChange={(e) => {
                setTitle(e.target.value);
                if (formError) setFormError(null);
              }}
              className="mt-1 w-full h-11 px-3.5 rounded-[14px] bg-[var(--card)] border border-[var(--line)] text-sm font-bold text-[var(--ink-900)] placeholder:text-[var(--ink-300)] focus:outline-2 focus:outline-[var(--brand-500)]"
            />
          </label>

          {/* Rule Type */}
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                { id: 'streak_days', label: 'Streak days', defaultVal: 5 },
                { id: 'total_logs', label: 'Total drinks', defaultVal: 15 },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  setRuleType(opt.id);
                  setTargetValue(opt.defaultVal);
                }}
                className={`h-10 rounded-[12px] text-xs font-bold cursor-pointer ${
                  ruleType === opt.id
                    ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                    : 'bg-[var(--card)] text-[var(--ink-700)] border border-[var(--line)]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Target Stepper */}
          <div className="flex items-center justify-between rounded-[14px] bg-[var(--card)] border border-[var(--line)] px-3 py-2">
            <span className="text-xs font-semibold text-[var(--ink-700)]">
              {ruleType === 'streak_days' ? 'Target streak' : 'Target drinks'}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-label="Decrease badge target"
                onClick={() => setTargetValue((v) => Math.max(1, v - 1))}
                className="w-8 h-8 rounded-full bg-[var(--card-tint)] text-[var(--brand-600)] flex items-center justify-center cursor-pointer"
              >
                <Minus size={14} strokeWidth={2.5} />
              </button>
              <span className="min-w-[62px] text-center text-sm font-extrabold text-[var(--ink-900)] tabular-nums">
                {targetValue} {ruleType === 'streak_days' ? (targetValue === 1 ? 'day' : 'days') : 'drinks'}
              </span>
              <button
                type="button"
                aria-label="Increase badge target"
                onClick={() =>
                  setTargetValue((v) => Math.min(ruleType === 'streak_days' ? 365 : 500, v + 1))
                }
                className="w-8 h-8 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center cursor-pointer"
              >
                <Plus size={14} strokeWidth={2.5} />
              </button>
            </div>
          </div>

          {/* Color & Icon */}
          <div className="space-y-2">
            <span className="block text-xs font-semibold text-[var(--ink-500)]">Medallion color</span>
            <div className="flex items-center gap-2">
              {PALETTE_KEYS.map((key) => {
                const pal = ACHIEVEMENT_PALETTES[key];
                const selected = palette === key;
                return (
                  <button
                    key={key}
                    type="button"
                    aria-label={`Color ${pal.label}`}
                    onClick={() => setPalette(key)}
                    className={`w-9 h-9 rounded-full cursor-pointer transition-transform ${
                      selected ? 'ring-2 ring-offset-2 ring-[var(--ink-900)] scale-105' : ''
                    }`}
                    style={{ background: `linear-gradient(180deg, ${pal.from}, ${pal.to})` }}
                  />
                );
              })}
            </div>
          </div>

          <div className="space-y-2">
            <span className="block text-xs font-semibold text-[var(--ink-500)]">Icon</span>
            <div className="grid grid-cols-7 gap-1.5">
              {ICON_OPTIONS.map((opt) => {
                const active = icon === opt.key;
                return (
                  <button
                    key={opt.key}
                    type="button"
                    aria-label={`Badge icon ${opt.label}`}
                    onClick={() => setIcon(opt.key)}
                    className={`h-10 rounded-xl flex items-center justify-center cursor-pointer ${
                      active
                        ? 'bg-[var(--brand-500)] text-white'
                        : 'bg-[var(--card)] border border-[var(--line)] text-[var(--ink-700)]'
                    }`}
                  >
                    <MedallionGlyph
                      icon={opt.key}
                      color={active ? '#FFFFFF' : '#2F5BE0'}
                      size={18}
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {formError && (
            <p role="alert" className="text-xs font-bold text-[var(--coral-500)]">
              {formError}
            </p>
          )}

          <button
            type="submit"
            className="w-full h-11 rounded-[16px] bg-[var(--brand-500)] text-white text-sm font-bold sippy-press-brand cursor-pointer"
          >
            Create badge
          </button>
        </form>
      )}

      {/* Streak & Milestone Badges Grid */}
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)] mb-2.5">
          STREAK & MILESTONE BADGES
        </p>
        <div className="grid grid-cols-2 gap-3">
          {displayedBuiltIn.map((b) => {
            const cardTone = !b.unlocked
              ? { bg: 'var(--canvas)', border: 'var(--line)', shadow: 'none' }
              : b.palette === 'mint'
                ? { bg: 'var(--mint-100)', border: 'var(--edge-mint-tile)', shadow: '0 3px 0 var(--edge-mint-tile)' }
                : b.palette === 'flame'
                  ? { bg: 'var(--flame-tint)', border: 'var(--edge-flame)', shadow: '0 3px 0 var(--edge-flame)' }
                  : b.palette === 'water'
                    ? { bg: 'var(--water-100)', border: 'var(--edge-water)', shadow: '0 3px 0 var(--edge-water)' }
                    : b.palette === 'lav'
                      ? { bg: 'var(--lav-100)', border: 'var(--edge-lav)', shadow: '0 3px 0 var(--edge-lav)' }
                      : { bg: 'var(--brand-50)', border: 'var(--brand-100)', shadow: '0 3px 0 var(--edge-today)' };

            return (
              <div
                key={b.id}
                className="rounded-[20px] p-3.5 flex flex-col items-center text-center border-[1.5px]"
                style={{
                  backgroundColor: cardTone.bg,
                  borderColor: cardTone.border,
                  boxShadow: cardTone.shadow,
                }}
              >
                <BadgeMedallion icon={b.icon} palette={b.palette} unlocked={b.unlocked} size={62} />
                <p className="mt-2.5 text-[13.5px] font-extrabold text-[var(--ink-900)] leading-tight">
                  {b.title}
                </p>
                <p className="mt-0.5 text-[11px] text-[var(--ink-500)] leading-snug">
                  {b.description}
                </p>

                {/* Progress Bar */}
                <div className="mt-2.5 w-full space-y-1">
                  <div className="h-1.5 w-full rounded-full bg-white/75 dark:bg-black/25 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${b.progressPct}%`,
                        backgroundColor: b.unlocked ? 'var(--mint-500)' : 'var(--brand-400)',
                      }}
                    />
                  </div>
                  <p
                    className={`text-[10.5px] font-extrabold sippy-num ${
                      b.unlocked ? 'text-[var(--mint-500)]' : 'text-[var(--ink-500)]'
                    }`}
                  >
                    {b.unlocked
                      ? 'Unlocked'
                      : `${b.currentValue} / ${b.targetValue} ${b.unitLabel}`}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom Badges */}
      {!compact && (
        <div className="pt-2 border-t border-[var(--line)]">
          <div className="flex items-center justify-between mb-2.5">
            <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
              YOUR CUSTOM BADGES ({customBadgeStatuses.length})
            </p>
          </div>

          {customBadgeStatuses.length === 0 ? (
            <div className="rounded-[18px] bg-[var(--canvas)] p-4 text-center">
              <p className="text-xs font-medium text-[var(--ink-500)]">
                Create your own hydration streak goal badge to stay motivated.
              </p>
            </div>
          ) : (
            <ul className="space-y-2.5">
              {customBadgeStatuses.map(({ badge, currentValue, progressPct, unlocked }) => (
                <li
                  key={badge.id}
                  className="rounded-[20px] bg-[var(--canvas)] p-3 flex items-center gap-3"
                >
                  <BadgeMedallion
                    icon={badge.icon}
                    palette={badge.palette}
                    unlocked={unlocked}
                    size={56}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-extrabold text-[var(--ink-900)] truncate">
                        {badge.title}
                      </p>
                      <span
                        className={`px-2 py-0.5 rounded-[8px] text-[10px] font-extrabold shrink-0 ${
                          unlocked
                            ? 'bg-[var(--mint-100)] text-[var(--mint-500)]'
                            : 'bg-[var(--brand-50)] text-[var(--brand-600)]'
                        }`}
                      >
                        {unlocked ? 'Earned' : `${progressPct}%`}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--ink-500)] tabular-nums">
                      {badge.ruleType === 'streak_days'
                        ? `${currentValue} / ${badge.targetValue} streak days`
                        : `${currentValue} / ${badge.targetValue} drinks logged`}
                    </p>
                    <div className="mt-1.5 h-1.5 w-full rounded-full bg-[var(--card-tint)] overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${progressPct}%`,
                          backgroundColor: unlocked ? 'var(--mint-500)' : 'var(--brand-500)',
                        }}
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-label={`Delete custom badge ${badge.title}`}
                    onClick={() => setDeletingCustom(badge)}
                    className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-[var(--ink-300)] hover:text-[var(--coral-500)] hover:bg-[var(--coral-100)] transition-colors cursor-pointer shrink-0"
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <DeleteConfirmDialog
        open={Boolean(deletingCustom)}
        title={deletingCustom ? `Delete "${deletingCustom.title}"?` : 'Delete custom badge?'}
        description="This custom badge will be removed from your achievements list."
        confirmLabel="Delete badge"
        onCancel={() => setDeletingCustom(null)}
        onConfirm={() => {
          if (deletingCustom) {
            deleteCustomBadge(deletingCustom.id);
          }
          setDeletingCustom(null);
        }}
      />
    </section>
  );
};
