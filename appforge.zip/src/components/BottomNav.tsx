import React from 'react';
import { BarChart3, Calendar, Home, Plus, Settings } from 'lucide-react';
import { motion } from 'motion/react';
import { DropletLogoIcon } from './BrandIcons';

export type AppTab = 'home' | 'plan' | 'stats' | 'settings';

interface BottomNavProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  onOpenLog: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  onOpenLog,
}) => {
  const renderTab = (tab: AppTab, label: string, Icon: typeof Home) => {
    const isActive = activeTab === tab;
    return (
      <button
        key={tab}
        type="button"
        onClick={() => onSelectTab(tab)}
        aria-current={isActive ? 'page' : undefined}
        className={`relative flex flex-col items-center justify-center min-w-[44px] h-[50px] gap-1 px-1.5 rounded-[16px] transition-colors active:scale-95 focus-visible:outline-2 focus-visible:outline-[var(--brand-500)] cursor-pointer ${
          isActive
            ? 'bg-[var(--brand-50)] text-[var(--brand-600)]'
            : 'text-[var(--ink-500)] hover:text-[var(--ink-900)]'
        }`}
      >
        <Icon size={20} strokeWidth={isActive ? 2.25 : 1.8} />
        <span className="text-[11px] font-bold leading-none whitespace-nowrap">
          {label}
        </span>
      </button>
    );
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-30 pointer-events-none pb-safe">
      <div className="max-w-[480px] mx-auto px-4 pb-2.5">
        <nav
          aria-label="Primary navigation"
          className="pointer-events-auto h-[64px] rounded-[22px] sippy-nav-glass border border-[var(--line)] grid grid-cols-5 items-center gap-1 px-2"
        >
          {renderTab('home', 'Home', Home)}
          {renderTab('plan', 'Plan', Calendar)}

          <div className="flex items-center justify-center">
            <motion.button
              type="button"
              onClick={onOpenLog}
              aria-label="Log a drink"
              whileTap={{ scale: 0.94 }}
              transition={{ duration: 0.14, ease: [0.22, 1, 0.36, 1] }}
              className="relative w-full max-w-[60px] h-[50px] rounded-[16px] bg-[var(--brand-50)] hover:bg-[var(--brand-100)] border border-[var(--brand-100)] text-[var(--brand-600)] flex flex-col items-center justify-center gap-0.5 focus-visible:outline-2 focus-visible:outline-[var(--brand-500)] cursor-pointer"
            >
              <span className="relative inline-flex items-center justify-center">
                <DropletLogoIcon size={21} className="text-[var(--brand-500)]" />
                <Plus
                  size={10}
                  strokeWidth={3}
                  className="absolute -right-2 -top-0.5 text-[var(--brand-600)]"
                />
              </span>
              <span className="text-[10px] font-extrabold leading-none text-[var(--brand-600)]">
                Log
              </span>
            </motion.button>
          </div>

          {renderTab('stats', 'Stats', BarChart3)}
          {renderTab('settings', 'Settings', Settings)}
        </nav>
      </div>
    </div>
  );
};
