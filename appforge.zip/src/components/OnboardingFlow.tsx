import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Activity,
  Bell,
  Calculator,
  Check,
  ChevronLeft,
  Flame,
  Info,
  Mail,
  Minus,
  Plus,
  Share,
  Sparkles,
} from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import type {
  GlassPreset,
  NotificationTone,
  SippyMood,
  WorkoutLevel,
} from '../types';
import { createDefaultGlasses } from '../utils/demoData';
import { calculateRecommendedWaterGoal } from '../utils/hydrationCalculator';
import { DrinkGlyph, DropletLogoIcon, SmallGlassGauge } from './BrandIcons';
import { Mascot } from './Mascot';
import { PWAInstallButton } from './PWAInstallBanner';

const GOAL_PRESETS = [2000, 2500, 3000, 3500];

const PERSONA_OPTIONS: {
  id: NotificationTone;
  title: string;
  tagline: string;
  sampleTitle: string;
  sampleBody: string;
  mood: SippyMood;
  tintBg: string;
  tintBorder: string;
  tintEdge: string;
  badgeText: string;
  badgeClass: string;
}[] = [
  {
    id: 'coach',
    title: 'Coach',
    tagline: 'Focused, energetic splits that keep you hitting pace.',
    sampleTitle: 'Next 250 ml',
    sampleBody: "You're 400 ml behind split. Lock in a quick glass!",
    mood: 'proud',
    tintBg: 'var(--brand-50)',
    tintBorder: 'var(--brand-500)',
    tintEdge: 'var(--edge-brand)',
    badgeText: 'Athletic pace',
    badgeClass: 'bg-[var(--brand-500)] text-white',
  },
  {
    id: 'gentle',
    title: 'Gentle',
    tagline: 'Calm, mindful check-ins with zero pressure or rush.',
    sampleTitle: 'Sip time',
    sampleBody: 'A few quiet sips now will keep your afternoon easy.',
    mood: 'happy',
    tintBg: 'var(--mint-100)',
    tintBorder: 'var(--mint-500)',
    tintEdge: 'var(--edge-mint)',
    badgeText: 'Soft & calm',
    badgeClass: 'bg-[var(--mint-500)] text-white',
  },
  {
    id: 'playful',
    title: 'Playful',
    tagline: 'Dramatic jokes, cheeky winks, and upbeat cheer.',
    sampleTitle: 'Sippy is parched',
    sampleBody: "250 ml and I'll stop dramatically fainting.",
    mood: 'cheeky',
    tintBg: 'var(--flame-tint)',
    tintBorder: '#FF6B2C',
    tintEdge: '#D9531E',
    badgeText: 'Fun & cheeky',
    badgeClass: 'bg-[#FF6B2C] text-white',
  },
];

const WORKOUT_LEVELS: { id: WorkoutLevel; label: string; hint: string }[] = [
  { id: 'light', label: 'Light', hint: 'Walks · yoga' },
  { id: 'moderate', label: 'Moderate', hint: 'Gym · runs' },
  { id: 'intense', label: 'Intense', hint: 'HIIT · sports' },
];

const GoogleGIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
    <path
      fill="#4285F4"
      d="M23.52 12.27c0-.85-.08-1.68-.22-2.48H12v4.69h6.46a5.52 5.52 0 0 1-2.39 3.62v3.01h3.87c2.26-2.08 3.58-5.15 3.58-8.84Z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.95-1.07 7.94-2.91l-3.87-3.01c-1.07.72-2.45 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.27v3.1A11.99 11.99 0 0 0 12 24Z"
    />
    <path
      fill="#FBBC05"
      d="M5.27 14.27A7.2 7.2 0 0 1 4.89 12c0-.79.14-1.56.38-2.27V6.63H1.27A11.99 11.99 0 0 0 0 12c0 1.93.46 3.76 1.27 5.37l4-3.1Z"
    />
    <path
      fill="#EA4335"
      d="M12 4.77c1.76 0 3.34.61 4.58 1.8l3.44-3.44C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.69 1.27 6.63l4 3.1C6.22 6.88 8.87 4.77 12 4.77Z"
    />
  </svg>
);

export const OnboardingFlow: React.FC = () => {
  const {
    onboardingStep,
    setOnboardingStep,
    authUser,
    authError,
    signInWithGoogle,
    startDemoMode,
    finishOnboarding,
    enablePushNotifications,
  } = useSippy();

  const { isIOS, isInstalled } = usePWAInstall();

  const [name, setName] = useState(() => authUser?.displayName?.split(' ')[0] || '');
  const [emailInput, setEmailInput] = useState(() => authUser?.email || '');
  const [nameError, setNameError] = useState<string | null>(null);
  const [usingEmailFlow, setUsingEmailFlow] = useState(false);

  const [tone, setTone] = useState<NotificationTone>('playful');
  const [goalMode, setGoalMode] = useState<'manual' | 'calculator'>('manual');
  const [goalMl, setGoalMl] = useState(2500);

  // Hydration calculator inputs (for "I don't know / Get your goal")
  const [age, setAge] = useState(28);
  const [weightKg, setWeightKg] = useState(68);
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lb'>('kg');
  const [heightCm, setHeightCm] = useState(172);
  const [workoutLevel, setWorkoutLevel] = useState<WorkoutLevel>('moderate');
  const [workoutsPerWeek, setWorkoutsPerWeek] = useState(3);

  const calcResult = useMemo(
    () =>
      calculateRecommendedWaterGoal({
        age,
        weightKg,
        heightCm,
        workoutLevel,
        workoutsPerWeek,
      }),
    [age, weightKg, heightCm, workoutLevel, workoutsPerWeek]
  );

  const activeGoalMl = goalMode === 'calculator' ? calcResult.goalMl : goalMl;

  const [wakeTime, setWakeTime] = useState('07:00');
  const [bedTime, setBedTime] = useState('23:00');
  const [glasses, setGlasses] = useState<GlassPreset[]>(() =>
    createDefaultGlasses(authUser?.uid || 'pending')
  );
  const [selectedIds, setSelectedIds] = useState<string[]>(['glass_250', 'glass_300']);
  const [defaultGlassId, setDefaultGlassId] = useState('glass_250');
  const [customMl, setCustomMl] = useState(400);
  const [customName, setCustomName] = useState('');
  const [showCustomAdder, setShowCustomAdder] = useState(false);

  const [pushStatus, setPushStatus] = useState<string | null>(null);
  const [buildingPlan, setBuildingPlan] = useState(false);

  useEffect(() => {
    if (authUser?.displayName && !name.trim()) {
      setName(authUser.displayName.split(' ')[0]);
    }
    if (authUser?.email && !emailInput.trim()) {
      setEmailInput(authUser.email);
    }
  }, [authUser, name, emailInput]);

  const activePersona =
    PERSONA_OPTIONS.find((p) => p.id === tone) ?? PERSONA_OPTIONS[2];

  const toggleGlassSelect = (id: string) => {
    setSelectedIds((prev) => {
      if (prev.includes(id)) {
        if (prev.length === 1) return prev;
        const next = prev.filter((x) => x !== id);
        if (defaultGlassId === id) setDefaultGlassId(next[0]);
        return next;
      }
      return [...prev, id];
    });
  };

  const handleAddCustomGlass = () => {
    const ml = Math.max(50, Math.min(1500, Math.round(customMl)));
    const id = `glass_custom_${Date.now()}`;
    const newGlass: GlassPreset = {
      id,
      uid: authUser?.uid || 'pending',
      name: customName.trim() || `${ml} ml Glass`,
      ml,
      icon: 'bottle',
    };
    setGlasses((prev) => [...prev, newGlass]);
    setSelectedIds((prev) => [...prev, id]);
    setDefaultGlassId(id);
    setCustomName('');
    setShowCustomAdder(false);
  };

  const handleTurnOnReminders = async () => {
    const res = await enablePushNotifications();
    if (res.granted) {
      setPushStatus('Reminders are on!');
    } else {
      setPushStatus(res.reason || 'Skipped for now — you can turn these on in Settings.');
    }
  };

  const handleContinueFromName = () => {
    if (!name.trim()) {
      setNameError('Tell Sippy your first name so we can personalize your day.');
      return;
    }
    setNameError(null);
    setOnboardingStep(3);
  };

  const handleContinueFromGoal = () => {
    if (goalMode === 'calculator') {
      setGoalMl(calcResult.goalMl);
    }
    setOnboardingStep(5);
  };

  const handleComplete = async () => {
    setBuildingPlan(true);
    const chosen = glasses.filter((g) => selectedIds.includes(g.id));
    window.setTimeout(async () => {
      await finishOnboarding({
        name: name.trim() || authUser?.displayName?.split(' ')[0] || 'Friend',
        email: emailInput.trim() || undefined,
        goalMl: activeGoalMl,
        wakeTime,
        bedTime,
        tone,
        selectedGlasses: chosen.length > 0 ? chosen : glasses.slice(0, 2),
        defaultGlassId: selectedIds.includes(defaultGlassId)
          ? defaultGlassId
          : chosen[0]?.id || 'glass_250',
      });
    }, 950);
  };

  if (buildingPlan) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center p-6 text-center bg-[var(--canvas)]">
        <motion.div
          initial={{ scale: 0.92, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full max-w-[400px] sippy-hero-card rounded-[28px] p-8 flex flex-col items-center"
        >
          <Mascot mood="hyped" persona={tone} size={120} />
          <h2 className="mt-4 text-[24px] font-extrabold text-[var(--ink-900)]">
            Building {name.trim() || 'your'}’s plan
          </h2>
          <p className="mt-2 text-[15px] text-[var(--ink-500)] sippy-num">
            Setting {activeGoalMl.toLocaleString()} ml between {wakeTime} and {bedTime}.
          </p>
        </motion.div>
      </div>
    );
  }

  // Step 1: Welcome (full brand-blue canvas)
  if (onboardingStep === 1) {
    return (
      <div className="min-h-dvh w-full bg-[var(--brand-500)] text-white flex flex-col">
        <div className="flex-1 w-full max-w-[480px] mx-auto px-6 py-6 flex flex-col justify-between">
          <header className="pt-safe flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DropletLogoIcon size={24} className="text-white" />
              <span className="text-[22px] font-extrabold tracking-tight text-white">Sippy</span>
            </div>
            <PWAInstallButton compact />
          </header>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="my-auto py-4 flex flex-col items-center text-center"
          >
            <div className="relative bg-white text-[#0B1633] rounded-[18px] px-5 py-3 shadow-lg mb-3">
              <p className="text-[16px] font-extrabold tracking-tight">Hi, I’m Sippy!</p>
              <div
                aria-hidden="true"
                className="absolute left-9 -bottom-2 w-0 h-0 border-x-[8px] border-x-transparent border-t-[10px] border-t-white"
              />
            </div>

            <Mascot mood="waving" persona={tone} size={156} interactive hideShadow />

            <h1 className="mt-5 text-[36px] leading-[42px] font-extrabold tracking-[-0.02em] text-white">
              Drinking enough,
              <br />
              made easy
            </h1>
            <p className="mt-3 text-[16px] leading-[22px] text-[var(--brand-100)] font-medium max-w-[300px]">
              Friendly nudges, simple streaks, zero guilt.
            </p>

            {authError && (
              <p className="mt-3 text-xs font-semibold text-white bg-[#FF6B6B]/25 border border-white/30 px-3.5 py-2 rounded-xl">
                {authError}
              </p>
            )}
          </motion.div>

          <div className="space-y-3 pb-safe">
            <button
              type="button"
              onClick={() => void signInWithGoogle()}
              className="w-full h-14 rounded-[20px] bg-white text-[#0B1633] font-bold text-[17px] flex items-center justify-center gap-2.5 sippy-press-white cursor-pointer"
            >
              <GoogleGIcon />
              <span>Continue with Google</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setUsingEmailFlow(true);
                setOnboardingStep(2);
              }}
              className="w-full h-14 rounded-[20px] bg-transparent border-2 border-white/75 text-white font-bold text-[17px] flex items-center justify-center gap-2.5 active:scale-[0.98] transition-transform cursor-pointer hover:bg-white/10"
            >
              <Mail size={20} />
              <span>Continue with email</span>
            </button>

            <div className="pt-1 flex flex-col items-center gap-2">
              <button
                type="button"
                onClick={startDemoMode}
                className="min-h-[36px] px-4 rounded-full text-xs font-bold text-white/90 hover:text-white underline underline-offset-4 cursor-pointer"
              >
                Preview with demo data
              </button>
              <p className="text-[11px] text-white/80 text-center">
                By continuing you agree to the Terms and Privacy Policy
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Steps 2..6 -> 5-dash progress indicator
  const activeDashIndex = Math.max(1, Math.min(5, onboardingStep - 1));
  const totalGlasses10 = Math.max(1, Math.min(10, Math.round(activeGoalMl / 250)));
  const displayWeight = weightUnit === 'kg' ? weightKg : Math.round(weightKg * 2.20462);

  return (
    <div className="min-h-dvh max-w-[480px] mx-auto px-5 py-6 flex flex-col justify-between bg-[var(--canvas)]">
      {/* Header: Back chevron + 5-dash progress bar */}
      <header className="flex items-center gap-3 pt-safe">
        <button
          type="button"
          aria-label="Go back"
          onClick={() => setOnboardingStep(Math.max(1, onboardingStep - 1))}
          className="w-11 h-11 -ml-2 rounded-full flex items-center justify-center text-[var(--brand-600)] hover:bg-[var(--card-tint)] active:scale-95 transition-transform cursor-pointer"
        >
          <ChevronLeft size={24} strokeWidth={2.5} />
        </button>

        <div className="flex-1 grid grid-cols-5 gap-2 pr-4" aria-label={`Step ${activeDashIndex} of 5`}>
          {[1, 2, 3, 4, 5].map((dash) => (
            <span
              key={dash}
              className={`h-1.5 rounded-full transition-colors duration-300 ${
                dash <= activeDashIndex ? 'bg-[var(--brand-500)]' : 'bg-[var(--line)]'
              }`}
            />
          ))}
        </div>
      </header>

      {/* Step Content */}
      <div className="flex-1 flex flex-col justify-center py-4">
        <AnimatePresence mode="wait">
          {/* Step 2: Name Onboarding Step */}
          {onboardingStep === 2 && (
            <motion.div
              key="step-name"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-5"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h1 className="text-[30px] leading-[36px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
                    What should I
                    <br />
                    call you?
                  </h1>
                  <p className="mt-2 text-[15px] leading-[22px] text-[var(--ink-500)]">
                    Sippy greets you here and cheers on every streak.
                  </p>
                </div>
                <Mascot mood={name.trim() ? 'happy' : 'thinking'} persona={tone} size={84} interactive />
              </div>

              <div className="sippy-hero-card rounded-[28px] p-5 space-y-4">
                <label className="block">
                  <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
                    First name
                  </span>
                  <input
                    type="text"
                    value={name}
                    maxLength={32}
                    autoFocus
                    placeholder="e.g. Alex"
                    aria-label="Your first name"
                    onChange={(e) => {
                      setName(e.target.value);
                      if (nameError) setNameError(null);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleContinueFromName();
                    }}
                    className="mt-2 w-full h-14 px-4 rounded-[18px] bg-[var(--card)] text-[18px] font-bold text-[var(--ink-900)] placeholder:text-[var(--ink-300)] shadow-xs focus:outline-2 focus:outline-[var(--brand-500)]"
                  />
                </label>

                {usingEmailFlow && !authUser && (
                  <label className="block">
                    <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
                      Email (optional)
                    </span>
                    <input
                      type="email"
                      value={emailInput}
                      placeholder="you@example.com"
                      aria-label="Your email address"
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="mt-2 w-full h-12 px-4 rounded-[16px] bg-[var(--card)] text-[15px] font-semibold text-[var(--ink-900)] placeholder:text-[var(--ink-300)] focus:outline-2 focus:outline-[var(--brand-500)]"
                    />
                  </label>
                )}

                {nameError && (
                  <p role="alert" className="text-xs font-bold text-[var(--coral-500)]">
                    {nameError}
                  </p>
                )}

                <div className="rounded-[18px] bg-[var(--card)]/85 px-4 py-3 flex items-center gap-2.5">
                  <DropletLogoIcon size={18} className="text-[var(--brand-500)] shrink-0" />
                  <p className="text-[14px] font-semibold text-[var(--ink-700)]">
                    {name.trim()
                      ? `Hi ${name.trim()}, next let’s pick your Sippy buddy!`
                      : 'Enter your name so Sippy knows who to cheer for.'}
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 3: Persona Selection (Coach, Gentle, Playful with Custom Mascots) */}
          {onboardingStep === 3 && (
            <motion.div
              key="step-persona"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-4"
            >
              <div>
                <h1 className="text-[30px] leading-[36px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
                  Pick your Sippy
                </h1>
                <p className="mt-1.5 text-[15px] leading-[21px] text-[var(--ink-500)]">
                  Each persona comes with its own look and reminder style.
                </p>
              </div>

              {/* Live Persona Mascot Showcase */}
              <div
                className="rounded-[26px] p-4 flex items-center gap-3.5 border-[1.5px] transition-colors"
                style={{
                  backgroundColor: activePersona.tintBg,
                  borderColor: activePersona.tintBorder,
                }}
              >
                <div className="shrink-0">
                  <Mascot
                    mood={activePersona.mood}
                    persona={activePersona.id}
                    size={96}
                    interactive
                    hideShadow
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-[8px] text-[11px] font-extrabold ${activePersona.badgeClass}`}
                  >
                    {activePersona.title} Sippy
                  </span>
                  <div className="mt-2 rounded-[16px] bg-[var(--card)] px-3.5 py-2.5 shadow-xs">
                    <p className="text-[12px] font-extrabold text-[var(--ink-900)]">
                      “{activePersona.sampleTitle}”
                    </p>
                    <p className="mt-0.5 text-[12.5px] font-medium text-[var(--ink-500)] leading-snug">
                      {activePersona.sampleBody}
                    </p>
                  </div>
                </div>
              </div>

              {/* 3 Tactile Persona Option Cards */}
              <div className="space-y-2.5" role="radiogroup" aria-label="Choose Sippy persona">
                {PERSONA_OPTIONS.map((option) => {
                  const selected = tone === option.id;
                  return (
                    <button
                      key={option.id}
                      type="button"
                      role="radio"
                      aria-checked={selected}
                      onClick={() => setTone(option.id)}
                      className={`w-full rounded-[22px] p-3.5 flex items-center gap-3.5 text-left transition-all cursor-pointer border-2 ${
                        selected
                          ? 'bg-[var(--card)]'
                          : 'bg-[var(--card)] border-transparent hover:bg-[var(--card-tint)]/60'
                      }`}
                      style={
                        selected
                          ? {
                              borderColor: option.tintBorder,
                              boxShadow: `0 4px 0 ${option.tintBorder}`,
                            }
                          : {
                              borderColor: 'var(--line)',
                            }
                      }
                    >
                      <div
                        className="w-[64px] h-[64px] rounded-[18px] flex items-center justify-center shrink-0"
                        style={{ backgroundColor: option.tintBg }}
                      >
                        <Mascot
                          mood={option.mood}
                          persona={option.id}
                          size={56}
                          hideShadow
                        />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[17px] font-extrabold text-[var(--ink-900)]">
                            {option.title}
                          </span>
                          <span className="text-[11px] font-bold text-[var(--ink-500)]">
                            · {option.badgeText}
                          </span>
                        </div>
                        <p className="mt-0.5 text-[13px] leading-snug font-medium text-[var(--ink-500)]">
                          {option.tagline}
                        </p>
                      </div>

                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border-2 ${
                          selected
                            ? 'text-white border-transparent'
                            : 'border-[var(--line)] bg-transparent'
                        }`}
                        style={selected ? { backgroundColor: option.tintBorder } : undefined}
                      >
                        {selected && <Check size={14} strokeWidth={3} />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Step 4: Daily Goal OR "I don't know · Get your goal" Calculator */}
          {onboardingStep === 4 && (
            <motion.div
              key="step-goal"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h1 className="text-[28px] leading-[34px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
                    How much water
                    <br />
                    a day?
                  </h1>
                  <p className="mt-1.5 text-[14px] leading-[20px] text-[var(--ink-500)]">
                    {goalMode === 'manual'
                      ? 'Pick your target, or let Sippy calculate it.'
                      : 'Answer a few quick details like a calorie tracker.'}
                  </p>
                </div>
                <Mascot
                  mood={goalMode === 'calculator' ? 'thinking' : 'happy'}
                  persona={tone}
                  size={82}
                  interactive
                />
              </div>

              {/* Manual vs "I don't know / Get your goal" Switcher */}
              <div className="p-1.5 rounded-[18px] bg-[var(--card-tint)] grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => setGoalMode('manual')}
                  className={`h-11 rounded-[14px] text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
                    goalMode === 'manual'
                      ? 'bg-[var(--card)] text-[var(--ink-900)] shadow-xs'
                      : 'text-[var(--ink-500)] hover:text-[var(--ink-900)]'
                  }`}
                >
                  <DropletLogoIcon size={15} className="text-[var(--brand-500)]" />
                  <span>Set my goal</span>
                </button>
                <button
                  type="button"
                  onClick={() => setGoalMode('calculator')}
                  className={`h-11 rounded-[14px] text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
                    goalMode === 'calculator'
                      ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                      : 'text-[var(--brand-600)] hover:bg-white/50'
                  }`}
                >
                  <Calculator size={15} />
                  <span>I don’t know · Get goal</span>
                </button>
              </div>

              {goalMode === 'manual' ? (
                <>
                  {/* Gradient Hero Card with Stepper + 10 Glasses */}
                  <div className="sippy-hero-card rounded-[28px] px-5 py-6">
                    <div className="flex items-center justify-between gap-3">
                      <button
                        type="button"
                        aria-label="Decrease goal by 100 ml"
                        onClick={() => setGoalMl((g) => Math.max(1000, g - 100))}
                        className="w-[52px] h-[52px] rounded-full bg-white text-[var(--brand-600)] flex items-center justify-center sippy-press-white shrink-0 cursor-pointer"
                      >
                        <Minus size={22} strokeWidth={2.5} />
                      </button>

                      <div className="text-center">
                        <motion.p
                          key={goalMl}
                          initial={{ scale: 0.92 }}
                          animate={{ scale: 1 }}
                          transition={{ type: 'spring', stiffness: 420, damping: 22 }}
                          className="text-[50px] leading-[54px] font-extrabold text-[var(--ink-900)] sippy-num"
                        >
                          {goalMl.toLocaleString()}
                        </motion.p>
                        <p className="mt-0.5 text-[16px] font-semibold text-[var(--ink-500)]">ml a day</p>
                      </div>

                      <button
                        type="button"
                        aria-label="Increase goal by 100 ml"
                        onClick={() => setGoalMl((g) => Math.min(5000, g + 100))}
                        className="w-[52px] h-[52px] rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center sippy-press-brand shrink-0 cursor-pointer"
                      >
                        <Plus size={22} strokeWidth={2.5} />
                      </button>
                    </div>

                    <div className="my-5 h-[1.5px] bg-white/80 rounded-full" />

                    <div className="flex items-center justify-center gap-1.5" aria-hidden="true">
                      {Array.from({ length: 10 }, (_, idx) => {
                        const glassPortion = Math.max(0, Math.min(1, goalMl / 250 - idx));
                        return (
                          <SmallGlassGauge
                            key={idx}
                            fillLevel={glassPortion > 0 ? Math.max(0.45, glassPortion) : 0}
                            size={21}
                          />
                        );
                      })}
                    </div>

                    <p className="mt-3 text-center text-[15px] font-bold text-[var(--ink-900)] sippy-num">
                      About {Math.round(goalMl / 250)} glasses of 250 ml
                    </p>
                    <p className="mt-0.5 text-center text-[13px] font-medium text-[var(--ink-500)]">
                      Tap + or − to change by <span className="sippy-num">100 ml</span>
                    </p>
                  </div>

                  {/* QUICK PICKS */}
                  <div>
                    <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)] mb-2.5">
                      QUICK PICKS
                    </p>
                    <div className="grid grid-cols-4 gap-2">
                      {GOAL_PRESETS.map((preset) => {
                        const active = goalMl === preset;
                        return (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setGoalMl(preset)}
                            className={`h-11 rounded-[16px] text-[15px] font-extrabold sippy-num cursor-pointer ${
                              active
                                ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                                : 'bg-[var(--card-tint)] text-[var(--ink-700)] sippy-press-tint'
                            }`}
                          >
                            {(preset / 1000).toFixed(1)} L
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              ) : (
                /* Playful Calorie-Tracker-Style Hydration Calculator */
                <div className="space-y-3">
                  {/* Live Saturated Theme-Blue Result Banner */}
                  <div className="sippy-blue-feature rounded-[24px] p-4 text-white">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-[var(--brand-100)]">
                          Get your goal
                        </p>
                        <p className="mt-0.5 text-[38px] leading-none font-extrabold text-white sippy-num">
                          {calcResult.goalMl.toLocaleString()}{' '}
                          <span className="text-[16px] font-bold text-[var(--brand-100)]">ml</span>
                        </p>
                      </div>
                      <div className="rounded-[16px] bg-white/18 px-3 py-2 text-right">
                        <p className="text-[18px] leading-tight font-extrabold text-white sippy-num">
                          ~{calcResult.glassesOf250Ml} glasses
                        </p>
                        <p className="text-[11px] font-semibold text-[var(--brand-100)]">
                          {calcResult.tierLabel}
                        </p>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-white/20 flex items-center justify-between text-xs font-bold text-[var(--brand-100)] sippy-num">
                      <span>Base body need: {calcResult.baseMl.toLocaleString()} ml</span>
                      <span>
                        Workout add-on: +{calcResult.activityBonusMl.toLocaleString()} ml
                      </span>
                    </div>
                  </div>

                  {/* Body Stats Card: Age, Weight, Height */}
                  <div className="sippy-card rounded-[24px] p-4 space-y-3.5">
                    {/* Age Stepper + Slider */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                          Age
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            aria-label="Decrease age"
                            onClick={() => setAge((a) => Math.max(12, a - 1))}
                            className="w-7 h-7 rounded-full bg-[var(--card-tint)] text-[var(--brand-600)] flex items-center justify-center cursor-pointer"
                          >
                            <Minus size={13} strokeWidth={2.5} />
                          </button>
                          <span className="min-w-[64px] text-center text-base font-extrabold text-[var(--ink-900)] sippy-num">
                            {age} yrs
                          </span>
                          <button
                            type="button"
                            aria-label="Increase age"
                            onClick={() => setAge((a) => Math.min(90, a + 1))}
                            className="w-7 h-7 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center cursor-pointer"
                          >
                            <Plus size={13} strokeWidth={2.5} />
                          </button>
                        </div>
                      </div>
                      <input
                        type="range"
                        min={14}
                        max={85}
                        value={age}
                        aria-label="Age in years"
                        onChange={(e) => setAge(Number(e.target.value))}
                        className="w-full accent-[var(--brand-500)] cursor-pointer"
                      />
                    </div>

                    {/* Weight Slider with kg/lb toggle */}
                    <div className="space-y-1.5 pt-1 border-t border-[var(--line)]/70">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                            Weight
                          </span>
                          <div className="p-0.5 rounded-full bg-[var(--card-tint)] flex text-[10px] font-bold">
                            {(['kg', 'lb'] as const).map((u) => (
                              <button
                                key={u}
                                type="button"
                                onClick={() => setWeightUnit(u)}
                                className={`px-2 py-0.5 rounded-full cursor-pointer ${
                                  weightUnit === u
                                    ? 'bg-[var(--brand-500)] text-white'
                                    : 'text-[var(--ink-500)]'
                                }`}
                              >
                                {u}
                              </button>
                            ))}
                          </div>
                        </div>
                        <span className="text-base font-extrabold text-[var(--ink-900)] sippy-num">
                          {displayWeight} {weightUnit}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={40}
                        max={145}
                        value={weightKg}
                        aria-label="Weight"
                        onChange={(e) => setWeightKg(Number(e.target.value))}
                        className="w-full accent-[var(--brand-500)] cursor-pointer"
                      />
                    </div>

                    {/* Height Slider */}
                    <div className="space-y-1.5 pt-1 border-t border-[var(--line)]/70">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                          Height
                        </span>
                        <span className="text-base font-extrabold text-[var(--ink-900)] sippy-num">
                          {heightCm} cm
                        </span>
                      </div>
                      <input
                        type="range"
                        min={135}
                        max={215}
                        value={heightCm}
                        aria-label="Height in centimeters"
                        onChange={(e) => setHeightCm(Number(e.target.value))}
                        className="w-full accent-[var(--brand-500)] cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Workout Level & Times Per Week */}
                  <div className="sippy-card rounded-[24px] p-4 space-y-3.5">
                    <div>
                      <div className="flex items-center gap-1.5 mb-2">
                        <Activity size={14} className="text-[var(--mint-500)]" />
                        <span className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                          Workout level
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        {WORKOUT_LEVELS.map((lvl) => {
                          const active = workoutLevel === lvl.id;
                          return (
                            <button
                              key={lvl.id}
                              type="button"
                              onClick={() => setWorkoutLevel(lvl.id)}
                              className={`rounded-[16px] p-2.5 text-center cursor-pointer transition-colors ${
                                active
                                  ? 'bg-[var(--mint-500)] text-white'
                                  : 'bg-[var(--card-tint)] text-[var(--ink-900)]'
                              }`}
                              style={active ? { boxShadow: '0 3px 0 var(--edge-mint)' } : undefined}
                            >
                              <p className="text-xs font-extrabold">{lvl.label}</p>
                              <p
                                className={`text-[10.5px] font-medium ${
                                  active ? 'text-white/90' : 'text-[var(--ink-500)]'
                                }`}
                              >
                                {lvl.hint}
                              </p>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="pt-1 border-t border-[var(--line)]/70">
                      <div className="flex items-center justify-between mb-2">
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                          <Flame size={14} className="text-[#FF6B2C]" />
                          <span>Workouts / week</span>
                        </span>
                        <span className="text-xs font-extrabold text-[var(--brand-600)] sippy-num">
                          {workoutsPerWeek === 0
                            ? 'Rest week'
                            : `${workoutsPerWeek} ${workoutsPerWeek === 1 ? 'time' : 'times'}`}
                        </span>
                      </div>
                      <div className="grid grid-cols-8 gap-1.5">
                        {[0, 1, 2, 3, 4, 5, 6, 7].map((count) => {
                          const active = workoutsPerWeek === count;
                          return (
                            <button
                              key={count}
                              type="button"
                              aria-label={`${count} workouts per week`}
                              onClick={() => setWorkoutsPerWeek(count)}
                              className={`h-10 rounded-[12px] text-sm font-extrabold sippy-num cursor-pointer ${
                                active
                                  ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                                  : 'bg-[var(--card-tint)] text-[var(--ink-700)]'
                              }`}
                            >
                              {count}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Doctor advice info note */}
              <div className="rounded-[16px] bg-[var(--brand-50)] px-4 py-3 flex items-center gap-3">
                <Info size={19} className="text-[var(--brand-600)] shrink-0" />
                <p className="text-[13px] leading-[18px] font-semibold text-[var(--ink-700)]">
                  If you have a doctor’s advice on water, follow that
                </p>
              </div>
            </motion.div>
          )}

          {/* Step 5: Awake Window & Go-To Glasses */}
          {onboardingStep === 5 && (
            <motion.div
              key="step-window"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h1 className="text-[28px] leading-[34px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
                    Awake hours &<br />
                    go-to glasses
                  </h1>
                  <p className="mt-1.5 text-[14px] text-[var(--ink-500)]">
                    Sippy only nudges while you’re awake.
                  </p>
                </div>
                <Mascot mood="sleepy" persona={tone} size={76} />
              </div>

              <div className="sippy-card rounded-[24px] p-4 grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-[11px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
                    Wake up
                  </span>
                  <input
                    type="time"
                    value={wakeTime}
                    onChange={(e) => setWakeTime(e.target.value)}
                    className="mt-1.5 w-full h-11 px-3 rounded-[14px] bg-[var(--card-tint)] text-[var(--ink-900)] font-bold sippy-num"
                  />
                </label>
                <label className="block">
                  <span className="text-[11px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
                    Bedtime
                  </span>
                  <input
                    type="time"
                    value={bedTime}
                    onChange={(e) => setBedTime(e.target.value)}
                    className="mt-1.5 w-full h-11 px-3 rounded-[14px] bg-[var(--card-tint)] text-[var(--ink-900)] font-bold sippy-num"
                  />
                </label>
              </div>

              <div>
                <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)] mb-2">
                  YOUR GLASSES
                </p>
                <div className="grid grid-cols-2 gap-2.5">
                  {glasses.map((g) => {
                    const selected = selectedIds.includes(g.id);
                    const isDef = defaultGlassId === g.id;
                    return (
                      <div
                        key={g.id}
                        className={`rounded-[20px] p-3 sippy-card transition-all ${
                          selected ? 'ring-2 ring-[var(--brand-500)]' : ''
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => toggleGlassSelect(g.id)}
                          className="w-full text-left flex items-center justify-between cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-9 h-9 rounded-xl bg-[var(--water-100)] text-[var(--water-500)] flex items-center justify-center">
                              <DrinkGlyph type={g.icon} size={19} color="#19B4F2" />
                            </span>
                            <div>
                              <p className="text-sm font-extrabold text-[var(--ink-900)] sippy-num">{g.ml} ml</p>
                              <p className="text-[11px] text-[var(--ink-500)] truncate max-w-[78px]">{g.name}</p>
                            </div>
                          </div>
                          {selected && (
                            <span className="w-5 h-5 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center">
                              <Check size={12} strokeWidth={3} />
                            </span>
                          )}
                        </button>

                        {selected && (
                          <button
                            type="button"
                            onClick={() => setDefaultGlassId(g.id)}
                            className={`mt-2.5 w-full h-8 rounded-full text-xs font-bold cursor-pointer ${
                              isDef
                                ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                                : 'bg-[var(--card-tint)] text-[var(--ink-700)]'
                            }`}
                          >
                            {isDef ? 'Default tap' : 'Make default'}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {!showCustomAdder ? (
                <button
                  type="button"
                  onClick={() => setShowCustomAdder(true)}
                  className="w-full h-11 rounded-[16px] border-2 border-dashed border-[#C3CCDD] bg-[var(--card-tint)] text-sm font-bold text-[var(--brand-600)] cursor-pointer"
                >
                  + Add custom size
                </button>
              ) : (
                <div className="sippy-card rounded-[20px] p-3.5 space-y-2.5">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Name (e.g. Bottle)"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      className="flex-1 h-10 px-3 rounded-xl bg-[var(--card-tint)] text-sm text-[var(--ink-900)]"
                    />
                    <input
                      type="number"
                      min={50}
                      max={1500}
                      step={25}
                      value={customMl}
                      onChange={(e) => setCustomMl(Number(e.target.value))}
                      className="w-24 h-10 px-3 rounded-xl bg-[var(--card-tint)] text-sm font-bold text-[var(--ink-900)] sippy-num"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setShowCustomAdder(false)}
                      className="flex-1 h-10 rounded-xl bg-[var(--card-tint)] text-xs font-bold text-[var(--ink-700)] cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleAddCustomGlass}
                      className="flex-1 h-10 rounded-xl bg-[var(--brand-500)] text-xs font-bold text-white sippy-press-brand cursor-pointer"
                    >
                      Add glass
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* Step 6: Reminders & Finish */}
          {onboardingStep === 6 && (
            <motion.div
              key="step-tone"
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-4"
            >
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h1 className="text-[28px] leading-[34px] font-extrabold tracking-[-0.02em] text-[var(--ink-900)]">
                    Turn on your
                    <br />
                    {activePersona.title} nudges
                  </h1>
                  <p className="mt-1 text-[14px] text-[var(--ink-500)]">
                    Ready for <span className="font-bold text-[var(--ink-900)] sippy-num">{activeGoalMl.toLocaleString()} ml</span> a day.
                  </p>
                </div>
                <Mascot mood={activePersona.mood} persona={tone} size={84} />
              </div>

              <div className="grid grid-cols-3 gap-2">
                {(['gentle', 'playful', 'coach'] as NotificationTone[]).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTone(t)}
                    className={`h-11 rounded-[16px] text-sm font-bold capitalize cursor-pointer ${
                      tone === t
                        ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                        : 'bg-[var(--card-tint)] text-[var(--ink-700)] sippy-press-tint'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>

              {/* Notification Preview */}
              <div className="sippy-card rounded-[24px] p-4 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-[14px] bg-[var(--brand-500)] flex items-center justify-center shrink-0 overflow-hidden">
                  <Mascot mood="thirsty" persona={tone} size={44} hideShadow />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] font-semibold text-[var(--ink-500)]">Sippy · now</p>
                  <p className="text-[16px] font-extrabold text-[var(--ink-900)]">
                    {activePersona.sampleTitle}
                  </p>
                  <p className="text-[13px] text-[var(--ink-500)] leading-snug">
                    {activePersona.sampleBody}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => void handleTurnOnReminders()}
                className="w-full h-12 rounded-[18px] bg-[var(--brand-500)] text-white font-bold text-sm flex items-center justify-center gap-2 sippy-press-brand cursor-pointer"
              >
                <Bell size={18} />
                <span>Turn on reminders</span>
              </button>

              {pushStatus && (
                <p className="text-xs text-center font-semibold text-[var(--brand-600)]">
                  {pushStatus}
                </p>
              )}

              {isIOS && !isInstalled && (
                <div className="rounded-[16px] bg-[var(--brand-50)] p-3.5 text-xs text-[var(--ink-700)] space-y-1">
                  <p className="font-bold text-[var(--ink-900)]">Using iPhone Safari?</p>
                  <p className="flex items-center gap-1">
                    1. Tap <Share size={13} className="text-[var(--brand-600)]" /> Share in Safari toolbar.
                  </p>
                  <p>2. Choose Add to Home Screen, then open Sippy for push alerts.</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer CTA */}
      <div className="pt-3 pb-safe">
        {onboardingStep === 2 ? (
          <button
            type="button"
            onClick={handleContinueFromName}
            className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
          >
            <span>Continue</span>
          </button>
        ) : onboardingStep === 4 ? (
          <button
            type="button"
            onClick={handleContinueFromGoal}
            className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
          >
            <span className="sippy-num">
              {goalMode === 'calculator'
                ? `Use ${calcResult.goalMl.toLocaleString()} ml & continue`
                : 'Continue'}
            </span>
          </button>
        ) : onboardingStep < 6 ? (
          <button
            type="button"
            onClick={() => setOnboardingStep(onboardingStep + 1)}
            className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
          >
            <span>Continue</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => void handleComplete()}
            className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
          >
            <Sparkles size={18} />
            <span>Start sipping</span>
          </button>
        )}
      </div>

      <span className="sr-only">Goal equals {totalGlasses10} glasses of 250 ml</span>
    </div>
  );
};
