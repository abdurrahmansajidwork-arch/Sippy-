import React, { useState } from 'react';
import { Download, Share, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Mascot } from './Mascot';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) return null;

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void install()}
        className={
          compact
            ? 'inline-flex items-center gap-1.5 min-h-[44px] px-3.5 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-semibold whitespace-nowrap active:scale-[0.97] transition-transform'
            : 'w-full min-h-[48px] px-4 py-3 rounded-[20px] bg-[var(--brand-500)] text-white font-semibold text-sm flex items-center justify-center gap-2 active:scale-[0.97] transition-transform'
        }
      >
        <Download size={16} />
        <span>Install Sippy App</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className={
            compact
              ? 'inline-flex items-center gap-1.5 min-h-[44px] px-3.5 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-semibold whitespace-nowrap'
              : 'w-full min-h-[48px] px-4 py-3 rounded-[20px] bg-[var(--card-tint)] text-[var(--ink-900)] font-semibold text-sm flex items-center justify-center gap-2'
          }
        >
          <PlusSquare size={16} />
          <span>Add to Home Screen (iOS)</span>
        </button>

        {showIOSGuide && (
          <div
            className="fixed inset-0 z-50 bg-black/45 backdrop-blur-xs flex items-end sm:items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="ios-install-title"
          >
            <div className="w-full max-w-[420px] rounded-[28px] bg-[var(--card)] p-6 shadow-2xl">
              <div className="flex items-start justify-between">
                <Mascot mood="waving" size={64} />
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  aria-label="Close install guide"
                  className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-[var(--ink-500)] hover:bg-[var(--card-tint)]"
                >
                  <X size={20} />
                </button>
              </div>
              <h3 id="ios-install-title" className="mt-2 text-xl font-bold text-[var(--ink-900)]">
                Install Sippy on iPhone
              </h3>
              <p className="mt-1 text-sm text-[var(--ink-500)]">
                iOS Safari requires adding Sippy to your Home Screen before push reminders can arrive.
              </p>
              <ol className="mt-4 space-y-3 text-sm text-[var(--ink-700)]">
                <li className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-full bg-[var(--brand-100)] text-[var(--brand-600)] font-bold flex items-center justify-center shrink-0">1</span>
                  <span className="flex items-center gap-1.5">Tap the <Share size={15} className="text-[var(--brand-600)]" /> <strong>Share</strong> button in Safari.</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-full bg-[var(--brand-100)] text-[var(--brand-600)] font-bold flex items-center justify-center shrink-0">2</span>
                  <span>Scroll down and choose <strong>Add to Home Screen</strong>.</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-full bg-[var(--brand-100)] text-[var(--brand-600)] font-bold flex items-center justify-center shrink-0">3</span>
                  <span>Open Sippy from your Home Screen and tap <strong>Turn on reminders</strong>.</span>
                </li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-6 w-full h-12 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-semibold text-sm"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
