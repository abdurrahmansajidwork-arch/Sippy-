import React, { useId } from 'react';
import type { GlassSkin } from '../types';

interface GlassFillProps {
  level: number; // 0 to 1+
  skin?: GlassSkin;
  isLogging?: boolean;
  goalHit?: boolean;
  size?: number;
  showPercentInside?: boolean;
}

export const GlassFill: React.FC<GlassFillProps> = ({
  level,
  skin = 'classic',
  isLogging = false,
  goalHit = false,
  size = 136,
  showPercentInside = true,
}) => {
  const uid = useId().replace(/:/g, '');
  const clamped = Math.max(0, Math.min(1, level));
  const pct = Math.round(clamped * 100);

  // Liquid sits inside y=28..136 in viewBox 0..120 x 0..150
  const fillTopY = goalHit ? 25 : 136 - clamped * 104;
  const clipId = `glass-clip-${uid}`;
  const liqId = `glass-liq-${uid}`;

  const renderContainerMask = () => {
    if (skin === 'mason') {
      return (
        <path d="M30 34C30 28 34 26 38 26H82C86 26 90 28 90 34V126C90 135 83 140 74 140H46C37 140 30 135 30 126V34Z" />
      );
    }
    if (skin === 'sports') {
      return (
        <path d="M38 38C32 42 30 48 30 56V128C30 136 36 140 44 140H76C84 140 90 136 90 128V56C90 48 88 42 82 38L78 28H42L38 38Z" />
      );
    }
    if (skin === 'boba') {
      return (
        <path d="M30 38H90L82 130C81 136 76 140 70 140H50C44 140 39 136 38 130L30 38Z" />
      );
    }
    // Classic tapered tumbler matching PDF Page 3
    return (
      <path d="M27 28H93L84 130C83 136 78 140 72 140H48C42 140 37 136 36 130L27 28Z" />
    );
  };

  return (
    <div
      className="relative flex items-center justify-center"
      style={{ width: size, height: size * 1.15 }}
    >
      <svg
        viewBox="0 0 120 150"
        className="w-full h-full overflow-visible select-none"
        aria-label={`Water glass ${pct}% full`}
        role="img"
      >
        <defs>
          <clipPath id={clipId}>{renderContainerMask()}</clipPath>
          <linearGradient id={liqId} x1="60" y1="26" x2="60" y2="140" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#6FD3FF" />
            <stop offset="100%" stopColor="#3D6EF5" />
          </linearGradient>
        </defs>

        {/* Grounded contact shadow */}
        <ellipse cx="60" cy="145" rx="28" ry="4.5" fill="#0B1633" fillOpacity="0.07" />

        {/* Skin toppers */}
        {skin === 'boba' && (
          <>
            <path d="M68 6L61 42" stroke="#3D6EF5" strokeWidth="6" strokeLinecap="round" />
            <path d="M28 38C28 20 92 20 92 38H28Z" fill="#EEF3FF" stroke="#DCE6FE" strokeWidth="2.5" />
          </>
        )}
        {skin === 'sports' && (
          <rect x="44" y="16" width="32" height="14" rx="5" fill="#3D6EF5" />
        )}
        {skin === 'mason' && (
          <g fill="#EEF3FF" stroke="#DCE6FE" strokeWidth="2">
            <rect x="33" y="18" width="54" height="7" rx="3.5" />
            <rect x="31" y="25" width="58" height="5" rx="2.5" />
          </g>
        )}

        {/* Glass shell */}
        <g fill="var(--brand-50)" stroke="var(--brand-100)" strokeWidth="3.2" strokeLinejoin="round">
          {renderContainerMask()}
        </g>

        {/* Animated Liquid inside clipped container — fluid sloshes & ripples without stretching the glass */}
        <g clipPath={`url(#${clipId})`}>
          <g
            style={{
              transform: `translateY(${fillTopY}px)`,
              transition: 'transform 1100ms cubic-bezier(0.22, 1, 0.36, 1)',
            }}
          >
            <g className={isLogging ? 'anim-slosh' : undefined}>
              {/* Back wave */}
              <path
                className="anim-wave-b"
                d="M0 4 Q 15 -1, 30 4 T 60 4 T 90 4 T 120 4 T 150 4 T 180 4 T 210 4 T 240 4 V 148 H -20 Z"
                fill="#6FD3FF"
                fillOpacity="0.72"
              />
              {/* Front wave */}
              <path
                className="anim-wave-a"
                d="M0 6 Q 15 10.5, 30 6 T 60 6 T 90 6 T 120 6 T 150 6 T 180 6 T 210 6 T 240 6 V 148 H -20 Z"
                fill={`url(#${liqId})`}
              />

              {/* Surface impact ripple on drink log */}
              {isLogging && (
                <ellipse
                  cx="60"
                  cy="7"
                  rx="18"
                  ry="3.2"
                  fill="none"
                  stroke="#FFFFFF"
                  strokeWidth="1.8"
                  className="anim-ripple"
                />
              )}

              {/* Rising micro-bubbles */}
              {clamped > 0.06 && (
                <g fill="#FFFFFF" fillOpacity="0.52">
                  <circle className="anim-bubble" cx="46" cy="48" r="2.4" style={{ animationDelay: '0s' }} />
                  <circle className="anim-bubble" cx="62" cy="64" r="3" style={{ animationDelay: '0.8s' }} />
                  <circle className="anim-bubble" cx="74" cy="54" r="2" style={{ animationDelay: '1.5s' }} />
                  {isLogging && (
                    <>
                      <circle className="anim-bubble" cx="53" cy="68" r="2.2" style={{ animationDelay: '0.1s' }} />
                      <circle className="anim-bubble" cx="68" cy="72" r="2.8" style={{ animationDelay: '0.35s' }} />
                    </>
                  )}
                </g>
              )}
            </g>
          </g>
        </g>

        {/* Glass crisp outline & vertical specular reflection */}
        <g fill="none" stroke="var(--brand-100)" strokeWidth="3" strokeLinejoin="round">
          {renderContainerMask()}
        </g>
        <path
          d="M36 42L41 124"
          stroke="#FFFFFF"
          strokeWidth="4.2"
          strokeOpacity="0.58"
          strokeLinecap="round"
        />

        {/* Falling droplet on log */}
        {isLogging && (
          <path
            className="anim-drop-fall"
            d="M60 4C60 4 54.5 11.5 54.5 16.5C54.5 19.6 57 22 60 22C63 22 65.5 19.6 65.5 16.5C65.5 11.5 60 4 60 4Z"
            fill="#19B4F2"
          />
        )}

        {showPercentInside && (
          <text
            x="60"
            y={Math.max(48, Math.min(126, fillTopY + 18))}
            textAnchor="middle"
            fill={clamped >= 0.35 ? '#FFFFFF' : '#0B1633'}
            fontSize="13"
            fontWeight="800"
            className="sippy-num"
            style={{ transition: 'all 1100ms cubic-bezier(0.22, 1, 0.36, 1)' }}
          >
            {pct}%
          </text>
        )}
      </svg>
    </div>
  );
};
