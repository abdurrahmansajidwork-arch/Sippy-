import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AlertTriangle, Clock, Minus, Plus, Share2, Trash2, X } from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import type { DrinkType, FeelingLevel, HydrationLog, ReminderSlot } from '../types';
import { evaluateIntakeSafety } from '../utils/intakeGuard';
import { DRINK_FACTORS, DRINK_LABELS, formatVolume } from '../utils/patternEngine';
import { formatTimeShort, toDateKey } from '../utils/scheduleEngine';
import { generateShareCardBlob } from '../utils/shareCard';
import { DrinkGlyph, DropletLogoIcon, SmallGlassGauge, StreakFlame, TokenCoinIcon } from './BrandIcons';
import { Mascot } from './Mascot';

const DRINK_TYPES: DrinkType[] = ['water', 'tea', 'coffee', 'juice', 'sparkling', 'milk'];

const SIZE_TILES = [
  { ml: 150, fill: 0.42, bg: 'var(--tile-mint)', edge: 'var(--edge-mint-tile)', variant: 'tumbler' as const },
  { ml: 250, fill: 0.65, bg: 'var(--tile-lav)', edge: 'var(--edge-lav)', variant: 'tumbler' as const },
  { ml: 300, fill: 0.78, bg: 'var(--tile-flame)', edge: 'var(--edge-flame)', variant: 'tumbler' as const },
  { ml: 500, fill: 0.9, bg: 'var(--tile-water)', edge: 'var(--edge-water)', variant: 'bottle' as const },
];

/* Reusable Warning Badge */
export const OverGoalWarningBadge: React.FC<{
  excessMl: number;
  unit?: 'ml' | 'oz';
  className?: string;
}> = ({ excessMl, unit = 'ml', className = '' }) => {
  const fmt = formatVolume(excessMl, unit);
  return (
    <div
      role="status"
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] bg-[var(--amber-100)] text-[#92400E] dark:text-[#FCD34D] text-xs font-extrabold ${className}`}
    >
      <AlertTriangle size={14} className="text-[#D97706] shrink-0" />
      <span className="tabular-nums">
        Well over goal (+{fmt.value} {fmt.unitLabel}) · Pace gently
      </span>
    </div>
  );
};

/* Reusable Confirmation Dialog */
export const DeleteConfirmDialog: React.FC<{
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'primary';
  icon?: React.ReactNode;
  onCancel: () => void;
  onConfirm: () => void;
}> = ({
  open,
  title,
  description,
  confirmLabel = 'Delete',
  cancelLabel = 'Keep',
  variant = 'danger',
  icon,
  onCancel,
  onConfirm,
}) => {
  const isPrimary = variant === 'primary';
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          className="fixed inset-0 z-[60] bg-[#0B1633]/65 backdrop-blur-xs flex items-center justify-center px-5"
          onClick={onCancel}
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="delete-confirm-title"
          aria-describedby="delete-confirm-desc"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 8 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[380px] rounded-[28px] bg-[var(--card)] p-6 shadow-2xl text-center"
          >
            <div
              className={`mx-auto w-12 h-12 rounded-2xl flex items-center justify-center ${
                isPrimary
                  ? 'bg-[var(--brand-50)] text-[var(--brand-600)]'
                  : 'bg-[var(--coral-100)] text-[var(--coral-500)]'
              }`}
            >
              {icon ?? <Trash2 size={22} />}
            </div>
            <h2 id="delete-confirm-title" className="mt-3 text-[20px] font-extrabold text-[var(--ink-900)]">
              {title}
            </h2>
            <p id="delete-confirm-desc" className="mt-1.5 text-[14px] text-[var(--ink-500)]">
              {description}
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={onCancel}
                className="h-12 rounded-[16px] bg-[var(--card-tint)] text-[var(--ink-700)] font-bold text-sm sippy-press-tint cursor-pointer"
              >
                {cancelLabel}
              </button>
              <button
                type="button"
                onClick={onConfirm}
                className={`h-12 rounded-[16px] text-white font-bold text-sm cursor-pointer ${
                  isPrimary
                    ? 'bg-[var(--brand-500)] sippy-press-brand'
                    : 'bg-[var(--coral-500)] sippy-press-coral'
                }`}
              >
                {confirmLabel}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* Near-Max / Over-Goal Drink Confirmation Modal */
export const ConfirmDrinkModal: React.FC = () => {
  const {
    pendingDrinkRequest,
    confirmPendingDrink,
    cancelPendingDrink,
    todayTotalMl,
    effectiveGoalMl,
    profile,
  } = useSippy();

  if (!profile) return null;

  return (
    <AnimatePresence>
      {pendingDrinkRequest && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          className="fixed inset-0 z-[60] bg-[#0B1633]/65 backdrop-blur-xs flex items-center justify-center px-5"
          onClick={cancelPendingDrink}
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="confirm-drink-title"
          aria-describedby="confirm-drink-desc"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 8 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[400px] rounded-[28px] bg-[var(--card)] p-6 shadow-2xl text-center"
          >
            <div className="flex justify-center">
              <Mascot
                mood={pendingDrinkRequest.safety.breaksTooMuch ? 'worried' : 'proud'}
                persona={profile.tone}
                size={88}
              />
            </div>

            {pendingDrinkRequest.safety.breaksTooMuch && (
              <div className="mt-2 flex justify-center">
                <OverGoalWarningBadge
                  excessMl={pendingDrinkRequest.safety.excessOverGoalMl}
                  unit={profile.unit}
                />
              </div>
            )}

            <h2
              id="confirm-drink-title"
              className="mt-3 text-[22px] font-extrabold text-[var(--ink-900)]"
            >
              {pendingDrinkRequest.safety.breaksTooMuch
                ? 'That breaks way past your goal'
                : pendingDrinkRequest.safety.reason === 'over_goal'
                  ? 'You’re right at your max goal'
                  : 'Almost at your daily goal!'}
            </h2>

            <p id="confirm-drink-desc" className="mt-1.5 text-[14px] text-[var(--ink-500)] tabular-nums">
              {pendingDrinkRequest.safety.breaksTooMuch
                ? `Adding ${pendingDrinkRequest.ml} ml brings today to ${pendingDrinkRequest.safety.projectedTotalMl.toLocaleString()} ml (goal ${effectiveGoalMl.toLocaleString()} ml). Are you sure?`
                : `Adding ${pendingDrinkRequest.ml} ml ${DRINK_LABELS[pendingDrinkRequest.drinkType].toLowerCase()} brings you from ${todayTotalMl.toLocaleString()} to ${pendingDrinkRequest.safety.projectedTotalMl.toLocaleString()} ml of your ${effectiveGoalMl.toLocaleString()} ml goal.`}
            </p>

            <div className="mt-5 grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={cancelPendingDrink}
                className="h-12 rounded-[16px] bg-[var(--card-tint)] text-[var(--ink-700)] font-bold text-sm sippy-press-tint cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void confirmPendingDrink()}
                className="h-12 rounded-[16px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-sm flex items-center justify-center gap-1.5 sippy-press-ink cursor-pointer"
              >
                <DropletLogoIcon size={16} />
                <span>Log {pendingDrinkRequest.ml} ml</span>
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* Log Sheet — Redesign Pass 2, Page 4 */
export const LogSheet: React.FC = () => {
  const {
    logSheetOpen,
    setLogSheetOpen,
    requestLogDrink,
    profile,
    todayTotalMl,
    effectiveGoalMl,
  } = useSippy();

  const [selectedSize, setSelectedSize] = useState<number>(250);
  const [drinkType, setDrinkType] = useState<DrinkType>('water');
  const [showCustom, setShowCustom] = useState(false);
  const [customMl, setCustomMl] = useState(350);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [drankEarlierTime, setDrankEarlierTime] = useState('');

  if (!profile) return null;

  const activeMl = showCustom ? customMl : selectedSize;
  const safety = evaluateIntakeSafety(todayTotalMl, activeMl, effectiveGoalMl, drinkType);
  const projectedPct = Math.round((safety.projectedTotalMl / Math.max(1, effectiveGoalMl)) * 100);
  const currentFmt = formatVolume(todayTotalMl, profile.unit);
  const projectedFmt = formatVolume(safety.projectedTotalMl, profile.unit);
  const activeFmt = formatVolume(activeMl, profile.unit);

  const computeTimestamp = () => {
    if (!drankEarlierTime) return Date.now();
    const [hh, mm] = drankEarlierTime.split(':').map(Number);
    const d = new Date();
    d.setHours(hh || 0, mm || 0, 0, 0);
    return Math.min(Date.now(), d.getTime());
  };

  const displayTime = drankEarlierTime
    ? formatTimeShort(computeTimestamp())
    : `Now · ${formatTimeShort(Date.now())}`;

  const handleConfirmLog = async () => {
    setLogSheetOpen(false);
    await requestLogDrink({
      ml: activeMl,
      drinkType,
      ts: computeTimestamp(),
      source: 'app',
    });
    setDrankEarlierTime('');
    setShowTimePicker(false);
  };

  return (
    <AnimatePresence>
      {logSheetOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 bg-[#0B1633]/65 backdrop-blur-xs flex items-end justify-center"
          onClick={() => setLogSheetOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Log a drink"
        >
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 360, damping: 32 }}
            className="relative w-full max-w-[480px] rounded-t-[28px] bg-[var(--card)] px-5 pt-4 pb-6 pb-safe shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Cheering Sippy peeking over top edge (Design Pass 2 Page 4) */}
            <div className="pointer-events-none absolute left-1/2 -translate-x-1/2 -top-[68px] z-10">
              <Mascot mood="hyped" persona={profile.tone} size={102} hideShadow />
            </div>

            <div className="w-10 h-1.5 rounded-full bg-[var(--line)] mx-auto mb-3" />

            <div className="text-center">
              <h2 className="text-[24px] font-extrabold text-[var(--ink-900)]">Log a drink</h2>
              <p className="mt-0.5 text-[14px] font-semibold text-[var(--ink-500)] tabular-nums">
                {currentFmt.value} → {projectedFmt.value} {projectedFmt.unitLabel} · {projectedPct}% of today
              </p>
              {safety.breaksTooMuch && (
                <div className="mt-2 flex justify-center">
                  <OverGoalWarningBadge excessMl={safety.excessOverGoalMl} unit={profile.unit} />
                </div>
              )}
            </div>

            {/* SIZE tiles */}
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
                  SIZE
                </span>
                <button
                  type="button"
                  onClick={() => setShowCustom((v) => !v)}
                  className="text-xs font-bold text-[var(--brand-600)] min-h-[32px] px-2 cursor-pointer"
                >
                  {showCustom ? 'Use presets' : '+ Custom size'}
                </button>
              </div>

              {!showCustom ? (
                <div className="grid grid-cols-4 gap-2.5">
                  {SIZE_TILES.map((tile) => {
                    const selected = selectedSize === tile.ml;
                    const fmt = formatVolume(tile.ml, profile.unit);
                    return (
                      <button
                        key={tile.ml}
                        type="button"
                        onClick={() => setSelectedSize(tile.ml)}
                        className={`h-[104px] rounded-[20px] px-2 py-3 flex flex-col items-center justify-between transition-transform active:translate-y-[2px] active:scale-[0.97] cursor-pointer ${
                          selected ? 'ring-[3px] ring-[var(--brand-500)]' : ''
                        }`}
                        style={{
                          backgroundColor: tile.bg,
                          boxShadow: `0 4px 0 ${tile.edge}`,
                        }}
                      >
                        <SmallGlassGauge fillLevel={tile.fill} size={26} variant={tile.variant} />
                        <span className="text-[14px] font-extrabold text-[var(--ink-900)] tabular-nums">
                          {fmt.value} <span className="text-[12px] font-semibold text-[var(--ink-500)]">{fmt.unitLabel}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="rounded-[20px] bg-[var(--card-tint)] p-3.5 flex items-center justify-between gap-3">
                  <button
                    type="button"
                    aria-label="Decrease custom amount"
                    onClick={() => setCustomMl((v) => Math.max(50, v - 25))}
                    className="w-12 h-12 rounded-full bg-white text-[var(--brand-600)] flex items-center justify-center sippy-press-white cursor-pointer"
                  >
                    <Minus size={18} strokeWidth={2.5} />
                  </button>
                  <div className="text-center">
                    <span className="text-[28px] font-extrabold text-[var(--ink-900)] tabular-nums">
                      {customMl}
                    </span>
                    <span className="ml-1 text-sm font-semibold text-[var(--ink-500)]">ml</span>
                  </div>
                  <button
                    type="button"
                    aria-label="Increase custom amount"
                    onClick={() => setCustomMl((v) => Math.min(1500, v + 25))}
                    className="w-12 h-12 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center sippy-press-brand cursor-pointer"
                  >
                    <Plus size={18} strokeWidth={2.5} />
                  </button>
                </div>
              )}
            </div>

            {/* DRINK chips */}
            <div className="mt-4">
              <span className="block text-[12px] font-bold uppercase tracking-[0.08em] text-[var(--ink-500)] mb-2">
                DRINK
              </span>
              <div className="flex flex-wrap gap-2">
                {DRINK_TYPES.map((dt) => {
                  const active = drinkType === dt;
                  return (
                    <button
                      key={dt}
                      type="button"
                      onClick={() => setDrinkType(dt)}
                      className={`h-11 px-4 rounded-[16px] text-[15px] font-bold cursor-pointer ${
                        active
                          ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                          : 'bg-[var(--card-tint)] text-[var(--ink-700)] sippy-press-tint'
                      }`}
                    >
                      {DRINK_LABELS[dt]}
                    </button>
                  );
                })}
              </div>
              {drinkType !== 'water' && drinkType !== 'sparkling' && (
                <p className="mt-1.5 text-xs font-medium text-[var(--ink-500)]">
                  Counts as ~{Math.round(DRINK_FACTORS[drinkType] * 100)}% hydration ({safety.countedAddMl} ml counted).
                </p>
              )}
            </div>

            {/* Time row */}
            <div className="mt-4 rounded-[16px] bg-[var(--card-tint)] px-4 py-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-[14px] font-bold text-[var(--ink-900)] tabular-nums">
                <Clock size={16} className="text-[var(--ink-500)]" />
                <span>{displayTime}</span>
              </div>
              {!showTimePicker ? (
                <button
                  type="button"
                  onClick={() => setShowTimePicker(true)}
                  className="text-[14px] font-bold text-[var(--brand-600)] min-h-[32px] px-2 cursor-pointer"
                >
                  Change
                </button>
              ) : (
                <input
                  type="time"
                  aria-label="Log time"
                  value={drankEarlierTime}
                  onChange={(e) => setDrankEarlierTime(e.target.value)}
                  className="bg-transparent text-sm font-bold text-[var(--brand-600)] tabular-nums"
                />
              )}
            </div>

            {/* Navy Main CTA */}
            <button
              type="button"
              onClick={() => void handleConfirmLog()}
              className="mt-4 w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
            >
              <DropletLogoIcon size={19} />
              <span className="tabular-nums">
                Log {activeFmt.value} {activeFmt.unitLabel}
              </span>
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* Edit Log Sheet with Delete Confirmation */
export const EditLogSheet: React.FC<{
  log: HydrationLog | null;
  onClose: () => void;
}> = ({ log, onClose }) => {
  const { editLog, deleteLog } = useSippy();
  const [ml, setMl] = useState(log?.ml ?? 250);
  const [drinkType, setDrinkType] = useState<DrinkType>(log?.drinkType ?? 'water');
  const [timeStr, setTimeStr] = useState('12:00');
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  useEffect(() => {
    if (log) {
      setMl(log.ml);
      setDrinkType(log.drinkType);
      const d = new Date(log.ts);
      setTimeStr(`${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`);
      setConfirmDeleteOpen(false);
    }
  }, [log]);

  if (!log) return null;

  const handleSave = async () => {
    const [hh, mm] = timeStr.split(':').map(Number);
    const d = new Date(log.ts);
    d.setHours(hh || 0, mm || 0, 0, 0);
    await editLog(log.id, { ml, ts: d.getTime(), drinkType });
    onClose();
  };

  const handleConfirmedDelete = async () => {
    setConfirmDeleteOpen(false);
    await deleteLog(log.id);
    onClose();
  };

  return (
    <>
      <div
        className="fixed inset-0 z-50 bg-[#0B1633]/60 backdrop-blur-xs flex items-end justify-center"
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-label="Edit drink log"
      >
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', stiffness: 360, damping: 32 }}
          className="w-full max-w-[480px] rounded-t-[28px] bg-[var(--card)] px-5 pt-3 pb-6 pb-safe shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-10 h-1.5 rounded-full bg-[var(--line)] mx-auto mb-3" />
          <div className="flex items-center justify-between">
            <h2 className="text-[22px] font-extrabold text-[var(--ink-900)]">Edit drink</h2>
            <button
              type="button"
              onClick={() => setConfirmDeleteOpen(true)}
              aria-label="Delete log"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-[var(--coral-500)] hover:bg-[var(--coral-100)] cursor-pointer"
            >
              <Trash2 size={20} />
            </button>
          </div>

          <div className="mt-4 flex items-center justify-center gap-4">
            <button
              type="button"
              aria-label="Decrease log amount"
              onClick={() => setMl((v) => Math.max(50, v - 50))}
              className="w-12 h-12 rounded-full bg-white text-[var(--brand-600)] flex items-center justify-center sippy-press-white cursor-pointer"
            >
              <Minus size={18} strokeWidth={2.5} />
            </button>
            <span className="text-3xl font-extrabold text-[var(--ink-900)] tabular-nums min-w-[110px] text-center">
              {ml} ml
            </span>
            <button
              type="button"
              aria-label="Increase log amount"
              onClick={() => setMl((v) => Math.min(3000, v + 50))}
              className="w-12 h-12 rounded-full bg-[var(--brand-500)] text-white flex items-center justify-center sippy-press-brand cursor-pointer"
            >
              <Plus size={18} strokeWidth={2.5} />
            </button>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {DRINK_TYPES.map((dt) => (
              <button
                key={dt}
                type="button"
                onClick={() => setDrinkType(dt)}
                className={`h-10 px-4 rounded-[16px] text-sm font-bold cursor-pointer ${
                  drinkType === dt
                    ? 'bg-[var(--brand-500)] text-white sippy-press-brand'
                    : 'bg-[var(--card-tint)] text-[var(--ink-700)] sippy-press-tint'
                }`}
              >
                {DRINK_LABELS[dt]}
              </button>
            ))}
          </div>

          <label className="mt-4 flex items-center justify-between rounded-[16px] bg-[var(--card-tint)] px-4 py-3">
            <span className="text-sm font-semibold text-[var(--ink-700)]">Time logged</span>
            <input
              type="time"
              value={timeStr}
              onChange={(e) => setTimeStr(e.target.value)}
              className="bg-transparent text-sm font-bold text-[var(--ink-900)] tabular-nums"
            />
          </label>

          <button
            type="button"
            onClick={() => void handleSave()}
            className="mt-5 w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] sippy-press-ink cursor-pointer"
          >
            Save changes
          </button>
        </motion.div>
      </div>

      <DeleteConfirmDialog
        open={confirmDeleteOpen}
        title={`Delete ${log.ml} ml ${DRINK_LABELS[log.drinkType]}?`}
        description="This removes the drink from today’s hydration total and recalculates your remaining plan."
        confirmLabel="Delete drink"
        onCancel={() => setConfirmDeleteOpen(false)}
        onConfirm={() => void handleConfirmedDelete()}
      />
    </>
  );
};

/* Slot Detail Sheet */
export const SlotDetailSheet: React.FC<{
  slot: ReminderSlot | null;
  onClose: () => void;
}> = ({ slot, onClose }) => {
  const { requestLogDrink, skipSlot, editSlotTime } = useSippy();
  const [timeStr, setTimeStr] = useState('12:00');

  useEffect(() => {
    if (slot) {
      const d = new Date(slot.notifyAt);
      setTimeStr(`${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`);
    }
  }, [slot]);

  if (!slot) return null;

  const handleSaveTime = async () => {
    const [hh, mm] = timeStr.split(':').map(Number);
    const d = new Date(slot.notifyAt);
    d.setHours(hh || 0, mm || 0, 0, 0);
    await editSlotTime(slot.id, d.getTime());
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#0B1633]/60 backdrop-blur-xs flex items-end justify-center"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Reminder slot details"
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', stiffness: 360, damping: 32 }}
        className="w-full max-w-[480px] rounded-t-[28px] bg-[var(--card)] px-5 pt-3 pb-6 pb-safe shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1.5 rounded-full bg-[var(--line)] mx-auto mb-3" />
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.08em] text-[var(--ink-500)]">
              {formatTimeShort(slot.notifyAt)}
            </p>
            <h2 className="text-[22px] font-extrabold text-[var(--ink-900)] tabular-nums">
              {slot.targetMl} ml sip
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close slot sheet"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-[var(--ink-500)] cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        <label className="mt-4 flex items-center justify-between rounded-[16px] bg-[var(--card-tint)] px-4 py-3">
          <span className="text-sm font-semibold text-[var(--ink-700)]">Move reminder time</span>
          <input
            type="time"
            value={timeStr}
            onChange={(e) => setTimeStr(e.target.value)}
            className="bg-transparent text-sm font-bold text-[var(--ink-900)] tabular-nums"
          />
        </label>

        <div className="mt-5 space-y-2.5">
          {slot.status === 'pending' && (
            <button
              type="button"
              onClick={async () => {
                onClose();
                await requestLogDrink({ ml: slot.targetMl, drinkType: 'water', source: 'app' });
              }}
              className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
            >
              <DropletLogoIcon size={18} />
              <span>Log {slot.targetMl} ml now</span>
            </button>
          )}
          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => void handleSaveTime()}
              className="h-12 rounded-[16px] bg-[var(--brand-500)] text-white font-bold text-sm sippy-press-brand cursor-pointer"
            >
              Save time
            </button>
            {slot.status === 'pending' && (
              <button
                type="button"
                onClick={async () => {
                  await skipSlot(slot.id);
                  onClose();
                }}
                className="h-12 rounded-[16px] bg-[var(--card-tint)] text-[var(--brand-600)] font-bold text-sm sippy-press-tint cursor-pointer"
              >
                Skip & shift plan
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

/* Feeling Check-in Sheet */
export const FeelingSheet: React.FC = () => {
  const { feelingSheetOpen, setFeelingSheetOpen, submitFeeling, profile } = useSippy();

  const options: { level: FeelingLevel; label: string; mood: 'thirsty' | 'happy' | 'hyped' | 'proud' }[] = [
    { level: 'drained', label: 'Drained', mood: 'thirsty' },
    { level: 'okay', label: 'Okay', mood: 'happy' },
    { level: 'good', label: 'Good', mood: 'proud' },
    { level: 'great', label: 'Great', mood: 'hyped' },
  ];

  return (
    <AnimatePresence>
      {feelingSheetOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-[#0B1633]/60 backdrop-blur-xs flex items-end justify-center"
          onClick={() => setFeelingSheetOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Feeling check-in"
        >
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 360, damping: 32 }}
            className="w-full max-w-[480px] rounded-t-[28px] bg-[var(--card)] px-5 pt-3 pb-6 pb-safe shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1.5 rounded-full bg-[var(--line)] mx-auto mb-3" />
            <div className="flex items-center justify-between">
              <h2 className="text-[22px] font-extrabold text-[var(--ink-900)]">How are you feeling?</h2>
              <button
                type="button"
                onClick={() => setFeelingSheetOpen(false)}
                className="min-h-[44px] px-3 text-sm font-bold text-[var(--brand-600)] cursor-pointer"
              >
                Skip
              </button>
            </div>
            <p className="mt-1 text-sm text-[var(--ink-500)]">
              After 10 check-ins, Sippy compares your energy with your hydration.
            </p>

            <div className="mt-4 grid grid-cols-4 gap-2">
              {options.map((o) => (
                <button
                  key={o.level}
                  type="button"
                  onClick={() => void submitFeeling(o.level)}
                  className="rounded-[20px] bg-[var(--lav-100)] p-3 flex flex-col items-center gap-1.5 sippy-press-tint cursor-pointer"
                  style={{ boxShadow: '0 4px 0 var(--edge-lav)' }}
                >
                  <Mascot mood={o.mood} persona={profile?.tone} size={50} />
                  <span className="text-xs font-bold text-[var(--ink-900)]">{o.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* Goal Hit Celebration Sheet */
export const GoalHitSheet: React.FC = () => {
  const {
    goalHitSheetOpen,
    setGoalHitSheetOpen,
    todayTotalMl,
    effectiveGoalMl,
    currentStreak,
    lastGoalTokensEarned,
    profile,
  } = useSippy();
  const [sharing, setSharing] = useState(false);

  if (!profile) return null;

  const handleShare = async () => {
    setSharing(true);
    try {
      const blob = await generateShareCardBlob({
        totalMl: todayTotalMl,
        goalMl: effectiveGoalMl,
        streak: Math.max(1, currentStreak),
        unit: profile.unit,
        dateLabel: toDateKey(Date.now()),
      });
      const file = new File([blob], `sippy-${toDateKey(Date.now())}.png`, { type: 'image/png' });
      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          title: 'Sippy Daily Goal Reached',
          files: [file],
        });
      } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sippy-${toDateKey(Date.now())}.png`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } finally {
      setSharing(false);
    }
  };

  return (
    <AnimatePresence>
      {goalHitSheetOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-[#0B1633]/65 backdrop-blur-xs flex items-end justify-center"
          onClick={() => setGoalHitSheetOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Daily goal reached"
        >
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 360, damping: 32 }}
            className="w-full max-w-[480px] rounded-t-[28px] bg-[var(--card)] px-5 pt-3 pb-7 pb-safe shadow-2xl text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1.5 rounded-full bg-[var(--line)] mx-auto mb-3" />
            <div className="flex justify-center">
              <Mascot mood="hyped" persona={profile.tone} size={114} />
            </div>
            <div className="mt-2 flex items-center justify-center gap-2 flex-wrap">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--flame-tint)] text-[#FF6B2C] text-sm font-bold">
                <StreakFlame size={18} />
                <span>{Math.max(1, currentStreak)}-day streak</span>
              </div>
              {lastGoalTokensEarned > 0 && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--water-100)] text-[var(--brand-600)] text-sm font-bold tabular-nums">
                  <TokenCoinIcon size={18} />
                  <span>+{lastGoalTokensEarned} Dew Tokens</span>
                </div>
              )}
            </div>
            <h2 className="mt-3 text-[26px] font-extrabold text-[var(--ink-900)]">
              Goal reached!
            </h2>
            <p className="mt-1 text-sm text-[var(--ink-500)] tabular-nums">
              You hit {todayTotalMl.toLocaleString()} of {effectiveGoalMl.toLocaleString()} ml today.
              {lastGoalTokensEarned > 0 ? ' Visit Settings to open a Mystery Recipe Box!' : ''}
            </p>

            <div className="mt-6 space-y-2.5">
              <button
                type="button"
                disabled={sharing}
                onClick={() => void handleShare()}
                className="w-full h-14 rounded-[20px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-[17px] flex items-center justify-center gap-2 sippy-press-ink cursor-pointer"
              >
                <Share2 size={18} />
                <span>{sharing ? 'Rendering card...' : 'Share progress card'}</span>
              </button>
              <button
                type="button"
                onClick={() => setGoalHitSheetOpen(false)}
                className="w-full h-11 rounded-[20px] text-sm font-bold text-[var(--brand-600)] cursor-pointer"
              >
                Back to Home
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* Reminder Notification Banner Preview — Redesign Pass 2, Page 6 */
export const ReminderPreviewModal: React.FC = () => {
  const {
    reminderPreviewOpen,
    setReminderPreviewOpen,
    todayTotalMl,
    effectiveGoalMl,
    nextPendingSlot,
    requestLogDrink,
    snoozeSlot,
    profile,
  } = useSippy();

  if (!profile) return null;

  const pct = Math.min(100, Math.round((todayTotalMl / Math.max(1, effectiveGoalMl)) * 100));
  const targetMl = nextPendingSlot?.targetMl ?? 250;
  const title =
    profile.tone === 'gentle'
      ? 'Sip time'
      : profile.tone === 'coach'
        ? `Next ${targetMl} ml`
        : 'Sippy is parched';
  const body =
    profile.tone === 'gentle'
      ? 'A little water now keeps the afternoon easy.'
      : profile.tone === 'coach'
        ? `Time for ${targetMl} ml to stay ahead of pace.`
        : `${targetMl} ml and I’ll stop dramatically fainting.`;

  return (
    <AnimatePresence>
      {reminderPreviewOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[55] bg-[#0B1633]/92 flex flex-col justify-between items-center px-5 pt-12 pb-0 overflow-hidden"
          onClick={() => setReminderPreviewOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Sippy reminder card"
        >
          {/* Notification Banner Card */}
          <motion.div
            initial={{ y: -32, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -24, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 360, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[440px] rounded-[28px] bg-white p-5 shadow-2xl"
          >
            <div className="flex items-start gap-3.5">
              {/* 56px Brand App Icon */}
              <div className="w-14 h-14 rounded-[16px] bg-[#3D6EF5] flex items-center justify-center shrink-0 overflow-hidden">
                <Mascot mood="thirsty" persona={profile.tone} size={50} hideShadow />
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-[12px] font-semibold text-[#5B6578]">Sippy · now</p>
                <h2 className="text-[20px] leading-tight font-extrabold text-[#0B1633]">{title}</h2>
                <p className="mt-0.5 text-[14px] leading-snug font-medium text-[#5B6578]">{body}</p>
              </div>

              {/* Water Ring */}
              <div className="relative w-12 h-12 shrink-0 flex items-center justify-center">
                <svg width="48" height="48" viewBox="0 0 48 48" aria-hidden="true">
                  <circle cx="24" cy="24" r="19" stroke="#D9F2FD" strokeWidth="5" fill="none" />
                  <circle
                    cx="24"
                    cy="24"
                    r="19"
                    stroke="#19B4F2"
                    strokeWidth="5"
                    strokeLinecap="round"
                    fill="none"
                    strokeDasharray={`${Math.round((pct / 100) * 119.4)} 120`}
                    transform="rotate(-90 24 24)"
                  />
                </svg>
                <span className="absolute text-[11px] font-extrabold text-[#0B1633] tabular-nums">
                  {pct}%
                </span>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <button
                type="button"
                onClick={async () => {
                  setReminderPreviewOpen(false);
                  await requestLogDrink({ ml: targetMl, drinkType: 'water', source: 'app' });
                }}
                className="flex-1 h-12 rounded-[16px] bg-[#0B1633] text-white font-bold text-[16px] sippy-press-ink cursor-pointer"
              >
                Done
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (nextPendingSlot) {
                    await snoozeSlot(nextPendingSlot.id, 15);
                  }
                  setReminderPreviewOpen(false);
                }}
                className="px-3 min-h-[44px] text-[15px] font-bold text-[#2F5BE0] cursor-pointer whitespace-nowrap"
              >
                Remind me later
              </button>
            </div>
          </motion.div>

          {/* Large thirsty Sippy peeking up from bottom edge (Design Pass 2 Page 6) */}
          <motion.div
            initial={{ y: 80 }}
            animate={{ y: 36 }}
            exit={{ y: 120 }}
            transition={{ type: 'spring', stiffness: 260, damping: 24 }}
            className="pointer-events-none"
          >
            <Mascot mood="thirsty" persona={profile.tone} size={230} hideShadow />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
