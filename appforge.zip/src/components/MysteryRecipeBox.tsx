import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { BookOpen, ChevronRight, Clock, Droplets, Lock, X } from 'lucide-react';
import { useSippy } from '../context/SippyContext';
import type { HydrationRecipe } from '../types';
import { formatVolume } from '../utils/patternEngine';
import {
  RECIPE_CATEGORY_LABELS,
  RECIPE_DRINK_TYPE,
  WATER_RECIPES,
} from '../utils/recipes';
import { MysteryBoxIcon, TokenCoinIcon } from './BrandIcons';

export const MysteryRecipeBox: React.FC = () => {
  const {
    profile,
    tokens,
    mysteryBoxCost,
    unlockedRecipes,
    openMysteryBox,
    requestLogDrink,
  } = useSippy();

  const [openingPhase, setOpeningPhase] = useState<'idle' | 'shaking' | 'open'>('idle');
  const [activeRecipe, setActiveRecipe] = useState<{
    recipe: HydrationRecipe;
    justUnlocked?: boolean;
    isNew?: boolean;
  } | null>(null);
  const [boxError, setBoxError] = useState<string | null>(null);

  if (!profile) return null;

  const canAfford = tokens >= mysteryBoxCost;
  const remainingNeeded = Math.max(0, mysteryBoxCost - tokens);

  const collectedRecipes = unlockedRecipes
    .map((entry) => ({
      entry,
      recipe: WATER_RECIPES.find((r) => r.id === entry.recipeId),
    }))
    .filter((item): item is { entry: (typeof unlockedRecipes)[number]; recipe: HydrationRecipe } =>
      Boolean(item.recipe)
    );

  const handleOpenBox = () => {
    if (!canAfford || openingPhase === 'shaking') return;
    setBoxError(null);
    setOpeningPhase('shaking');

    window.setTimeout(() => {
      const res = openMysteryBox();
      if (!res.ok || !res.recipe) {
        setOpeningPhase('idle');
        setBoxError(res.error || 'Not enough Dew Tokens yet.');
        return;
      }
      setOpeningPhase('open');
      setActiveRecipe({
        recipe: res.recipe,
        justUnlocked: true,
        isNew: res.isNew,
      });
      window.setTimeout(() => setOpeningPhase('idle'), 900);
    }, 460);
  };

  const handleLogRecipe = async (recipe: HydrationRecipe) => {
    setActiveRecipe(null);
    await requestLogDrink({
      ml: recipe.waterMl,
      drinkType: RECIPE_DRINK_TYPE[recipe.category],
      source: 'app',
    });
  };

  return (
    <>
      <section
        aria-label="Dew Tokens and Mystery Box"
        className="sippy-blue-feature rounded-[26px] text-white p-4 space-y-4"
      >
        {/* Header with token balance */}
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-[18px] font-extrabold text-white">
              Dew Tokens & Recipe Box
            </h2>
            <p className="mt-0.5 text-xs text-[var(--brand-100)] font-medium">
              Hit your daily goal to earn tokens for custom drink recipes
            </p>
          </div>

          <div
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-[#0B1633] shadow-xs shrink-0"
            aria-label={`${tokens} Dew Tokens`}
          >
            <TokenCoinIcon size={21} />
            <span className="text-[16px] font-extrabold text-[#0B1633] sippy-num">
              {tokens}
            </span>
          </div>
        </div>

        {/* Mystery Box Stage */}
        <div className="rounded-[20px] bg-[var(--card)] text-[var(--ink-900)] p-4 flex items-center gap-4">
          <motion.div
            animate={
              openingPhase === 'shaking'
                ? {
                    rotate: [0, -8, 9, -7, 6, 0],
                    scale: [1, 1.04, 0.96, 1.06, 0.98, 1.08],
                  }
                : { rotate: 0, scale: 1 }
            }
            transition={{ duration: 0.45 }}
            className="shrink-0"
          >
            <MysteryBoxIcon size={64} open={openingPhase === 'open'} />
          </motion.div>

          <div className="min-w-0 flex-1">
            <p className="text-[16px] font-extrabold text-[var(--ink-900)]">
              Mystery Recipe Box
            </p>
            <p className="mt-0.5 text-xs text-[var(--ink-500)] leading-relaxed">
              Unlocks a unique coffee, sparkling, or infused water recipe.
            </p>

            <button
              type="button"
              onClick={handleOpenBox}
              disabled={!canAfford || openingPhase === 'shaking'}
              className={`mt-3 w-full h-11 px-4 rounded-[14px] text-xs font-extrabold flex items-center justify-center gap-2 transition-transform active:translate-y-[1px] ${
                canAfford
                  ? 'bg-[var(--mint-500)] text-white cursor-pointer'
                  : 'bg-[var(--card-tint)] text-[var(--ink-500)] cursor-not-allowed'
              }`}
              style={canAfford ? { boxShadow: '0 3px 0 var(--edge-mint)' } : undefined}
            >
              {canAfford ? (
                <>
                  <TokenCoinIcon size={17} />
                  <span className="sippy-num">
                    {openingPhase === 'shaking'
                      ? 'Opening box...'
                      : `Open box · ${mysteryBoxCost} tokens`}
                  </span>
                </>
              ) : (
                <>
                  <Lock size={14} />
                  <span className="sippy-num">Need {remainingNeeded} more tokens</span>
                </>
              )}
            </button>
          </div>
        </div>

        {boxError && (
          <p className="text-xs font-bold text-[#FFE4E4]">{boxError}</p>
        )}

        {/* Recipe Collection Shelf */}
        <div className="pt-0.5">
          <div className="flex items-center justify-between mb-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-white">
              <BookOpen size={14} className="text-[var(--brand-100)]" />
              <span>Recipe collection</span>
            </span>
            <span className="text-xs font-extrabold text-[var(--brand-100)] sippy-num">
              {collectedRecipes.length} of {WATER_RECIPES.length}
            </span>
          </div>

          {collectedRecipes.length === 0 ? (
            <div className="rounded-[18px] bg-white/15 border border-white/20 px-3.5 py-3 text-xs text-white font-medium">
              Open your first Mystery Box to save a water-based coffee or spa drink recipe here.
            </div>
          ) : (
            <ul className="divide-y divide-[var(--line)] rounded-[18px] bg-[var(--card)] text-[var(--ink-900)] overflow-hidden">
              {collectedRecipes.map(({ recipe }) => {
                const fmt = formatVolume(recipe.waterMl, profile.unit);
                return (
                  <li key={recipe.id}>
                    <button
                      type="button"
                      onClick={() => setActiveRecipe({ recipe })}
                      className="w-full px-3.5 py-3 flex items-center justify-between gap-3 text-left hover:bg-[var(--brand-50)]/60 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className="w-10 h-10 rounded-[12px] flex items-center justify-center shrink-0"
                          style={{ backgroundColor: recipe.accentBg, color: recipe.accentColor }}
                        >
                          <Droplets size={18} />
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-[var(--ink-900)] truncate">
                            {recipe.title}
                          </p>
                          <p className="text-xs text-[var(--ink-500)] sippy-num">
                            {RECIPE_CATEGORY_LABELS[recipe.category]} · {fmt.value} {fmt.unitLabel} · {recipe.prepMinutes} min
                          </p>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-[var(--ink-300)] shrink-0" />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>

      {/* Revealed / Selected Recipe Modal */}
      <AnimatePresence>
        {activeRecipe && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-[#0B1633]/65 backdrop-blur-xs flex items-end sm:items-center justify-center px-4 pb-4"
            onClick={() => setActiveRecipe(null)}
            role="dialog"
            aria-modal="true"
            aria-label={activeRecipe.recipe.title}
          >
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.96 }}
              transition={{ type: 'spring', stiffness: 360, damping: 28 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-[420px] rounded-[28px] bg-[var(--card)] p-5 shadow-2xl max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span
                    className="w-12 h-12 rounded-[16px] flex items-center justify-center shrink-0"
                    style={{
                      backgroundColor: activeRecipe.recipe.accentBg,
                      color: activeRecipe.recipe.accentColor,
                    }}
                  >
                    <Droplets size={22} />
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-[var(--brand-600)]">
                      {activeRecipe.justUnlocked
                        ? activeRecipe.isNew
                          ? 'New Mystery Recipe Unlocked'
                          : 'Mystery Recipe Encore'
                        : RECIPE_CATEGORY_LABELS[activeRecipe.recipe.category]}
                    </p>
                    <h3 className="text-[20px] leading-tight font-extrabold text-[var(--ink-900)]">
                      {activeRecipe.recipe.title}
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveRecipe(null)}
                  aria-label="Close recipe"
                  className="min-w-[40px] min-h-[40px] rounded-full flex items-center justify-center text-[var(--ink-500)] hover:bg-[var(--card-tint)] cursor-pointer shrink-0"
                >
                  <X size={18} />
                </button>
              </div>

              <p className="mt-3 text-sm text-[var(--ink-700)] leading-relaxed">
                {activeRecipe.recipe.tagline}
              </p>

              {/* Clean typographic metadata row */}
              <div className="mt-3 flex items-center gap-2 text-xs font-semibold text-[var(--ink-500)] tabular-nums">
                <span className="inline-flex items-center gap-1">
                  <Droplets size={13} className="text-[var(--water-500)]" />
                  {formatVolume(activeRecipe.recipe.waterMl, profile.unit).value}{' '}
                  {formatVolume(activeRecipe.recipe.waterMl, profile.unit).unitLabel} water base
                </span>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1">
                  <Clock size={13} />
                  {activeRecipe.recipe.prepMinutes} min prep
                </span>
              </div>

              {/* Ingredients */}
              <div className="mt-4 rounded-[18px] bg-[var(--canvas)] p-3.5">
                <h4 className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                  Ingredients
                </h4>
                <ul className="mt-2 space-y-1.5">
                  {activeRecipe.recipe.ingredients.map((ing) => (
                    <li key={ing} className="text-sm text-[var(--ink-900)] font-medium flex items-start gap-2">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full bg-[var(--brand-500)] shrink-0" />
                      <span>{ing}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Steps */}
              <div className="mt-3 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-[0.06em] text-[var(--ink-500)]">
                  How to make it
                </h4>
                <ol className="space-y-2">
                  {activeRecipe.recipe.steps.map((step, i) => (
                    <li key={step} className="flex items-start gap-2.5 text-sm text-[var(--ink-700)]">
                      <span className="w-5 h-5 rounded-full bg-[var(--brand-50)] text-[var(--brand-600)] text-xs font-extrabold flex items-center justify-center shrink-0 mt-0.5 tabular-nums">
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <p className="mt-3 text-xs text-[var(--ink-500)] bg-[var(--brand-50)]/60 rounded-[14px] px-3 py-2.5">
                {activeRecipe.recipe.hydrationTip}
              </p>

              <div className="mt-4 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setActiveRecipe(null)}
                  className="h-12 rounded-[16px] bg-[var(--card-tint)] text-[var(--ink-700)] font-bold text-sm sippy-press-tint cursor-pointer"
                >
                  Done
                </button>
                <button
                  type="button"
                  onClick={() => void handleLogRecipe(activeRecipe.recipe)}
                  className="h-12 rounded-[16px] bg-[var(--color-cta)] text-[var(--color-cta-text)] font-bold text-sm flex items-center justify-center gap-1.5 sippy-press-ink cursor-pointer"
                >
                  <Droplets size={15} />
                  <span>
                    Log {formatVolume(activeRecipe.recipe.waterMl, profile.unit).value}{' '}
                    {formatVolume(activeRecipe.recipe.waterMl, profile.unit).unitLabel}
                  </span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
