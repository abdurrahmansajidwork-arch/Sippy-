import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  onSnapshot,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import type {
  AchievementIconKey,
  AchievementPaletteKey,
  BadgeInfo,
  BadgeProgressInfo,
  CustomBadge,
  CustomBadgeRuleType,
  CustomBadgeStatus,
  DaySummary,
  DrinkType,
  FeelingLevel,
  GlassIconType,
  GlassPreset,
  GlassSkin,
  HydrationLog,
  HydrationPattern,
  HydrationRecipe,
  LogSource,
  NotificationTone,
  PatternStats,
  ReminderSlot,
  ScheduleTweak,
  SippyMood,
  UnitType,
  UnlockedRecipeEntry,
  UserProfile,
  WeatherBoostInfo,
} from '../types';
import {
  auth,
  db,
  handleFirestoreError,
  isFirebaseConfigured,
  OperationType,
  signInWithGooglePopup,
  signOutFirebase,
  testFirestoreConnection,
} from '../services/firebase';
import { fetchWeatherBoost } from '../services/weatherBoost';
import { requestPushAndRegisterToken } from '../services/pushNotifications';
import { createDefaultGlasses, createDemoSeedData } from '../utils/demoData';
import {
  calculateCountedMl,
  computeHydrationPatterns,
  computeStreakAndBadges,
  getSippyMood,
} from '../utils/patternEngine';
import {
  evaluateIntakeSafety,
  getCurrentIntakeStatus,
  type CurrentIntakeWarningState,
  type IntakeSafetyEvaluation,
} from '../utils/intakeGuard';
import {
  computeStreakAchievements,
  createStarterCustomBadges,
  evaluateCustomBadges,
  validateCustomBadgeInput,
} from '../utils/achievements';
import {
  canOpenMysteryBox,
  computeGoalRewardTokens,
  MYSTERY_BOX_COST,
  pickMysteryRecipe,
} from '../utils/recipes';
import {
  adjustScheduleForIntake,
  buildScheduleSlots,
  shiftPlanForMissedSlots,
  snapTo5Min,
  toDateKey,
} from '../utils/scheduleEngine';

const DEMO_STORAGE_KEY = 'sippy_demo_state_v2';
const LOCAL_STORAGE_KEY = 'sippy_local_state_v1';
const CUSTOM_BADGES_PREFIX = 'sippy_custom_badges_v1_';
const TOKENS_PREFIX = 'sippy_tokens_v1_';

interface PersistedTokenState {
  balance: number;
  rewardedDates: string[];
  unlockedRecipes: UnlockedRecipeEntry[];
  totalBoxesOpened: number;
}

export interface UndoToastState {
  id: string;
  logId: string;
  ml: number;
  message: string;
}

export interface PendingDrinkRequest {
  ml: number;
  drinkType: DrinkType;
  glassId?: string;
  ts?: number;
  source: LogSource;
  safety: IntakeSafetyEvaluation;
}

interface SippyContextValue {
  mode: 'loading' | 'onboarding' | 'app';
  onboardingStep: number;
  setOnboardingStep: (step: number) => void;
  isDemo: boolean;
  authUser: User | null;
  authError: string | null;
  profile: UserProfile | null;
  glasses: GlassPreset[];
  logs: HydrationLog[];
  todayLogs: HydrationLog[];
  days: DaySummary[];
  slots: ReminderSlot[];
  todaySlots: ReminderSlot[];
  nextPendingSlot: ReminderSlot | null;
  pattern: HydrationPattern | null;
  patternStats: PatternStats;
  weatherInfo: WeatherBoostInfo | null;
  effectiveGoalMl: number;
  todayTotalMl: number;
  boostMl: number;
  boostReason: string | null;
  currentStreak: number;
  bestStreak: number;
  shieldsEarned: number;
  shieldSavedDates: string[];
  badges: BadgeInfo[];
  achievementBadges: BadgeProgressInfo[];
  customBadges: CustomBadge[];
  customBadgeStatuses: CustomBadgeStatus[];
  tokens: number;
  mysteryBoxCost: number;
  unlockedRecipes: UnlockedRecipeEntry[];
  totalBoxesOpened: number;
  lastGoalTokensEarned: number;
  unlockedSkins: GlassSkin[];
  goalHitRate: number;
  avgDailyMl: number;
  sippyMood: SippyMood;
  sippyMessage: string;
  isLoggingAnim: boolean;
  showConfetti: boolean;
  goalHitSheetOpen: boolean;
  setGoalHitSheetOpen: (open: boolean) => void;
  logSheetOpen: boolean;
  setLogSheetOpen: (open: boolean) => void;
  feelingSheetOpen: boolean;
  setFeelingSheetOpen: (open: boolean) => void;
  reminderPreviewOpen: boolean;
  setReminderPreviewOpen: (open: boolean) => void;
  pendingDrinkRequest: PendingDrinkRequest | null;
  intakeWarningStatus: CurrentIntakeWarningState;
  undoToast: UndoToastState | null;
  dismissUndoToast: () => void;
  liveAnnouncement: string;
  aiLoading: boolean;
  aiError: string | null;
  fewerRemindersPrompt: boolean;
  dismissFewerRemindersPrompt: () => void;
  // Actions
  startDemoMode: () => void;
  signInWithGoogle: () => Promise<void>;
  finishOnboarding: (draft: {
    name: string;
    email?: string;
    goalMl: number;
    wakeTime: string;
    bedTime: string;
    tone: NotificationTone;
    selectedGlasses: GlassPreset[];
    defaultGlassId: string;
  }) => Promise<void>;
  signOutUser: () => Promise<void>;
  requestLogDrink: (params: {
    ml: number;
    drinkType?: DrinkType;
    glassId?: string;
    ts?: number;
    source?: LogSource;
  }) => Promise<boolean>;
  confirmPendingDrink: () => Promise<void>;
  cancelPendingDrink: () => void;
  logDrink: (params: {
    ml: number;
    drinkType?: DrinkType;
    glassId?: string;
    ts?: number;
    source?: LogSource;
  }) => Promise<void>;
  editLog: (logId: string, updates: { ml: number; ts: number; drinkType: DrinkType }) => Promise<void>;
  deleteLog: (logId: string) => Promise<void>;
  undoLastLog: () => Promise<void>;
  snoozeSlot: (slotId: string, minutes?: number) => Promise<void>;
  skipSlot: (slotId: string) => Promise<void>;
  completeSlot: (slotId: string) => Promise<void>;
  editSlotTime: (slotId: string, newNotifyAt: number) => Promise<void>;
  toggleWorkoutBoost: () => Promise<void>;
  removeTodayBoosts: () => Promise<void>;
  toggleWeatherBoost: (enabled: boolean) => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  addGlass: (glass: { name: string; ml: number; icon: GlassIconType }) => Promise<void>;
  updateGlass: (glassId: string, updates: { name: string; ml: number; icon: GlassIconType }) => Promise<void>;
  deleteGlass: (glassId: string) => Promise<void>;
  addCustomBadge: (input: {
    title: string;
    ruleType: CustomBadgeRuleType;
    targetValue: number;
    icon: AchievementIconKey;
    palette: AchievementPaletteKey;
  }) => { ok: boolean; error?: string };
  deleteCustomBadge: (badgeId: string) => void;
  openMysteryBox: () => {
    ok: boolean;
    recipe?: HydrationRecipe;
    isNew?: boolean;
    boxNumber?: number;
    error?: string;
  };
  submitFeeling: (level: FeelingLevel) => Promise<void>;
  refreshAIInsight: () => Promise<void>;
  enablePushNotifications: () => Promise<{ granted: boolean; reason?: string }>;
  exportAllDataJson: () => void;
  deleteAccountAndData: () => Promise<void>;
}

const SippyContext = createContext<SippyContextValue | null>(null);

export const SippyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setMode] = useState<'loading' | 'onboarding' | 'app'>('loading');
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [isDemo, setIsDemo] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [glasses, setGlasses] = useState<GlassPreset[]>([]);
  const [logs, setLogs] = useState<HydrationLog[]>([]);
  const [days, setDays] = useState<DaySummary[]>([]);
  const [slots, setSlots] = useState<ReminderSlot[]>([]);
  const [pattern, setPattern] = useState<HydrationPattern | null>(null);
  const [weatherInfo, setWeatherInfo] = useState<WeatherBoostInfo | null>(null);
  const [customBadges, setCustomBadges] = useState<CustomBadge[]>([]);
  const [tokenState, setTokenState] = useState<PersistedTokenState>({
    balance: 5,
    rewardedDates: [],
    unlockedRecipes: [],
    totalBoxesOpened: 0,
  });
  const [lastGoalTokensEarned, setLastGoalTokensEarned] = useState(0);

  const [isLoggingAnim, setIsLoggingAnim] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [goalHitSheetOpen, setGoalHitSheetOpen] = useState(false);
  const [logSheetOpen, setLogSheetOpen] = useState(false);
  const [feelingSheetOpen, setFeelingSheetOpen] = useState(false);
  const [reminderPreviewOpen, setReminderPreviewOpen] = useState(false);
  const [pendingDrinkRequest, setPendingDrinkRequest] = useState<PendingDrinkRequest | null>(null);
  const [undoToast, setUndoToast] = useState<UndoToastState | null>(null);
  const [liveAnnouncement, setLiveAnnouncement] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [fewerRemindersPrompt, setFewerRemindersPrompt] = useState(false);

  const lastFeelingLogCountRef = useRef(0);
  const logsInitializedRef = useRef(false);
  const rebuildTimerRef = useRef<number | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const todayKey = toDateKey(Date.now());

  const persistLocalOrDemo = useCallback(
    (
      key: string,
      next: {
        profile: UserProfile | null;
        glasses: GlassPreset[];
        logs: HydrationLog[];
        days: DaySummary[];
        slots: ReminderSlot[];
        pattern: HydrationPattern | null;
      }
    ) => {
      try {
        localStorage.setItem(key, JSON.stringify(next));
      } catch {
        // ignore quota error
      }
    },
    []
  );

  const startDemoMode = useCallback(() => {
    setIsDemo(true);
    setAuthError(null);
    let seed = createDemoSeedData();
    try {
      const saved = localStorage.getItem(DEMO_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.profile?.uid === 'demo-alex' && Array.isArray(parsed.logs)) {
          seed = {
            profile: parsed.profile,
            glasses: parsed.glasses || seed.glasses,
            logs: parsed.logs,
            days: parsed.days || seed.days,
            slots: parsed.slots || seed.slots,
          };
          if (parsed.pattern) setPattern(parsed.pattern);
        }
      }
    } catch {
      // use fresh seed
    }
    const seedTodayCount = seed.logs.filter((l) => l.date === todayKey).length;
    lastFeelingLogCountRef.current = seedTodayCount;
    logsInitializedRef.current = true;
    setProfile(seed.profile);
    setGlasses(seed.glasses);
    setLogs(seed.logs);
    setDays(seed.days);
    setSlots(seed.slots);
    setMode('app');
  }, [todayKey]);

  // Boot check: ?demo=1 or ?autostart=1 or Firebase Auth
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('demo') === '1' || params.get('autostart') === '1') {
      startDemoMode();
      return;
    }

    if (!isFirebaseConfigured || !auth) {
      setMode('onboarding');
      setOnboardingStep(1);
      return;
    }

    testFirestoreConnection();

    let authResolved = false;
    const bootFallbackTimer = window.setTimeout(() => {
      if (!authResolved && !auth?.currentUser) {
        setMode('onboarding');
        setOnboardingStep(1);
      }
    }, 900);

    const unsubAuth = onAuthStateChanged(auth, (user) => {
      authResolved = true;
      window.clearTimeout(bootFallbackTimer);
      setAuthUser(user);
      if (!user) {
        setProfile(null);
        setGlasses([]);
        setLogs([]);
        setDays([]);
        setSlots([]);
        setPattern(null);
        setMode('onboarding');
        setOnboardingStep(1);
        return;
      }

      if (!db) return;
      const uid = user.uid;

      const unsubProfile = onSnapshot(
        doc(db, 'users', uid),
        (snap) => {
          if (snap.exists()) {
            setProfile(snap.data() as UserProfile);
            setMode('app');
          } else {
            setProfile(null);
            setMode('onboarding');
            setOnboardingStep(2);
          }
        },
        (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}`)
      );

      const unsubGlasses = onSnapshot(
        collection(db, 'users', uid, 'glasses'),
        (snap) => {
          setGlasses(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<GlassPreset, 'id'>) })));
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/glasses`)
      );

      const unsubLogs = onSnapshot(
        collection(db, 'users', uid, 'logs'),
        (snap) => {
          const loaded = snap.docs
            .map((d) => ({ id: d.id, ...(d.data() as Omit<HydrationLog, 'id'>) }))
            .sort((a, b) => b.ts - a.ts);
          if (!logsInitializedRef.current) {
            logsInitializedRef.current = true;
            lastFeelingLogCountRef.current = loaded.filter((l) => l.date === todayKey).length;
          }
          setLogs(loaded);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/logs`)
      );

      const unsubDays = onSnapshot(
        collection(db, 'users', uid, 'days'),
        (snap) => {
          setDays(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<DaySummary, 'id'>) })));
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/days`)
      );

      const unsubSlots = onSnapshot(
        collection(db, 'users', uid, 'slots'),
        (snap) => {
          setSlots(
            snap.docs
              .map((d) => ({ id: d.id, ...(d.data() as Omit<ReminderSlot, 'id'>) }))
              .sort((a, b) => a.notifyAt - b.notifyAt)
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/slots`)
      );

      const unsubPattern = onSnapshot(
        doc(db, 'users', uid, 'patterns', 'current'),
        (snap) => {
          if (snap.exists()) {
            setPattern(snap.data() as HydrationPattern);
          }
        },
        (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}/patterns/current`)
      );

      return () => {
        unsubProfile();
        unsubGlasses();
        unsubLogs();
        unsubDays();
        unsubSlots();
        unsubPattern();
      };
    });

    return () => {
      window.clearTimeout(bootFallbackTimer);
      unsubAuth();
    };
  }, [startDemoMode]);

  // Derived metrics
  const todayLogs = useMemo(
    () => logs.filter((l) => l.date === todayKey).sort((a, b) => b.ts - a.ts),
    [logs, todayKey]
  );

  const todayTotalMl = useMemo(
    () => todayLogs.reduce((sum, l) => sum + l.countedMl, 0),
    [todayLogs]
  );

  const weatherBoostMl = profile?.weatherBoost && weatherInfo ? weatherInfo.boostMl : 0;
  const workoutBoostMl = profile?.workoutBoostMl ?? 0;
  const boostMl = weatherBoostMl + workoutBoostMl;
  const effectiveGoalMl = (profile?.goalMl ?? 2500) + boostMl;

  const boostReason = useMemo(() => {
    const parts: string[] = [];
    if (weatherBoostMl > 0) parts.push(`+${weatherBoostMl} hot day`);
    if (workoutBoostMl > 0) parts.push(`+${workoutBoostMl} workout`);
    return parts.length > 0 ? parts.join(' & ') : null;
  }, [weatherBoostMl, workoutBoostMl]);

  const todaySlots = useMemo(
    () => slots.filter((s) => s.date === todayKey).sort((a, b) => a.notifyAt - b.notifyAt),
    [slots, todayKey]
  );

  const nextPendingSlot = useMemo(
    () => todaySlots.find((s) => s.status === 'pending') ?? null,
    [todaySlots]
  );

  const streakInfo = useMemo(
    () => computeStreakAndBadges(days, logs, todayKey, profile?.shields ?? 0),
    [days, logs, todayKey, profile?.shields]
  );

  const achievementBadges = useMemo(
    () =>
      computeStreakAchievements({
        days,
        logs,
        currentStreak: streakInfo.currentStreak,
        bestStreak: streakInfo.bestStreak,
      }),
    [days, logs, streakInfo.currentStreak, streakInfo.bestStreak]
  );

  const customBadgeStatuses = useMemo(
    () =>
      evaluateCustomBadges(customBadges, {
        currentStreak: streakInfo.currentStreak,
        bestStreak: streakInfo.bestStreak,
        totalLogsCount: logs.length,
      }),
    [customBadges, streakInfo.currentStreak, streakInfo.bestStreak, logs.length]
  );

  const computedPatterns = useMemo(
    () => computeHydrationPatterns(logs, slots, days),
    [logs, slots, days]
  );

  const moodInfo = useMemo(
    () =>
      getSippyMood({
        loggedMl: todayTotalMl,
        goalMl: effectiveGoalMl,
        wakeTime: profile?.wakeTime ?? '07:00',
        bedTime: profile?.bedTime ?? '23:00',
        nowMs: Date.now(),
        slots: todaySlots,
        isStreakMilestone: showConfetti && streakInfo.currentStreak >= 3,
        tone: profile?.tone,
      }),
    [
      todayTotalMl,
      effectiveGoalMl,
      profile?.wakeTime,
      profile?.bedTime,
      profile?.tone,
      todaySlots,
      showConfetti,
      streakInfo.currentStreak,
    ]
  );

  const intakeWarningStatus = useMemo(
    () => getCurrentIntakeStatus(todayTotalMl, effectiveGoalMl),
    [todayTotalMl, effectiveGoalMl]
  );

  // Load & persist custom badges per user uid
  useEffect(() => {
    if (!profile?.uid) {
      setCustomBadges([]);
      return;
    }
    try {
      const raw = localStorage.getItem(`${CUSTOM_BADGES_PREFIX}${profile.uid}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setCustomBadges(parsed);
          return;
        }
      }
      if (profile.uid === 'demo-alex') {
        const starter = createStarterCustomBadges();
        setCustomBadges(starter);
        localStorage.setItem(`${CUSTOM_BADGES_PREFIX}${profile.uid}`, JSON.stringify(starter));
      } else {
        setCustomBadges([]);
      }
    } catch {
      setCustomBadges(profile.uid === 'demo-alex' ? createStarterCustomBadges() : []);
    }
  }, [profile?.uid]);

  useEffect(() => {
    if (!profile?.uid) return;
    try {
      localStorage.setItem(`${CUSTOM_BADGES_PREFIX}${profile.uid}`, JSON.stringify(customBadges));
    } catch {
      // ignore storage quota errors
    }
  }, [profile?.uid, customBadges]);

  // Load & persist Dew Tokens + Mystery Box recipes per user uid
  useEffect(() => {
    if (!profile?.uid) {
      setTokenState({ balance: 5, rewardedDates: [], unlockedRecipes: [], totalBoxesOpened: 0 });
      return;
    }
    const defaultState: PersistedTokenState =
      profile.uid === 'demo-alex'
        ? {
            balance: 15,
            rewardedDates: [],
            unlockedRecipes: [
              {
                recipeId: 'cardamom_cold_brew',
                unlockedAt: Date.now() - 86400000,
                boxNumber: 1,
              },
            ],
            totalBoxesOpened: 1,
          }
        : {
            balance: 5,
            rewardedDates: [],
            unlockedRecipes: [],
            totalBoxesOpened: 0,
          };

    try {
      const raw = localStorage.getItem(`${TOKENS_PREFIX}${profile.uid}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.balance === 'number') {
          setTokenState({
            balance: Math.max(0, parsed.balance),
            rewardedDates: Array.isArray(parsed.rewardedDates) ? parsed.rewardedDates : [],
            unlockedRecipes: Array.isArray(parsed.unlockedRecipes) ? parsed.unlockedRecipes : [],
            totalBoxesOpened: typeof parsed.totalBoxesOpened === 'number' ? parsed.totalBoxesOpened : 0,
          });
          return;
        }
      }
      setTokenState(defaultState);
      localStorage.setItem(`${TOKENS_PREFIX}${profile.uid}`, JSON.stringify(defaultState));
    } catch {
      setTokenState(defaultState);
    }
  }, [profile?.uid]);

  useEffect(() => {
    if (!profile?.uid) return;
    try {
      localStorage.setItem(`${TOKENS_PREFIX}${profile.uid}`, JSON.stringify(tokenState));
    } catch {
      // ignore storage quota errors
    }
  }, [profile?.uid, tokenState]);

  // Sync demo or local-guest data to isolated localStorage keys
  useEffect(() => {
    if (isDemo && profile) {
      const storageKey =
        profile.uid === 'demo-alex' ? DEMO_STORAGE_KEY : LOCAL_STORAGE_KEY;
      persistLocalOrDemo(storageKey, { profile, glasses, logs, days, slots, pattern });
    }
  }, [isDemo, profile, glasses, logs, days, slots, pattern, persistLocalOrDemo]);

  // Weather boost fetch when enabled
  useEffect(() => {
    if (!profile?.weatherBoost || mode !== 'app') return;
    if (weatherInfo && Date.now() - weatherInfo.fetchedAt < 3 * 3600 * 1000) return;

    fetchWeatherBoost(profile.goalMl)
      .then((info) => setWeatherInfo(info))
      .catch(() => {
        // Silent fallback if geolocation denied or offline
      });
  }, [profile?.weatherBoost, profile?.goalMl, mode, weatherInfo]);

  // Check for 3 ignored pushes in a row -> offer fewer reminders
  useEffect(() => {
    const recent = [...todaySlots]
      .filter((s) => s.status !== 'pending')
      .sort((a, b) => b.notifyAt - a.notifyAt)
      .slice(0, 3);
    if (recent.length === 3 && recent.every((s) => s.status === 'missed')) {
      setFewerRemindersPrompt(true);
    }
  }, [todaySlots]);

  const syncDayAndSlots = useCallback(
    async (
      nextProfile: UserProfile,
      nextLogs: HydrationLog[],
      nextSlots: ReminderSlot[],
      extraDayUpdates?: Partial<DaySummary>
    ) => {
      const uid = nextProfile.uid;
      const dayLogs = nextLogs.filter((l) => l.date === todayKey);
      const totalMl = dayLogs.reduce((s, l) => s + l.countedMl, 0);
      const goal = nextProfile.goalMl + (nextProfile.workoutBoostMl || 0) + (nextProfile.weatherBoost && weatherInfo ? weatherInfo.boostMl : 0);
      const existingDay = days.find((d) => d.date === todayKey);
      const nextDay: DaySummary = {
        id: todayKey,
        uid,
        date: todayKey,
        goalMl: goal,
        totalMl,
        hit: totalMl >= goal,
        shieldUsed: existingDay?.shieldUsed ?? false,
        boostMl: goal - nextProfile.goalMl,
        feelings: extraDayUpdates?.feelings ?? existingDay?.feelings ?? [],
        updatedAt: Date.now(),
      };

      const dedupedSlots = Array.from(
        new Map(nextSlots.map((s) => [s.id, s])).values()
      ).sort((a, b) => a.notifyAt - b.notifyAt);

      setDays((prev) => {
        const rest = prev.filter((d) => d.date !== todayKey);
        return [...rest, nextDay];
      });
      setSlots(dedupedSlots);

      if (!isDemo && db && authUser) {
        try {
          const dayPath = `users/${uid}/days/${todayKey}`;
          await setDoc(doc(db, 'users', uid, 'days', todayKey), {
            uid,
            date: todayKey,
            goalMl: nextDay.goalMl,
            totalMl: nextDay.totalMl,
            hit: nextDay.hit,
            shieldUsed: nextDay.shieldUsed,
            boostMl: nextDay.boostMl,
            feelings: nextDay.feelings,
            updatedAt: nextDay.updatedAt,
          }).catch((e) => handleFirestoreError(e, OperationType.WRITE, dayPath));

          const batch = writeBatch(db);
          for (const s of dedupedSlots.filter((x) => x.date === todayKey)) {
            const payload: Record<string, unknown> = {
              uid,
              date: s.date,
              notifyAt: s.notifyAt,
              targetMl: s.targetMl,
              status: s.status,
              title: s.title,
              body: s.body,
              notified: s.notified,
              updatedAt: Date.now(),
            };
            if (s.movedFrom !== undefined) payload.movedFrom = s.movedFrom;
            if (s.createdAt !== undefined) payload.createdAt = s.createdAt;
            batch.set(doc(db, 'users', uid, 'slots', s.id), payload);
          }
          await batch.commit();
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `users/${uid}/slots`);
        }
      }
    },
    [todayKey, weatherInfo, days, isDemo, authUser]
  );

  const scheduleDebouncedRebuild = useCallback(
    (nextProfile: UserProfile, nextLogs: HydrationLog[], currentSlots: ReminderSlot[]) => {
      if (rebuildTimerRef.current) window.clearTimeout(rebuildTimerRef.current);
      rebuildTimerRef.current = window.setTimeout(() => {
        const defGlass = glasses.find((g) => g.id === nextProfile.defaultGlassId);
        const total = nextLogs
          .filter((l) => l.date === todayKey)
          .reduce((s, l) => s + l.countedMl, 0);
        const goal =
          nextProfile.goalMl +
          (nextProfile.workoutBoostMl || 0) +
          (nextProfile.weatherBoost && weatherInfo ? weatherInfo.boostMl : 0);

        const rebuilt = buildScheduleSlots({
          uid: nextProfile.uid,
          dateKey: todayKey,
          goalMl: goal,
          loggedMl: total,
          defaultGlassMl: defGlass?.ml ?? 250,
          wakeTime: nextProfile.wakeTime,
          bedTime: nextProfile.bedTime,
          maxPushPerDay: nextProfile.maxPushPerDay,
          tone: nextProfile.tone,
          nowMs: Date.now(),
          existingSlots: currentSlots,
          aiTweaks: pattern?.tweaks,
        });
        syncDayAndSlots(nextProfile, nextLogs, rebuilt);
      }, 2000);
    },
    [glasses, todayKey, weatherInfo, pattern?.tweaks, syncDayAndSlots]
  );

  // Periodic missed-slot detector while app is open
  useEffect(() => {
    if (mode !== 'app' || !profile) return;
    const interval = window.setInterval(() => {
      const shifted = shiftPlanForMissedSlots({
        uid: profile.uid,
        dateKey: todayKey,
        slots,
        goalMl: effectiveGoalMl,
        loggedMl: todayTotalMl,
        wakeTime: profile.wakeTime,
        bedTime: profile.bedTime,
        maxPushPerDay: profile.maxPushPerDay,
        tone: profile.tone,
        nowMs: Date.now(),
      });
      if (shifted.newlyMissedCount > 0) {
        syncDayAndSlots(profile, logs, shifted.slots);
      }
    }, 60 * 1000);

    return () => window.clearInterval(interval);
  }, [mode, profile, todayKey, slots, effectiveGoalMl, todayTotalMl, logs, syncDayAndSlots]);

  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    try {
      await signInWithGooglePopup();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google sign-in failed';
      setAuthError(msg);
    }
  }, []);

  const finishOnboarding = useCallback(
    async (draft: {
      name: string;
      email?: string;
      goalMl: number;
      wakeTime: string;
      bedTime: string;
      tone: NotificationTone;
      selectedGlasses: GlassPreset[];
      defaultGlassId: string;
    }) => {
      const now = Date.now();
      const isLocalSession = !authUser || !db;
      const uid = authUser?.uid || `local_${now}`;
      const cleanEmail = draft.email?.trim() || authUser?.email;
      const newProfile: UserProfile = {
        uid,
        name: draft.name.trim() || authUser?.displayName?.split(' ')[0] || 'Friend',
        ...(cleanEmail ? { email: cleanEmail } : {}),
        ...(authUser?.photoURL ? { photoURL: authUser.photoURL } : {}),
        goalMl: draft.goalMl,
        wakeTime: draft.wakeTime,
        bedTime: draft.bedTime,
        tone: draft.tone,
        maxPushPerDay: 8,
        unit: 'ml',
        defaultGlassId: draft.defaultGlassId,
        weatherBoost: false,
        workoutBoostMl: 0,
        shields: 0,
        activeSkin: 'classic',
        createdAt: now,
        updatedAt: now,
      };

      const initialGlasses = draft.selectedGlasses.map((g) => ({ ...g, uid }));
      const defGlass = initialGlasses.find((g) => g.id === draft.defaultGlassId) || initialGlasses[0];
      const initialSlots = buildScheduleSlots({
        uid,
        dateKey: todayKey,
        goalMl: newProfile.goalMl,
        loggedMl: 0,
        defaultGlassMl: defGlass?.ml ?? 250,
        wakeTime: newProfile.wakeTime,
        bedTime: newProfile.bedTime,
        maxPushPerDay: newProfile.maxPushPerDay,
        tone: newProfile.tone,
        nowMs: now,
      });

      const initialDay: DaySummary = {
        id: todayKey,
        uid,
        date: todayKey,
        goalMl: newProfile.goalMl,
        totalMl: 0,
        hit: false,
        shieldUsed: false,
        boostMl: 0,
        feelings: [],
        updatedAt: now,
      };

      if (isLocalSession) {
        setIsDemo(true);
        setDays([initialDay]);
        setLogs([]);
      }

      setProfile(newProfile);
      setGlasses(initialGlasses);
      setSlots(initialSlots);
      setMode('app');

      if (!isLocalSession && db && authUser) {
        try {
          await setDoc(doc(db, 'users', uid), newProfile);
          const batch = writeBatch(db);
          for (const g of initialGlasses) {
            batch.set(doc(db, 'users', uid, 'glasses', g.id), {
              uid,
              name: g.name,
              ml: g.ml,
              icon: g.icon,
              createdAt: now,
            });
          }
          for (const s of initialSlots) {
            batch.set(doc(db, 'users', uid, 'slots', s.id), s);
          }
          await batch.commit();
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
        }
      }
    },
    [authUser, todayKey]
  );

  const signOutUser = useCallback(async () => {
    if (isDemo) {
      if (profile?.uid === 'demo-alex') {
        localStorage.removeItem(DEMO_STORAGE_KEY);
      } else {
        localStorage.removeItem(LOCAL_STORAGE_KEY);
      }
      setIsDemo(false);
      setMode('onboarding');
      setOnboardingStep(1);
      return;
    }
    await signOutFirebase();
  }, [isDemo, profile?.uid]);

  const showUndoToast = useCallback((logId: string, ml: number) => {
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    setUndoToast({
      id: `toast_${Date.now()}`,
      logId,
      ml,
      message: `Added ${ml} ml.`,
    });
    toastTimerRef.current = window.setTimeout(() => {
      setUndoToast(null);
    }, 5000);
  }, []);

  const dismissUndoToast = useCallback(() => {
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    setUndoToast(null);
  }, []);

  const logDrink = useCallback(
    async ({
      ml,
      drinkType = 'water',
      glassId,
      ts,
      source = 'app',
    }: {
      ml: number;
      drinkType?: DrinkType;
      glassId?: string;
      ts?: number;
      source?: LogSource;
    }) => {
      if (!profile) return;
      const safeMl = Math.max(1, Math.min(3000, Math.round(ml)));
      const countedMl = calculateCountedMl(safeMl, drinkType);
      const now = ts ?? Date.now();
      const dateKey = toDateKey(now);
      const logId = `log_${now}_${Math.random().toString(36).slice(2, 7)}`;

      const newLog: HydrationLog = {
        id: logId,
        uid: profile.uid,
        ts: now,
        date: dateKey,
        ml: safeMl,
        countedMl,
        glassId: glassId || profile.defaultGlassId,
        drinkType,
        source,
        createdAt: Date.now(),
      };

      const prevTotal = todayTotalMl;
      const nextLogs = [newLog, ...logs];
      const nextTotal =
        dateKey === todayKey ? prevTotal + countedMl : prevTotal;

      setLogs(nextLogs);
      setIsLoggingAnim(true);
      window.setTimeout(() => setIsLoggingAnim(false), 1300);

      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate(15);
        } catch {
          // ignore unsupported
        }
      }

      setLiveAnnouncement(`Added ${safeMl} milliliters. Total today is ${nextTotal} of ${effectiveGoalMl} milliliters.`);
      showUndoToast(logId, safeMl);

      const adjustedSlots = adjustScheduleForIntake({
        slots,
        dateKey: todayKey,
        goalMl: effectiveGoalMl,
        newTotalLoggedMl: nextTotal,
        nowMs: now,
        tone: profile.tone,
      });

      if (!isDemo && db && authUser) {
        const logPath = `users/${profile.uid}/logs/${logId}`;
        try {
          await setDoc(doc(db, 'users', profile.uid, 'logs', logId), {
            uid: profile.uid,
            ts: newLog.ts,
            date: newLog.date,
            ml: newLog.ml,
            countedMl: newLog.countedMl,
            glassId: newLog.glassId,
            drinkType: newLog.drinkType,
            source: newLog.source,
            createdAt: newLog.createdAt,
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, logPath);
        }
      }

      await syncDayAndSlots(profile, nextLogs, adjustedSlots);
      scheduleDebouncedRebuild(profile, nextLogs, adjustedSlots);

      // Goal reached celebration + Dew Token reward (once per day)
      if (dateKey === todayKey && prevTotal < effectiveGoalMl && nextTotal >= effectiveGoalMl) {
        let earnedToday = 0;
        if (!tokenState.rewardedDates.includes(todayKey)) {
          earnedToday = computeGoalRewardTokens(streakInfo.currentStreak);
          setTokenState((prev) => {
            if (prev.rewardedDates.includes(todayKey)) return prev;
            return {
              ...prev,
              balance: prev.balance + earnedToday,
              rewardedDates: [...prev.rewardedDates, todayKey],
            };
          });
        }
        setLastGoalTokensEarned(earnedToday);
        setShowConfetti(true);
        setGoalHitSheetOpen(true);
        window.setTimeout(() => setShowConfetti(false), 1700);
      } else {
        // Feeling check-in: max 3 per day and max once per 3 logs
        const todayCount = nextLogs.filter((l) => l.date === todayKey).length;
        const todayFeelingsCount =
          days.find((d) => d.date === todayKey)?.feelings?.length ?? 0;
        if (
          todayFeelingsCount < 3 &&
          todayCount >= 3 &&
          todayCount - lastFeelingLogCountRef.current >= 3
        ) {
          lastFeelingLogCountRef.current = todayCount;
          window.setTimeout(() => setFeelingSheetOpen(true), 600);
        }
      }
    },
    [
      profile,
      todayTotalMl,
      logs,
      todayKey,
      effectiveGoalMl,
      showUndoToast,
      slots,
      isDemo,
      authUser,
      syncDayAndSlots,
      scheduleDebouncedRebuild,
      days,
      tokenState.rewardedDates,
      streakInfo.currentStreak,
    ]
  );

  const requestLogDrink = useCallback(
    async ({
      ml,
      drinkType = 'water',
      glassId,
      ts,
      source = 'app',
    }: {
      ml: number;
      drinkType?: DrinkType;
      glassId?: string;
      ts?: number;
      source?: LogSource;
    }): Promise<boolean> => {
      if (!profile) return false;
      const logDateKey = ts ? toDateKey(ts) : todayKey;
      if (logDateKey === todayKey) {
        const safety = evaluateIntakeSafety(todayTotalMl, ml, effectiveGoalMl, drinkType);
        if (safety.needsConfirmation) {
          setPendingDrinkRequest({
            ml,
            drinkType,
            glassId,
            ts,
            source,
            safety,
          });
          return false;
        }
      }
      await logDrink({ ml, drinkType, glassId, ts, source });
      return true;
    },
    [profile, todayKey, todayTotalMl, effectiveGoalMl, logDrink]
  );

  const confirmPendingDrink = useCallback(async () => {
    if (!pendingDrinkRequest) return;
    const req = pendingDrinkRequest;
    setPendingDrinkRequest(null);
    await logDrink({
      ml: req.ml,
      drinkType: req.drinkType,
      glassId: req.glassId,
      ts: req.ts,
      source: req.source,
    });
  }, [pendingDrinkRequest, logDrink]);

  const cancelPendingDrink = useCallback(() => {
    setPendingDrinkRequest(null);
  }, []);

  const deleteLog = useCallback(
    async (logId: string) => {
      if (!profile) return;
      const target = logs.find((l) => l.id === logId);
      if (!target) return;
      const nextLogs = logs.filter((l) => l.id !== logId);
      setLogs(nextLogs);

      if (!isDemo && db && authUser) {
        try {
          await deleteDoc(doc(db, 'users', profile.uid, 'logs', logId));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `users/${profile.uid}/logs/${logId}`);
        }
      }

      await syncDayAndSlots(profile, nextLogs, slots);
      scheduleDebouncedRebuild(profile, nextLogs, slots);
      setLiveAnnouncement(`Removed ${target.ml} milliliters log.`);
    },
    [profile, logs, isDemo, authUser, slots, syncDayAndSlots, scheduleDebouncedRebuild]
  );

  const editLog = useCallback(
    async (logId: string, updates: { ml: number; ts: number; drinkType: DrinkType }) => {
      if (!profile) return;
      const safeMl = Math.max(1, Math.min(3000, Math.round(updates.ml)));
      const countedMl = calculateCountedMl(safeMl, updates.drinkType);
      const dateKey = toDateKey(updates.ts);

      const nextLogs = logs.map((l) =>
        l.id === logId
          ? { ...l, ml: safeMl, countedMl, ts: updates.ts, date: dateKey, drinkType: updates.drinkType }
          : l
      );
      setLogs(nextLogs);

      if (!isDemo && db && authUser) {
        try {
          await updateDoc(doc(db, 'users', profile.uid, 'logs', logId), {
            ml: safeMl,
            countedMl,
            ts: updates.ts,
            date: dateKey,
            drinkType: updates.drinkType,
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}/logs/${logId}`);
        }
      }

      await syncDayAndSlots(profile, nextLogs, slots);
      scheduleDebouncedRebuild(profile, nextLogs, slots);
    },
    [profile, logs, isDemo, authUser, slots, syncDayAndSlots, scheduleDebouncedRebuild]
  );

  const undoLastLog = useCallback(async () => {
    if (!undoToast) return;
    const id = undoToast.logId;
    dismissUndoToast();
    await deleteLog(id);
  }, [undoToast, dismissUndoToast, deleteLog]);

  const snoozeSlot = useCallback(
    async (slotId: string, minutes = 15) => {
      if (!profile) return;
      const nextSlots = slots.map((s) =>
        s.id === slotId
          ? {
              ...s,
              movedFrom: s.movedFrom ?? s.notifyAt,
              notifyAt: snapTo5Min(Math.max(Date.now(), s.notifyAt) + minutes * 60 * 1000),
              notified: false,
              updatedAt: Date.now(),
            }
          : s
      );
      await syncDayAndSlots(profile, logs, nextSlots);
      setLiveAnnouncement(`Snoozed reminder by ${minutes} minutes.`);
    },
    [profile, slots, logs, syncDayAndSlots]
  );

  const skipSlot = useCallback(
    async (slotId: string) => {
      if (!profile) return;
      const shifted = shiftPlanForMissedSlots({
        uid: profile.uid,
        dateKey: todayKey,
        slots,
        goalMl: effectiveGoalMl,
        loggedMl: todayTotalMl,
        wakeTime: profile.wakeTime,
        bedTime: profile.bedTime,
        maxPushPerDay: profile.maxPushPerDay,
        tone: profile.tone,
        nowMs: Date.now(),
        skipSlotId: slotId,
      });
      await syncDayAndSlots(profile, logs, shifted.slots);
      setLiveAnnouncement('Skipped slot and shifted your remaining hydration plan.');
    },
    [profile, todayKey, slots, effectiveGoalMl, todayTotalMl, logs, syncDayAndSlots]
  );

  const completeSlot = useCallback(
    async (slotId: string) => {
      const slot = slots.find((s) => s.id === slotId);
      if (!slot) return;
      await logDrink({ ml: slot.targetMl, drinkType: 'water', source: 'app' });
    },
    [slots, logDrink]
  );

  const editSlotTime = useCallback(
    async (slotId: string, newNotifyAt: number) => {
      if (!profile) return;
      const nextSlots = slots
        .map((s) =>
          s.id === slotId
            ? {
                ...s,
                movedFrom: s.movedFrom ?? s.notifyAt,
                notifyAt: snapTo5Min(newNotifyAt),
                notified: false,
                updatedAt: Date.now(),
              }
            : s
        )
        .sort((a, b) => a.notifyAt - b.notifyAt);
      await syncDayAndSlots(profile, logs, nextSlots);
    },
    [profile, slots, logs, syncDayAndSlots]
  );

  const updateProfile = useCallback(
    async (updates: Partial<UserProfile>) => {
      if (!profile) return;
      const nextProfile: UserProfile = {
        ...profile,
        ...updates,
        updatedAt: Date.now(),
      };
      setProfile(nextProfile);

      if (!isDemo && db && authUser) {
        try {
          const cleanUpdates: Record<string, unknown> = { updatedAt: nextProfile.updatedAt };
          for (const [k, v] of Object.entries(updates)) {
            if (v !== undefined) cleanUpdates[k] = v;
          }
          await updateDoc(doc(db, 'users', profile.uid), cleanUpdates);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`);
        }
      }

      if (
        updates.goalMl !== undefined ||
        updates.wakeTime !== undefined ||
        updates.bedTime !== undefined ||
        updates.maxPushPerDay !== undefined ||
        updates.workoutBoostMl !== undefined ||
        updates.weatherBoost !== undefined ||
        updates.tone !== undefined
      ) {
        scheduleDebouncedRebuild(nextProfile, logs, slots);
      }
    },
    [profile, isDemo, authUser, logs, slots, scheduleDebouncedRebuild]
  );

  const toggleWorkoutBoost = useCallback(async () => {
    if (!profile) return;
    const nextBoost = profile.workoutBoostMl > 0 ? 0 : 500;
    await updateProfile({ workoutBoostMl: nextBoost });
  }, [profile, updateProfile]);

  const removeTodayBoosts = useCallback(async () => {
    if (!profile) return;
    setWeatherInfo(null);
    await updateProfile({ workoutBoostMl: 0, weatherBoost: false });
  }, [profile, updateProfile]);

  const toggleWeatherBoost = useCallback(
    async (enabled: boolean) => {
      await updateProfile({ weatherBoost: enabled });
      if (enabled && profile) {
        try {
          const info = await fetchWeatherBoost(profile.goalMl);
          setWeatherInfo(info);
        } catch {
          // Location denied or offline
        }
      } else {
        setWeatherInfo(null);
      }
    },
    [profile, updateProfile]
  );

  const addGlass = useCallback(
    async (glass: { name: string; ml: number; icon: GlassIconType }) => {
      if (!profile) return;
      const id = `glass_${Date.now()}`;
      const ml = Math.max(50, Math.min(1500, Math.round(glass.ml)));
      const newGlass: GlassPreset = {
        id,
        uid: profile.uid,
        name: glass.name.trim() || `${ml} ml Glass`,
        ml,
        icon: glass.icon,
        createdAt: Date.now(),
      };
      setGlasses((prev) => [...prev, newGlass]);

      if (!isDemo && db && authUser) {
        try {
          await setDoc(doc(db, 'users', profile.uid, 'glasses', id), {
            uid: profile.uid,
            name: newGlass.name,
            ml: newGlass.ml,
            icon: newGlass.icon,
            createdAt: newGlass.createdAt,
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, `users/${profile.uid}/glasses/${id}`);
        }
      }
    },
    [profile, isDemo, authUser]
  );

  const updateGlass = useCallback(
    async (glassId: string, updates: { name: string; ml: number; icon: GlassIconType }) => {
      if (!profile) return;
      const ml = Math.max(50, Math.min(1500, Math.round(updates.ml)));
      setGlasses((prev) =>
        prev.map((g) => (g.id === glassId ? { ...g, name: updates.name, ml, icon: updates.icon } : g))
      );

      if (!isDemo && db && authUser) {
        try {
          await updateDoc(doc(db, 'users', profile.uid, 'glasses', glassId), {
            name: updates.name,
            ml,
            icon: updates.icon,
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}/glasses/${glassId}`);
        }
      }
    },
    [profile, isDemo, authUser]
  );

  const deleteGlass = useCallback(
    async (glassId: string) => {
      if (!profile || glasses.length <= 1) return;
      const next = glasses.filter((g) => g.id !== glassId);
      setGlasses(next);
      if (profile.defaultGlassId === glassId && next[0]) {
        await updateProfile({ defaultGlassId: next[0].id });
      }
      if (!isDemo && db && authUser) {
        try {
          await deleteDoc(doc(db, 'users', profile.uid, 'glasses', glassId));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `users/${profile.uid}/glasses/${glassId}`);
        }
      }
    },
    [profile, glasses, isDemo, authUser, updateProfile]
  );

  const addCustomBadge = useCallback(
    (input: {
      title: string;
      ruleType: CustomBadgeRuleType;
      targetValue: number;
      icon: AchievementIconKey;
      palette: AchievementPaletteKey;
    }): { ok: boolean; error?: string } => {
      const check = validateCustomBadgeInput({
        title: input.title,
        targetValue: input.targetValue,
        ruleType: input.ruleType,
      });
      if (!check.valid) {
        return { ok: false, error: check.error };
      }
      const nextBadge: CustomBadge = {
        id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        title: check.cleanTitle,
        ruleType: input.ruleType,
        targetValue: check.cleanTarget,
        icon: input.icon,
        palette: input.palette,
        createdAt: Date.now(),
      };
      setCustomBadges((prev) => [nextBadge, ...prev]);
      setLiveAnnouncement(`Created custom badge ${check.cleanTitle}.`);
      return { ok: true };
    },
    []
  );

  const deleteCustomBadge = useCallback((badgeId: string) => {
    setCustomBadges((prev) => prev.filter((b) => b.id !== badgeId));
    setLiveAnnouncement('Removed custom badge.');
  }, []);

  const openMysteryBox = useCallback(() => {
    if (!canOpenMysteryBox(tokenState.balance)) {
      return {
        ok: false,
        error: `Need ${MYSTERY_BOX_COST} Dew Tokens to open a Mystery Box.`,
      };
    }
    const unlockedIds = tokenState.unlockedRecipes.map((entry) => entry.recipeId);
    const recipe = pickMysteryRecipe(unlockedIds);
    const alreadyOwned = unlockedIds.includes(recipe.id);
    const nextBoxNumber = tokenState.totalBoxesOpened + 1;

    setTokenState((prev) => ({
      ...prev,
      balance: Math.max(0, prev.balance - MYSTERY_BOX_COST),
      totalBoxesOpened: prev.totalBoxesOpened + 1,
      unlockedRecipes: alreadyOwned
        ? prev.unlockedRecipes
        : [
            {
              recipeId: recipe.id,
              unlockedAt: Date.now(),
              boxNumber: nextBoxNumber,
            },
            ...prev.unlockedRecipes,
          ],
    }));

    setLiveAnnouncement(`Opened Mystery Box #${nextBoxNumber} and unlocked ${recipe.title}.`);
    return {
      ok: true,
      recipe,
      isNew: !alreadyOwned,
      boxNumber: nextBoxNumber,
    };
  }, [tokenState.balance, tokenState.unlockedRecipes, tokenState.totalBoxesOpened]);

  const submitFeeling = useCallback(
    async (level: FeelingLevel) => {
      if (!profile) return;
      const existingDay = days.find((d) => d.date === todayKey);
      const nextFeelings = [
        ...(existingDay?.feelings ?? []),
        { ts: Date.now(), level, totalMlAtCheckin: todayTotalMl },
      ].slice(0, 10);

      await syncDayAndSlots(profile, logs, slots, { feelings: nextFeelings });
      setFeelingSheetOpen(false);
    },
    [profile, days, todayKey, todayTotalMl, syncDayAndSlots, logs, slots]
  );

  const refreshAIInsight = useCallback(async () => {
    if (!profile) return;
    setAiLoading(true);
    setAiError(null);
    const { stats, deterministicInsight } = computedPatterns;
    const defGlass = glasses.find((g) => g.id === profile.defaultGlassId);

    try {
      const res = await fetch('/api/gemini/insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stats,
          tone: profile.tone,
          goalMl: effectiveGoalMl,
          defaultGlassMl: defGlass?.ml ?? 250,
        }),
      });

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error(errBody.error || `Insight request failed (${res.status})`);
      }

      const data = await res.json();
      const insight =
        typeof data?.insight === 'string' && data.insight.trim()
          ? data.insight.trim().slice(0, 400)
          : deterministicInsight;
      const tweaks: ScheduleTweak[] = Array.isArray(data?.scheduleTweaks)
        ? data.scheduleTweaks.filter(
            (t: unknown): t is ScheduleTweak =>
              typeof t === 'object' &&
              t !== null &&
              typeof (t as ScheduleTweak).hour === 'number' &&
              typeof (t as ScheduleTweak).shiftMinutes === 'number'
          )
        : [];

      const nextPattern: HydrationPattern = {
        uid: profile.uid,
        stats,
        insight,
        tweaks,
        updatedAt: Date.now(),
      };
      setPattern(nextPattern);

      if (!isDemo && db && authUser) {
        await setDoc(doc(db, 'users', profile.uid, 'patterns', 'current'), {
          uid: profile.uid,
          stats,
          insight,
          updatedAt: nextPattern.updatedAt,
        });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to reach Gemini right now';
      setAiError(msg);
      // Graceful rules-based fallback
      setPattern({
        uid: profile.uid,
        stats,
        insight: deterministicInsight,
        updatedAt: Date.now(),
      });
    } finally {
      setAiLoading(false);
    }
  }, [profile, computedPatterns, glasses, effectiveGoalMl, isDemo, authUser]);

  const enablePushNotifications = useCallback(async () => {
    const res = await requestPushAndRegisterToken(profile?.uid ?? null);
    return { granted: res.granted, reason: res.reason };
  }, [profile?.uid]);

  const exportAllDataJson = useCallback(() => {
    const payload = {
      exportedAt: new Date().toISOString(),
      profile,
      glasses,
      logs,
      days,
      slots,
      pattern,
      customBadges,
      tokenState,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sippy-export-${todayKey}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [profile, glasses, logs, days, slots, pattern, customBadges, tokenState, todayKey]);

  const deleteAccountAndData = useCallback(async () => {
    if (profile?.uid) {
      localStorage.removeItem(`${CUSTOM_BADGES_PREFIX}${profile.uid}`);
      localStorage.removeItem(`${TOKENS_PREFIX}${profile.uid}`);
    }
    setCustomBadges([]);
    setTokenState({ balance: 5, rewardedDates: [], unlockedRecipes: [], totalBoxesOpened: 0 });
    if (isDemo) {
      localStorage.removeItem(
        profile?.uid === 'demo-alex' ? DEMO_STORAGE_KEY : LOCAL_STORAGE_KEY
      );
      setIsDemo(false);
      setProfile(null);
      setLogs([]);
      setDays([]);
      setSlots([]);
      setMode('onboarding');
      setOnboardingStep(1);
      return;
    }

    if (!db || !authUser) return;
    const uid = authUser.uid;
    const subcollections = ['glasses', 'logs', 'days', 'slots', 'patterns', 'fcmTokens'];
    for (const sub of subcollections) {
      const snap = await getDocs(collection(db, 'users', uid, sub));
      const batch = writeBatch(db);
      snap.docs.forEach((d) => batch.delete(d.ref));
      await batch.commit();
    }
    await deleteDoc(doc(db, 'users', uid));
    await signOutFirebase();
  }, [isDemo, authUser, profile?.uid]);

  // Handle PWA shortcuts (/?quick=250, /?quick=custom) & SW push messages
  const shortcutHandledRef = useRef(false);
  useEffect(() => {
    if (mode !== 'app' || shortcutHandledRef.current) return;
    shortcutHandledRef.current = true;

    const params = new URLSearchParams(window.location.search);
    const quick = params.get('quick');
    if (quick === 'custom') {
      setLogSheetOpen(true);
    } else if (quick && /^\d+$/.test(quick)) {
      const ml = Math.max(50, Math.min(1500, Number(quick)));
      logDrink({ ml, drinkType: 'water', source: 'shortcut' });
    }
  }, [mode, logDrink]);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const onMessage = (event: MessageEvent) => {
      if (event.data?.type !== 'SIPPY_PUSH_ACTION') return;
      const { action, data } = event.data;
      if (action === 'log-default') {
        const ml = Number(data?.defaultGlassMl || 250);
        logDrink({ ml, drinkType: 'water', source: 'push' });
      } else if (action === 'snooze-15' && data?.slotId) {
        snoozeSlot(String(data.slotId), 15);
      }
    };
    navigator.serviceWorker.addEventListener('message', onMessage);
    return () => navigator.serviceWorker.removeEventListener('message', onMessage);
  }, [logDrink, snoozeSlot]);

  // Ensure default glasses exist if empty
  useEffect(() => {
    if (mode === 'app' && profile && glasses.length === 0) {
      setGlasses(createDefaultGlasses(profile.uid));
    }
  }, [mode, profile, glasses.length]);

  const value: SippyContextValue = {
    mode,
    onboardingStep,
    setOnboardingStep,
    isDemo,
    authUser,
    authError,
    profile,
    glasses,
    logs,
    todayLogs,
    days,
    slots,
    todaySlots,
    nextPendingSlot,
    pattern,
    patternStats: computedPatterns.stats,
    weatherInfo,
    effectiveGoalMl,
    todayTotalMl,
    boostMl,
    boostReason,
    currentStreak: streakInfo.currentStreak,
    bestStreak: streakInfo.bestStreak,
    shieldsEarned: streakInfo.shieldsEarned,
    shieldSavedDates: streakInfo.shieldSavedDates,
    badges: streakInfo.badges,
    achievementBadges,
    customBadges,
    customBadgeStatuses,
    tokens: tokenState.balance,
    mysteryBoxCost: MYSTERY_BOX_COST,
    unlockedRecipes: tokenState.unlockedRecipes,
    totalBoxesOpened: tokenState.totalBoxesOpened,
    lastGoalTokensEarned,
    unlockedSkins: streakInfo.unlockedSkins,
    goalHitRate: streakInfo.goalHitRate,
    avgDailyMl: streakInfo.avgDailyMl,
    sippyMood: moodInfo.mood,
    sippyMessage: moodInfo.message,
    isLoggingAnim,
    showConfetti,
    goalHitSheetOpen,
    setGoalHitSheetOpen,
    logSheetOpen,
    setLogSheetOpen,
    feelingSheetOpen,
    setFeelingSheetOpen,
    reminderPreviewOpen,
    setReminderPreviewOpen,
    pendingDrinkRequest,
    intakeWarningStatus,
    undoToast,
    dismissUndoToast,
    liveAnnouncement,
    aiLoading,
    aiError,
    fewerRemindersPrompt,
    dismissFewerRemindersPrompt: () => setFewerRemindersPrompt(false),
    startDemoMode,
    signInWithGoogle,
    finishOnboarding,
    signOutUser,
    requestLogDrink,
    confirmPendingDrink,
    cancelPendingDrink,
    logDrink,
    editLog,
    deleteLog,
    undoLastLog,
    snoozeSlot,
    skipSlot,
    completeSlot,
    editSlotTime,
    toggleWorkoutBoost,
    removeTodayBoosts,
    toggleWeatherBoost,
    updateProfile,
    addGlass,
    updateGlass,
    deleteGlass,
    addCustomBadge,
    deleteCustomBadge,
    openMysteryBox,
    submitFeeling,
    refreshAIInsight,
    enablePushNotifications,
    exportAllDataJson,
    deleteAccountAndData,
  };

  return <SippyContext.Provider value={value}>{children}</SippyContext.Provider>;
};

export function useSippy() {
  const ctx = useContext(SippyContext);
  if (!ctx) throw new Error('useSippy must be used within SippyProvider');
  return ctx;
}
