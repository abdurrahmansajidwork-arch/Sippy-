import React, { useEffect, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { BottomNav, type AppTab } from './components/BottomNav';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Mascot } from './components/Mascot';
import { OnboardingFlow } from './components/OnboardingFlow';
import {
  ConfirmDrinkModal,
  FeelingSheet,
  GoalHitSheet,
  LogSheet,
  ReminderPreviewModal,
} from './components/Sheets';
import { SippyProvider, useSippy } from './context/SippyContext';
import { HomeScreen } from './screens/HomeScreen';
import { MeScreen } from './screens/MeScreen';
import { PlanScreen } from './screens/PlanScreen';
import { StatsScreen } from './screens/StatsScreen';

const SippyShell: React.FC = () => {
  const {
    mode,
    setLogSheetOpen,
    undoToast,
    undoLastLog,
    dismissUndoToast,
    liveAnnouncement,
  } = useSippy();
  const [activeTab, setActiveTab] = useState<AppTab>('home');

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [activeTab]);

  useEffect(() => {
    const onVisChange = () => {
      document.documentElement.classList.toggle('tab-hidden', document.hidden);
    };
    document.addEventListener('visibilitychange', onVisChange);
    return () => document.removeEventListener('visibilitychange', onVisChange);
  }, []);

  if (mode === 'loading') {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center bg-[var(--canvas)] p-6">
        <Mascot mood="happy" size={96} />
        <p className="mt-3 text-sm font-semibold text-[var(--ink-500)]">Waking Sippy...</p>
      </div>
    );
  }

  if (mode === 'onboarding') {
    return <OnboardingFlow />;
  }

  return (
    <div className="min-h-dvh bg-[var(--canvas)]">
      {/* Screen reader live announcement for hydration actions */}
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {liveAnnouncement}
      </div>

      <main className="max-w-[480px] mx-auto px-5 pt-3 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
          >
            {activeTab === 'home' && (
              <HomeScreen
                onOpenStats={() => setActiveTab('stats')}
                onOpenSettings={() => setActiveTab('settings')}
              />
            )}
            {activeTab === 'plan' && <PlanScreen />}
            {activeTab === 'stats' && <StatsScreen />}
            {activeTab === 'settings' && <MeScreen />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Undo Toast above floating bottom nav */}
      <AnimatePresence>
        {undoToast && (
          <motion.div
            key={undoToast.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 left-0 right-0 z-40 px-5 pointer-events-none"
          >
            <div className="max-w-[440px] mx-auto pointer-events-auto rounded-full bg-[var(--ink-900)] text-[var(--color-cta-text)] px-4 py-2.5 shadow-lg flex items-center justify-between gap-3">
              <span className="text-sm font-semibold">{undoToast.message}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void undoLastLog()}
                  className="min-h-[36px] px-2.5 rounded-full text-xs font-bold text-[#6FD3FF]"
                >
                  Undo
                </button>
                <button
                  type="button"
                  onClick={dismissUndoToast}
                  aria-label="Dismiss toast"
                  className="min-h-[36px] px-1.5 text-xs opacity-70"
                >
                  ✕
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <BottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenLog={() => setLogSheetOpen(true)}
      />

      <LogSheet />
      <ConfirmDrinkModal />
      <FeelingSheet />
      <GoalHitSheet />
      <ReminderPreviewModal />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <MotionConfig reducedMotion="user">
        <SippyProvider>
          <SippyShell />
        </SippyProvider>
      </MotionConfig>
    </ErrorBoundary>
  );
}
