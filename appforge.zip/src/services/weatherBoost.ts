import type { WeatherBoostInfo } from '../types';
import { calculateWeatherBoost } from '../utils/patternEngine';

export async function fetchWeatherBoost(baseGoalMl: number): Promise<WeatherBoostInfo> {
  const position = await new Promise<GeolocationPosition>((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation unavailable'));
      return;
    }
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: false,
      maximumAge: 60 * 60 * 1000,
      timeout: 8000,
    });
  });

  // Coarsen coordinates to 1 decimal place (~11 km) for privacy
  const lat = Math.round(position.coords.latitude * 10) / 10;
  const lon = Math.round(position.coords.longitude * 10) / 10;

  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=temperature_2m_max&timezone=auto&forecast_days=1`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error('Weather check failed');
  }
  const data = await res.json();
  const maxTempC = Number(data?.daily?.temperature_2m_max?.[0] ?? 22);
  const boostMl = calculateWeatherBoost(baseGoalMl, maxTempC);

  return {
    maxTempC: Math.round(maxTempC),
    boostMl,
    reason: boostMl > 0 ? `+${boostMl} hot day (${Math.round(maxTempC)}°C)` : `Mild day (${Math.round(maxTempC)}°C)`,
    fetchedAt: Date.now(),
  };
}
