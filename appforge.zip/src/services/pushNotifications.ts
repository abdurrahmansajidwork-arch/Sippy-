import { getMessaging, getToken, isSupported } from 'firebase/messaging';
import { doc, setDoc } from 'firebase/firestore';
import { app, db, handleFirestoreError, OperationType } from './firebase';

function sanitizeTokenId(token: string): string {
  return token.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
}

export function detectPushPlatform(): 'web' | 'ios-pwa' | 'android-pwa' {
  const ua = navigator.userAgent.toLowerCase();
  const isStandalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true;
  if (/iphone|ipad|ipod/.test(ua)) return 'ios-pwa';
  if (/android/.test(ua) && isStandalone) return 'android-pwa';
  return 'web';
}

export async function requestPushAndRegisterToken(uid: string | null): Promise<{
  granted: boolean;
  token: string | null;
  reason?: string;
}> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { granted: false, token: null, reason: 'Notifications are not supported in this browser.' };
  }

  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    return { granted: false, token: null, reason: 'Notification permission was declined.' };
  }

  if (!app || !uid || uid === 'demo-alex') {
    return {
      granted: true,
      token: null,
      reason: 'Browser permission granted (sign in with Google for cloud push sync).',
    };
  }

  try {
    const supported = await isSupported();
    if (!supported) {
      return { granted: true, token: null, reason: 'FCM Web Push is not supported in this browser.' };
    }

    const swReg = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
    const messaging = getMessaging(app);
    const rawVapid = import.meta.env.VITE_FIREBASE_VAPID_KEY;
    const vapidKey =
      typeof rawVapid === 'string' && /^B[A-Za-z0-9_-]{80,}$/.test(rawVapid.trim())
        ? rawVapid.trim()
        : undefined;
    const token = await getToken(messaging, {
      ...(vapidKey ? { vapidKey } : {}),
      serviceWorkerRegistration: swReg,
    });

    if (token && db) {
      const tokenId = sanitizeTokenId(token);
      const path = `users/${uid}/fcmTokens/${tokenId}`;
      try {
        await setDoc(doc(db, 'users', uid, 'fcmTokens', tokenId), {
          uid,
          token,
          platform: detectPushPlatform(),
          createdAt: Date.now(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
      return { granted: true, token };
    }

    return {
      granted: true,
      token: null,
      reason: 'Permission granted. Add VITE_FIREBASE_VAPID_KEY for background FCM delivery.',
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unable to register FCM token';
    return { granted: true, token: null, reason: msg };
  }
}
