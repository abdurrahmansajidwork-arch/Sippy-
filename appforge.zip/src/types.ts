export type DrinkType = 'water' | 'sparkling' | 'tea' | 'coffee' | 'juice' | 'milk';

export type NotificationTone = 'gentle' | 'playful' | 'coach';

export type GlassIconType = 'tumbler' | 'bottle' | 'mug' | 'cup' | 'jug' | 'boba';

export type GlassSkin = 'classic' | 'mason' | 'sports' | 'boba';

export type SippyMood =
  | 'happy'
  | 'hyped'
  | 'thirsty'
  | 'worried'
  | 'sleepy'
  | 'cheeky'
  | 'proud'
  | 'waving'
  | 'thinking';

export type FeelingLevel = 'drained' | 'okay' | 'good' | 'great';

export type UnitType = 'ml' | 'oz';

export type WorkoutLevel = 'light' | 'moderate' | 'intense';

export type SlotStatus = 'pending' | 'done' | 'missed' | 'skipped';

export type LogSource = 'app' | 'push' | 'shortcut';

export interface HydrationCalculatorInput {
  age: number;
  weightKg: number;
  heightCm: number;
  workoutLevel: WorkoutLevel;
  workoutsPerWeek: number;
}

export interface UserProfile {
  uid: string;
  name: string;
  email?: string;
  photoURL?: string;
  goalMl: number;
  wakeTime: string; // HH:MM
  bedTime: string;  // HH:MM
  tone: NotificationTone;
  maxPushPerDay: number;
  unit: UnitType;
  defaultGlassId: string;
  weatherBoost: boolean;
  workoutBoostMl: number;
  shields: number;
  activeSkin: GlassSkin;
  createdAt: number;
  updatedAt?: number;
}

export interface GlassPreset {
  id: string;
  uid: string;
  name: string;
  ml: number;
  icon: GlassIconType;
  createdAt?: number;
}

export interface HydrationLog {
  id: string;
  uid: string;
  ts: number;
  date: string; // yyyy-mm-dd
  ml: number;
  countedMl: number;
  glassId: string;
  drinkType: DrinkType;
  source: LogSource;
  createdAt?: number;
}

export interface FeelingEntry {
  ts: number;
  level: FeelingLevel;
  totalMlAtCheckin: number;
}

export interface DaySummary {
  id: string; // yyyy-mm-dd
  uid: string;
  date: string; // yyyy-mm-dd
  goalMl: number;
  totalMl: number;
  hit: boolean;
  shieldUsed: boolean;
  boostMl: number;
  feelings: FeelingEntry[];
  updatedAt?: number;
}

export interface ReminderSlot {
  id: string;
  uid: string;
  date: string;
  notifyAt: number;
  targetMl: number;
  status: SlotStatus;
  movedFrom?: number;
  title: string;
  body: string;
  notified: boolean;
  createdAt?: number;
  updatedAt?: number;
}

export interface PatternStats {
  intakeByHour: number[]; // 24 buckets
  completionByHour: Record<number, number>; // 0..1
  completionByWeekday: Record<number, number>; // 0..6 (Sun..Sat)
  medianResponseMin: number | null;
  bestWeekday: string;
  worstWeekday: string;
  usualFirstDrink: string;
  usualLastDrink: string;
  daysTracked: number;
  hasEnoughData: boolean;
}

export interface ScheduleTweak {
  hour: number;
  shiftMinutes: number;
  reason: string;
}

export interface HydrationPattern {
  uid: string;
  stats: PatternStats;
  insight: string;
  tweaks?: ScheduleTweak[];
  updatedAt: number;
}

export type BadgeId =
  | 'first_sip'
  | 'streak_3'
  | 'streak_7'
  | 'streak_14'
  | 'streak_30'
  | 'early_bird'
  | 'perfect_week'
  | 'hydration_hero';

export type AchievementPaletteKey = 'brand' | 'water' | 'mint' | 'flame' | 'lav';

export type AchievementIconKey =
  | 'droplet'
  | 'flame'
  | 'star'
  | 'trophy'
  | 'sun'
  | 'sparkles'
  | 'shield';

export interface BadgeInfo {
  id: BadgeId;
  title: string;
  description: string;
  unlocked: boolean;
}

export interface BadgeProgressInfo extends BadgeInfo {
  category: 'streak' | 'habit';
  currentValue: number;
  targetValue: number;
  unitLabel: string;
  progressPct: number;
  palette: AchievementPaletteKey;
  icon: AchievementIconKey;
}

export type CustomBadgeRuleType = 'streak_days' | 'total_logs';

export interface CustomBadge {
  id: string;
  title: string;
  ruleType: CustomBadgeRuleType;
  targetValue: number;
  icon: AchievementIconKey;
  palette: AchievementPaletteKey;
  createdAt: number;
}

export interface CustomBadgeStatus {
  badge: CustomBadge;
  currentValue: number;
  progressPct: number;
  unlocked: boolean;
}

export interface WeatherBoostInfo {
  maxTempC: number;
  boostMl: number;
  reason: string;
  fetchedAt: number;
}

export type RecipeCategory = 'coffee' | 'infused' | 'tea' | 'sparkling';

export interface HydrationRecipe {
  id: string;
  title: string;
  category: RecipeCategory;
  tagline: string;
  waterMl: number;
  prepMinutes: number;
  accentBg: string;
  accentColor: string;
  ingredients: string[];
  steps: string[];
  hydrationTip: string;
}

export interface UnlockedRecipeEntry {
  recipeId: string;
  unlockedAt: number;
  boxNumber: number;
}

