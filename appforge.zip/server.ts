import dotenv from 'dotenv';
import express from 'express';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

function loadPublicFirebaseConfig(): Record<string, string> | null {
  try {
    const cfgPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(cfgPath)) {
      const parsed = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      return {
        apiKey: String(parsed.apiKey || ''),
        authDomain: String(parsed.authDomain || ''),
        projectId: String(parsed.projectId || ''),
        storageBucket: String(parsed.storageBucket || ''),
        messagingSenderId: String(parsed.messagingSenderId || ''),
        appId: String(parsed.appId || ''),
      };
    }
  } catch {
    // Fall through to env vars
  }

  if (process.env.VITE_FIREBASE_API_KEY && process.env.VITE_FIREBASE_PROJECT_ID) {
    return {
      apiKey: process.env.VITE_FIREBASE_API_KEY,
      authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || '',
      projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET || '',
      messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
      appId: process.env.VITE_FIREBASE_APP_ID || '',
    };
  }
  return null;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/firebase-public-config', (_req, res) => {
    const cfg = loadPublicFirebaseConfig();
    if (!cfg) {
      res.status(404).json({ error: 'Firebase public config not found' });
      return;
    }
    res.json(cfg);
  });

  app.post('/api/gemini/insight', async (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        error: 'GEMINI_API_KEY is not configured in Secrets.',
      });
      return;
    }

    const { stats, tone, goalMl, defaultGlassMl } = req.body ?? {};
    if (!stats || typeof stats !== 'object') {
      res.status(400).json({ error: 'Missing hydration pattern stats payload.' });
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const prompt = [
        'Analyze this user hydration pattern summary and return personalized insights, optional schedule tweaks, and short push notification copy in Sippy voice.',
        'Constraints:',
        '- insight: 1 to 2 concise warm sentences, max 220 characters, no medical claims, no shaming.',
        '- scheduleTweaks: 0 to 2 suggested hour shifts (e.g. move 15:00 slot -30 min if 15:00 completion rate is low).',
        '- notificationCopy: title max 60 chars, body max 110 chars, max 1 emoji, no ALL CAPS, never guilt or threaten.',
        `Tone preference: ${String(tone || 'playful')}`,
        `Daily goal ml: ${Number(goalMl || 2500)}`,
        `Default glass ml: ${Number(defaultGlassMl || 250)}`,
        `Stats JSON: ${JSON.stringify(stats)}`,
      ].join('\n');

      const buildRequest = (model: string) =>
        ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            systemInstruction:
              'You are Sippy, a warm, slightly cheeky droplet hydration buddy. Output valid JSON strictly matching the requested schema. Never make medical claims or guilt-trip the user.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                insight: {
                  type: Type.STRING,
                  description: '1-2 friendly sentences summarizing the user hydration pattern.',
                },
                scheduleTweaks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      hour: { type: Type.INTEGER },
                      shiftMinutes: { type: Type.INTEGER },
                      reason: { type: Type.STRING },
                    },
                  },
                },
                notificationCopy: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    body: { type: Type.STRING },
                  },
                },
              },
            },
          },
        });

      let response;
      try {
        response = await buildRequest('gemini-4-hydrogen');
      } catch {
        response = await buildRequest('gemini-2.5-flash');
      }

      const rawText = (response.text ?? '').trim();
      const parsed = JSON.parse(rawText);
      res.json(parsed);
    } catch {
      res.status(503).json({ error: 'AI insights are temporarily busy.' });
    }
  });

  const httpServer = http.createServer(app);

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
        watch: null,
      },
      plugins: [
        {
          name: 'disable-hmr-websocket',
          transform(code, id) {
            if (id.endsWith('vite/dist/client/client.mjs')) {
              const target = /let wsTransport = createWebSocketModuleRunnerTransport\(\{[\s\S]*?\}\);/;
              return {
                code: code.replace(
                  target,
                  'let wsTransport = { async connect() {}, async disconnect() {}, send() {} };'
                ),
                map: null,
              };
            }
          },
        },
      ],
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Sippy server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Sippy server:', err);
  process.exit(1);
});
