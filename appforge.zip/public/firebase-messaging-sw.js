/* eslint-disable no-undef */
importScripts('https://www.gstatic.com/firebasejs/11.0.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/11.0.2/firebase-messaging-compat.js');

let initialized = false;

async function ensureFirebase() {
  if (initialized) return;
  try {
    const res = await fetch('/api/firebase-public-config');
    if (!res.ok) return;
    const cfg = await res.json();
    if (!cfg || !cfg.apiKey) return;
    if (!firebase.apps.length) {
      firebase.initializeApp(cfg);
    }
    const messaging = firebase.messaging();
    messaging.onBackgroundMessage((payload) => {
      const title = payload.notification?.title || payload.data?.title || 'Sip time';
      const body = payload.notification?.body || payload.data?.body || '250 ml keeps your day smooth.';
      const defaultGlassMl = payload.data?.defaultGlassMl || '250';
      const slotId = payload.data?.slotId || '';

      self.registration.showNotification(title, {
        body,
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        tag: slotId ? `sippy-slot-${slotId}` : 'sippy-nudge',
        data: {
          url: '/?from=push',
          slotId,
          defaultGlassMl,
        },
        actions: [
          { action: 'log-default', title: `+ ${defaultGlassMl} ml` },
          { action: 'snooze-15', title: 'Snooze 15 min' },
        ],
      });
    });
    initialized = true;
  } catch {
    // Ignore background init error when offline
  }
}

self.addEventListener('activate', (event) => {
  event.waitUntil(ensureFirebase());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const data = event.notification.data || {};
  let targetUrl = '/';

  if (event.action === 'log-default') {
    const ml = data.defaultGlassMl || '250';
    targetUrl = `/?quick=${encodeURIComponent(ml)}&source=push&slotId=${encodeURIComponent(data.slotId || '')}`;
  } else if (event.action === 'snooze-15') {
    targetUrl = `/?snooze=15&slotId=${encodeURIComponent(data.slotId || '')}`;
  }

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.postMessage({ type: 'SIPPY_PUSH_ACTION', action: event.action || 'open', data });
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
      return undefined;
    })
  );
});

ensureFirebase();
