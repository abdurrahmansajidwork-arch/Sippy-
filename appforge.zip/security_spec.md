# Sippy Security Specification (Payload-First Security TDD)

## 1. Data Invariants
1. Every document in `users/{userId}` and its subcollections (`glasses`, `logs`, `days`, `slots`, `patterns`, `fcmTokens`) is strictly owned by `request.auth.uid == userId` with `request.auth.token.email_verified == true`.
2. Users cannot list the top-level `users` collection (`allow list: if false`) to guarantee PII isolation (`email`, `photoURL`).
3. Every subcollection document stores `uid == userId` and cannot be created unless the parent `users/{userId}` document exists (Master Gate).
4. `logs/{logId}` requires `ml` to be an integer between `1` and `3000`, and `countedMl` between `1` and `3000`.
5. `days/{dayId}` caps `feelings` to `<= 10` entries.
6. Immutable fields (`uid`, `createdAt`) cannot be changed on update.
7. All string fields enforce `.size()` bounds; all keys enforce `hasAll` + `hasOnly` on create and `affectedKeys().hasOnly(...)` on update.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated read/write** on `/users/u1` -> `PERMISSION_DENIED`.
2. **Unverified email token** (`email_verified: false`) writing `/users/u1` -> `PERMISSION_DENIED`.
3. **Cross-user access**: user `u2` reading or writing `/users/u1/logs/l1` -> `PERMISSION_DENIED`.
4. **Top-level users list scraping**: `list /users` -> `PERMISSION_DENIED`.
5. **Shadow / Ghost field injection**: creating `/users/u1` with extra field `isAdmin: true` -> `PERMISSION_DENIED`.
6. **Log ml out of bounds (too high)**: creating `/users/u1/logs/l1` with `ml: 5000` -> `PERMISSION_DENIED`.
7. **Log ml out of bounds (zero/negative)**: creating `/users/u1/logs/l1` with `ml: 0` -> `PERMISSION_DENIED`.
8. **Identity spoofing**: user `u1` creating `/users/u1/logs/l1` with `uid: "u2"` -> `PERMISSION_DENIED`.
9. **Immutable field mutation**: updating `/users/u1` changing `createdAt` or `uid` -> `PERMISSION_DENIED`.
10. **ID Poisoning**: creating `/users/u1/glasses/<2000-char-id>` -> `PERMISSION_DENIED`.
11. **Unbounded array / Resource poisoning**: updating `/users/u1/days/2026-11-23` with 25 entries in `feelings` -> `PERMISSION_DENIED`.
12. **Orphaned subcollection write**: creating `/users/u1/logs/l1` when `/users/u1` does not exist -> `PERMISSION_DENIED`.
