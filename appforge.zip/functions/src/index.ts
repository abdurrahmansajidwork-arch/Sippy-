import { initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { getMessaging } from 'firebase-admin/messaging';
import { onSchedule } from 'firebase-functions/v2/scheduler';

initializeApp();
const db = getFirestore();
const messaging = getMessaging();

function parseTimeMinutes(hhmm: string): number {
  const [h, m] = (hhmm || '07:00').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

function snapTo5Min(ms: number): number {
  const step = 5 * 60 * 1000;
  return Math.round(ms / step) * step;
}

function getDateKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

/**
 * 1. Every minute: dispatch due hydration push notifications for slots
 *    where notified == false and notifyAt <= now.
 */
export const dispatchDueHydrationSlots = onSchedule('every 1 minutes', async () => {
  const now = Date.now();
  const snap = await db
    .collectionGroup('slots')
    .where('notified', '==', false)
    .where('notifyAt', '<=', now)
    .limit(100)
    .get();

  for (const slotDoc of snap.docs) {
    const slot = slotDoc.data();
    const userRef = slotDoc.ref.parent.parent;
    if (!userRef) continue;

    if (slot.status !== 'pending') {
      await slotDoc.ref.update({ notified: true, updatedAt: now });
      continue;
    }

    const userSnap = await userRef.get();
    const user = userSnap.data();
    if (!user) continue;

    // Respect daily goal reached and day window
    const daySnap = await userRef.collection('days').doc(slot.date).get();
    const day = daySnap.data();
    if (day && day.hit) {
      await slotDoc.ref.update({ notified: true, status: 'done', updatedAt: now });
      continue;
    }

    const tokensSnap = await userRef.collection('fcmTokens').get();
    if (tokensSnap.empty) {
      await slotDoc.ref.update({ notified: true, updatedAt: now });
      continue;
    }

    const defaultGlassMl = String(slot.targetMl || 250);
    const tokens = tokensSnap.docs.map((d) => ({ id: d.id, token: String(d.data().token || '') })).filter((t) => t.token);

    for (const t of tokens) {
      try {
        await messaging.send({
          token: t.token,
          notification: {
            title: String(slot.title || 'Sip time').slice(0, 60),
            body: String(slot.body || `Drink ${defaultGlassMl} ml to stay on pace.`).slice(0, 110),
          },
          data: {
            slotId: slotDoc.id,
            defaultGlassMl,
            url: '/?from=push',
          },
          webpush: {
            fcmOptions: { link: '/?from=push' },
            notification: {
              icon: '/pwa-192x192.png',
              badge: '/pwa-192x192.png',
              actions: [
                { action: 'log-default', title: `+ ${defaultGlassMl} ml` },
                { action: 'snooze-15', title: 'Snooze 15 min' },
              ],
            },
          },
        });
      } catch (err: unknown) {
        const code = typeof err === 'object' && err && 'code' in err ? String((err as { code?: string }).code) : '';
        if (code.includes('registration-token-not-registered') || code.includes('invalid-argument')) {
          await userRef.collection('fcmTokens').doc(t.id).delete();
        }
      }
    }

    await slotDoc.ref.update({ notified: true, updatedAt: now });
  }
});

/**
 * 2. Every minute: mark slots missed 30 min after notification and redistribute
 *    remaining ml across remaining pending slots (max +50% per slot).
 */
export const shiftMissedHydrationSlots = onSchedule('every 1 minutes', async () => {
  const now = Date.now();
  const cutoff = now - 30 * 60 * 1000;

  const snap = await db
    .collectionGroup('slots')
    .where('status', '==', 'pending')
    .where('notified', '==', true)
    .where('notifyAt', '<=', cutoff)
    .limit(100)
    .get();

  const touchedUsers = new Map<string, { userRef: FirebaseFirestore.DocumentReference; date: string; missedMl: number; missedTime: number }>();

  for (const docSnap of snap.docs) {
    const slot = docSnap.data();
    const userRef = docSnap.ref.parent.parent;
    if (!userRef) continue;

    await docSnap.ref.update({ status: 'missed', updatedAt: now });
    const key = `${userRef.id}:${slot.date}`;
    const prev = touchedUsers.get(key);
    touchedUsers.set(key, {
      userRef,
      date: String(slot.date),
      missedMl: (prev?.missedMl || 0) + Number(slot.targetMl || 250),
      missedTime: Math.max(prev?.missedTime || 0, Number(slot.notifyAt || now)),
    });
  }

  for (const item of touchedUsers.values()) {
    const pendingSnap = await item.userRef
      .collection('slots')
      .where('date', '==', item.date)
      .where('status', '==', 'pending')
      .get();

    const pending = pendingSnap.docs
      .map((d) => ({ ref: d.ref, data: d.data() }))
      .sort((a, b) => Number(a.data.notifyAt) - Number(b.data.notifyAt));

    let remaining = item.missedMl;
    for (const p of pending) {
      if (remaining <= 0) break;
      const cur = Number(p.data.targetMl || 250);
      const maxAdd = Math.round(cur * 0.5);
      const add = Math.min(remaining, maxAdd);
      if (add > 0) {
        await p.ref.update({
          targetMl: cur + add,
          movedFrom: p.data.movedFrom || item.missedTime,
          title: 'Still here',
          body: `No stress. Added +${add} ml to keep you on pace.`,
          updatedAt: now,
        });
        remaining -= add;
      }
    }
  }
});

/**
 * 3. Hourly: create baseline schedule with template copy when a user's day
 *    begins so reminders still fire even if the app hasn't been opened.
 */
export const generateDailySchedules = onSchedule('every 60 minutes', async () => {
  const now = new Date();
  const todayKey = getDateKey(now);
  const usersSnap = await db.collection('users').limit(500).get();

  for (const userDoc of usersSnap.docs) {
    const user = userDoc.data();
    const existingSlots = await userDoc.ref.collection('slots').where('date', '==', todayKey).limit(1).get();
    if (!existingSlots.empty) continue;

    const goalMl = Number(user.goalMl || 2500);
    const maxPush = Math.min(12, Math.max(3, Number(user.maxPushPerDay || 8)));
    const defaultGlassMl = 250;

    const dayStart = new Date(`${todayKey}T00:00:00.000Z`).getTime();
    const wakeMin = parseTimeMinutes(String(user.wakeTime || '07:00')) + 30;
    const bedMin = parseTimeMinutes(String(user.bedTime || '23:00')) - 90;
    const startMs = dayStart + wakeMin * 60 * 1000;
    const endMs = Math.max(startMs + 60 * 60 * 1000, dayStart + bedMin * 60 * 1000);

    const count = Math.min(maxPush, Math.max(2, Math.ceil(goalMl / defaultGlassMl)));
    const span = endMs - startMs;
    const batch = db.batch();

    for (let i = 0; i < count; i++) {
      const ratio = count === 1 ? 0.5 : i / (count - 1);
      const notifyAt = snapTo5Min(startMs + ratio * span);
      const targetMl = Math.round(goalMl / count / 10) * 10;
      const ref = userDoc.ref.collection('slots').doc(`auto_${todayKey}_${i}`);
      batch.set(ref, {
        uid: userDoc.id,
        date: todayKey,
        notifyAt,
        targetMl,
        status: 'pending',
        title: 'Sip time',
        body: `${targetMl} ml keeps your hydration smooth today.`,
        notified: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    }
    await batch.commit();
  }
});
