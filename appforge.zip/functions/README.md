# Sippy Cloud Functions (Scheduled Push & Background Shifting)

Scheduled Cloud Functions require the **Firebase CLI** and the **Firebase Blaze plan**.
All client-side adaptive scheduling, missed-slot shifting, offline logging, and Firestore persistence run out of the box without deploying `/functions`.

## Deploy steps

1. Install Firebase CLI and log in:
   ```bash
   npm install -g firebase-tools
   firebase login
   ```
2. Select your Firebase project from `firebase-applet-config.json`:
   ```bash
   firebase use gen-lang-client-0558507130
   ```
3. Build and deploy Firestore indexes and Cloud Functions:
   ```bash
   cd functions && npm install && npm run build && cd ..
   firebase deploy --only firestore:indexes,functions
   ```
4. Configure your Web Push VAPID key (`VITE_FIREBASE_VAPID_KEY`) in Firebase Console -> Project Settings -> Cloud Messaging -> Web configuration -> Web Push certificates.
